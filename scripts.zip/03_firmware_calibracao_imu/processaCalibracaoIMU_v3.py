import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

AQUI = Path(__file__).resolve().parent
ARQ_LOG = AQUI / "dados" / "calib_log.txt"
ARQ_JSON = AQUI / "dados" / "calibracao_imu_v3.json"
LINHA_INICIO = 21720       # 1ª linha (1-based) da sessão utilizada no log
PASTA_GRAFICOS = AQUI / "graficos"
PASTA_GRAFICOS.mkdir(exist_ok=True)

FS = 100.0                 # taxa do stream [Hz]
JANELA = 50                # 0,5 s para o desvio padrão móvel
LIMIAR_PARADO = 0.003      # rad/s (ruído em repouso ~0,0008 rad/s)
MARGEM = 50                # descarta 0,5 s em cada borda do trecho parado
DURACAO_MAX = 30.0         # s
RAD2DEG = 180.0 / np.pi


# ---------------------------------------------------------------- leitura do log
def ler_log(caminho):
    resultados, streams = [], []
    atual = None
    with open(caminho, encoding="utf-8") as f:
        linhas = f.readlines()[LINHA_INICIO - 1:]
        for linha in linhas:
            topico, _, conteudo = linha.strip().partition(" ")
            if topico.endswith("calib/result"):
                d = json.loads(conteudo)
                resultados.append(d)
                if d.get("status") == "stream_inicio":
                    atual = {"calibrado": bool(d.get("usa_calibracao_gyro")),
                             "idx_result": len(resultados) - 1,
                             "t": [], "raw": [], "cal": [], "phi": []}
                    streams.append(atual)
                elif d.get("status") == "stream_fim":
                    atual = None
            elif topico.endswith("calib/stream") and atual is not None:
                d = json.loads(conteudo)
                atual["t"].append(d["t"])
                atual["raw"].append(d["raw"])
                atual["cal"].append(d["cal"])
                atual["phi"].append(d["phi"])
    for s in streams:
        for k in ("t", "raw", "cal", "phi"):
            s[k] = np.asarray(s[k], dtype=float)
    return resultados, streams


def trecho_parado(giro):
    """Maior trecho contínuo com o desvio padrão móvel do giroscópio abaixo do limiar."""
    n = len(giro)
    if n < 2 * JANELA:
        return 0, 0
    if np.all(giro == 0):                     # sensor em sleep (leitura 0/0/0)
        return 0, 0
    dp = np.array([giro[max(0, i - JANELA // 2):i + JANELA // 2].std(axis=0).max()
                   for i in range(n)])
    parado = dp < LIMIAR_PARADO
    melhor, ini = (0, 0), None
    for i, ok in enumerate(np.append(parado, False)):
        if ok and ini is None:
            ini = i
        elif not ok and ini is not None:
            if i - ini > melhor[1] - melhor[0]:
                melhor = (ini, i)
            ini = None
    a, b = melhor[0] + MARGEM, melhor[1] - MARGEM
    return (a, b) if b > a else (0, 0)


resultados, streams = ler_log(ARQ_LOG)

# ---------------------------------------------------------------- valores finais
show = [r for r in resultados if r.get("status") == "show"]
if not show:
    raise SystemExit("Nenhuma mensagem 'show' no log: rode o passo 5.12.")
final = show[-1]

i_cal = max(i for i, r in enumerate(resultados) if r.get("status") == "accel_cal_ok")
posicoes = {}
for r in reversed(resultados[:i_cal]):
    if r.get("status") == "accel_pos_ok" and r["pos"] not in posicoes:
        posicoes[r["pos"]] = {k: r[k] for k in ("ax_g", "ay_g", "az_g",
                                                 "sd_ax_g", "sd_ay_g", "sd_az_g")}
    if len(posicoes) == 6:
        break

i_saved = max(i for i, r in enumerate(resultados) if r.get("status") == "saved")
i_bias = max(i for i, r in enumerate(resultados[:i_saved]) if r.get("status") == "gyro_bias_ok")
coleta_bias = resultados[i_bias]

# ---------------------------------------------------------------- trechos antes / depois
for s in streams:
    s["parado"] = trecho_parado(s["raw"][:, 3:]) if len(s["raw"]) else (0, 0)

cand_antes = [s for s in streams if s["idx_result"] < i_bias]   # antes da nova coleta de bias
antes = max(cand_antes, key=lambda s: s["parado"][1] - s["parado"][0])
depois = next(s for s in streams if s["idx_result"] > i_saved)

dur_a = (antes["parado"][1] - antes["parado"][0]) / FS
dur_d = (depois["parado"][1] - depois["parado"][0]) / FS
duracao = min(dur_a, dur_d, DURACAO_MAX)
n_amostras = int(round(duracao * FS))
if n_amostras < 5 * FS:
    raise SystemExit(f"Trecho parado curto demais (antes {dur_a:.1f} s, depois {dur_d:.1f} s).")


def recorte(s, chave):
    a = s["parado"][0]
    return s[chave][a:a + n_amostras]


A_raw, D_cal, D_raw = recorte(antes, "raw"), recorte(depois, "cal"), recorte(depois, "raw")
A_phi, D_phi = recorte(antes, "phi"), recorte(depois, "phi")
t = np.arange(n_amostras) / FS


def metricas(x, phi):
    giro, acel = x[:, 3:], x[:, :3]
    media_g = giro.mean(axis=0)
    return {
        "p_q_r_media_radps": media_g.tolist(),
        "p_q_r_dp_radps": giro.std(axis=0).tolist(),
        "deriva_p_q_r_grau_por_min": (media_g * RAD2DEG * 60).tolist(),
        "ax_ay_az_media_g": acel.mean(axis=0).tolist(),
        "norma_a_media_g": float(np.linalg.norm(acel, axis=1).mean()),
        "phi_acel_media_grau": float(phi.mean()),
        "phi_acel_dp_grau": float(phi.std()),
    }


m_antes = metricas(A_raw, A_phi)
m_depois = metricas(D_cal, D_phi)
m_depois_bruto = metricas(D_raw, D_phi)

# ---------------------------------------------------------------- saída em texto
eixos = ("p", "q", "r")
print(f"Trecho comparado: {duracao:.1f} s parado em cada stream "
      f"(antes: {dur_a:.1f} s parados; depois: {dur_d:.1f} s parados)\n")
print("Calibração gravada na NVS (mensagem 'show'):")
for i, e in enumerate(eixos):
    print(f"  bias {e} = {final[f'bias_{e}_radps']:+.5f} rad/s "
          f"({final[f'bias_{e}_radps'] * RAD2DEG:+.3f} °/s), "
          f"desvio padrão = {final[f'std_{e}_radps']:.5f} rad/s")
for e in ("x", "y", "z"):
    print(f"  acelerômetro {e}: offset = {final[f'off_{e}_g']:+.4f} g, escala = {final[f'esc_{e}']:.4f}")
print("\nMédias nas 6 posições [g]:")
for pos in ("xp", "xn", "yp", "yn", "zp", "zn"):
    v = posicoes[pos]
    print(f"  {pos}: ax = {v['ax_g']:+.4f}  ay = {v['ay_g']:+.4f}  az = {v['az_g']:+.4f}")
print("\nSensor parado            antes (bruto)      depois (corrigido)")
for i, e in enumerate(eixos):
    print(f"  média {e} [rad/s]      {m_antes['p_q_r_media_radps'][i]:+.5f}           "
          f"{m_depois['p_q_r_media_radps'][i]:+.5f}")
for i, e in enumerate(eixos):
    print(f"  deriva {e} [°/min]     {m_antes['deriva_p_q_r_grau_por_min'][i]:+8.2f}           "
          f"{m_depois['deriva_p_q_r_grau_por_min'][i]:+8.2f}")
print(f"  |a| médio [g]          {m_antes['norma_a_media_g']:.4f}             {m_depois['norma_a_media_g']:.4f}")

# ---------------------------------------------------------------- figura
CORES = ("tab:blue", "tab:orange", "tab:green")
ROTULOS = (r"\omega_{x,s}", r"\omega_{y,s}", r"\omega_{z,s}")   # eixos do sensor
fig, ax = plt.subplots(2, 2, figsize=(13, 8.5), sharex=True)

lim = 1.15 * max(np.abs(A_raw[:, 3:]).max(), np.abs(D_cal[:, 3:]).max())
for k, (dados, titulo) in enumerate(((A_raw, "(a) Giroscópio antes da calibração"),
                                     (D_cal, "(b) Giroscópio depois da calibração"))):
    for i, e in enumerate(ROTULOS):
        ax[0, k].plot(t, dados[:, 3 + i], color=CORES[i], lw=0.8, label=f"${e}$")
    ax[0, k].axhline(0, color="k", lw=0.6)
    ax[0, k].set_ylim(-lim, lim)
    ax[0, k].set_ylabel("Velocidade angular [rad/s]")
    ax[0, k].set_title(titulo)
    ax[0, k].legend(loc="center right" if k == 0 else "upper right", ncol=3)
    ax[0, k].grid(alpha=0.3)

# (c) ângulo obtido integrando o giroscópio com o sensor parado
for i, e in enumerate(ROTULOS):
    ang_a = np.concatenate(([0], np.cumsum((A_raw[1:, 3 + i] + A_raw[:-1, 3 + i]) / 2) / FS)) * RAD2DEG
    ang_d = np.concatenate(([0], np.cumsum((D_cal[1:, 3 + i] + D_cal[:-1, 3 + i]) / 2) / FS)) * RAD2DEG
    ax[1, 0].plot(t, ang_a, color=CORES[i], ls="--", lw=1.2, label=f"${e}$ antes")
    ax[1, 0].plot(t, ang_d, color=CORES[i], lw=1.6, label=f"${e}$ depois")
ax[1, 0].set_ylabel("Ângulo integrado [graus]")
ax[1, 0].set_title("(c) Deriva da integração do giroscópio")
ax[1, 0].legend(loc="upper left", ncol=2, fontsize=8)
ax[1, 0].grid(alpha=0.3)

# (d) módulo da aceleração medida
ax[1, 1].plot(t, np.linalg.norm(A_raw[:, :3], axis=1), color="tab:red", lw=0.8, label="antes")
ax[1, 1].plot(t, np.linalg.norm(D_cal[:, :3], axis=1), color="tab:blue", lw=0.8, label="depois")
ax[1, 1].axhline(1.0, color="k", lw=0.8, ls=":", label="1 g")
ax[1, 1].set_ylabel(r"$|\mathbf{a}|$ [g]")
ax[1, 1].set_title("(d) Módulo da aceleração medida")
ax[1, 1].legend(loc="upper right", ncol=3)
ax[1, 1].grid(alpha=0.3)

for a in ax[1]:
    a.set_xlabel("Tempo [s]")
fig.tight_layout()
arq_fig = PASTA_GRAFICOS / "calibracao_imu_antes_depois_v3.png"
plt.savefig(arq_fig, dpi=150)
print(f"\nFigura: {arq_fig}")

# ---------------------------------------------------------------- JSON
saida = {
    "origem": f"dados/calib_log.txt a partir da linha {LINHA_INICIO} (CalibracaoIMU_v2.ino)",
    "nvs": {
        "bias_p_q_r_radps": [final[f"bias_{e}_radps"] for e in eixos],
        "std_p_q_r_radps": [final[f"std_{e}_radps"] for e in eixos],
        "offset_x_y_z_g": [final[f"off_{e}_g"] for e in ("x", "y", "z")],
        "escala_x_y_z": [final[f"esc_{e}"] for e in ("x", "y", "z")],
    },
    "coleta_bias": {k: coleta_bias[k] for k in ("amostras", "falhas", "dt_ms")},
    "posicoes_acel_g": posicoes,
    "comparacao_parado": {
        "duracao_s": duracao,
        "antes_bruto": m_antes,
        "depois_corrigido": m_depois,
        "depois_bruto_mesmo_trecho": m_depois_bruto,
    },
    "verificacao_sinais_drone": "pendente de confirmação do usuário para o sensor novo",
}
with open(ARQ_JSON, "w", encoding="utf-8") as f:
    json.dump(saida, f, indent=2, ensure_ascii=False)
print(f"JSON:   {ARQ_JSON}")
