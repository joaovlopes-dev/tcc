#include <WiFi.h>
#include <Wire.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <Preferences.h>
#include <math.h>

#define MQTT_VERSION MQTT_VERSION_3_1

//================= AJUSTES =================
const char* WIFI_SSID   = "SEU_WIFI";
const char* WIFI_PASS   = "SUA_SENHA";
const char* BROKER_IP   = "IP_DO_BROKER";
const uint16_t BROKER_PORT = 1883;

const char* TOPIC_CMD    = "lab/esp32/calib/cmd";
const char* TOPIC_RESULT = "lab/esp32/calib/result";
const char* TOPIC_STREAM = "lab/esp32/calib/stream";
const char* TOPIC_STATUS = "lab/esp32/status";

const int   I2C_SDA = 13;   // lateral A
const int   I2C_SCL = 14;   // lateral A
const uint8_t MPU_ADDR = 0x68;

const int      N_GYRO   = 10000;
const int      N_ACCEL  = 1000;
const uint32_t TS_COLETA_US = 5000;   // 200 Hz
const uint32_t TS_STREAM_US = 10000;  // 100 Hz

const float GYRO_LSB_PER_DPS = 131.0f;
const float ACCEL_LSB_PER_G  = 16384.0f;
const float DPS_TO_RADPS     = 3.14159265f / 180.0f;
const float LSB_TO_RADPS     = DPS_TO_RADPS / GYRO_LSB_PER_DPS;
//===========================================

WiFiClient   espClient;
PubSubClient mqtt(espClient);
Preferences  prefs;

// ---------------- Calibracao (em LSB) ----------------
float gyro_bias_lsb[3] = {0, 0, 0};
float gyro_std_lsb[3]  = {0, 0, 0};
bool  gyro_bias_done   = false;

struct AccelPos {
  float mean[3];   // LSB
  float sd[3];     // LSB
  bool  has;
};
AccelPos accel_pos[6];

float accel_offset_lsb[3] = {0, 0, 0};
float accel_scale_lsb[3]  = {ACCEL_LSB_PER_G, ACCEL_LSB_PER_G, ACCEL_LSB_PER_G};
bool  accel_cal_done      = false;

// ---------------- Maquina de estados nao bloqueante ----------------
enum Modo { OCIOSO, COLETA_GIRO, COLETA_ACEL, STREAM };
Modo     modo = OCIOSO;
int      pos_atual = -1;
int      n_alvo = 0, n_ok = 0, n_falha = 0;
uint32_t t_prox_us = 0, t_inicio_ms = 0, t_fim_stream_ms = 0;
double   soma[3], soma2[3];

// --------------- MPU-6050 (registros) ---------------
void mpuWrite(uint8_t reg, uint8_t val) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(reg);
  Wire.write(val);
  Wire.endTransmission();
}

void mpuBegin() {
  Wire.begin(I2C_SDA, I2C_SCL, 400000);
  delay(10);
  mpuWrite(0x6B, 0x00);  // PWR_MGMT_1 = 0 (acorda)
  delay(10);
  mpuWrite(0x1A, 0x03);  // DLPF_CFG = 3 (~44 Hz)
  mpuWrite(0x1B, 0x00);  // GYRO_CONFIG +-250 dps
  mpuWrite(0x1C, 0x00);  // ACCEL_CONFIG +-2 g
  delay(50);
}

bool mpuReadAll(int16_t &ax, int16_t &ay, int16_t &az,
                int16_t &gx, int16_t &gy, int16_t &gz) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(0x3B);
  if (Wire.endTransmission(false) != 0) return false;
  uint8_t n = Wire.requestFrom((int)MPU_ADDR, 14);
  if (n < 14) return false;
  ax = (Wire.read() << 8) | Wire.read();
  ay = (Wire.read() << 8) | Wire.read();
  az = (Wire.read() << 8) | Wire.read();
  Wire.read(); Wire.read();  // temperatura (descarta)
  gx = (Wire.read() << 8) | Wire.read();
  gy = (Wire.read() << 8) | Wire.read();
  gz = (Wire.read() << 8) | Wire.read();
  return true;
}

// --------------- Conectividade ---------------
void connectWiFi() {
  if (WiFi.status() == WL_CONNECTED) return;
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  Serial.print("Conectando ao WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.print("\nWiFi OK. IP: ");
  Serial.println(WiFi.localIP());
}

bool ensureMqtt() {
  if (mqtt.connected()) return true;
  Serial.print("Conectando MQTT...");
  String clientId = "esp32imucal2-" + String((uint32_t)ESP.getEfuseMac(), HEX);
  clientId.toUpperCase();
  if (clientId.length() > 23) clientId = clientId.substring(0, 23);
  bool ok = mqtt.connect(clientId.c_str(), TOPIC_STATUS, 0, true, "offline");
  if (ok) {
    Serial.println("conectado.");
    mqtt.subscribe(TOPIC_CMD);
    mqtt.publish(TOPIC_STATUS, "online", true);
    return true;
  }
  Serial.print("falhou (rc=");
  Serial.print(mqtt.state());
  Serial.println(").");
  return false;
}

void publishResult(const char* status, JsonDocument& payload) {
  payload["status"] = status;
  char buf[900];
  serializeJson(payload, buf, sizeof(buf));
  mqtt.publish(TOPIC_RESULT, buf);
  Serial.print("RESULT: ");
  Serial.println(buf);
}

void publishMsg(const char* status, const char* msg) {
  JsonDocument doc;
  doc["msg"] = msg;
  publishResult(status, doc);
}

// --------------- Posicoes ---------------
int posIndex(const String& s) {
  if (s == "xp") return 0;
  if (s == "xn") return 1;
  if (s == "yp") return 2;
  if (s == "yn") return 3;
  if (s == "zp") return 4;
  if (s == "zn") return 5;
  return -1;
}

const char* posLabel(int i) {
  static const char* labels[6] = {"xp", "xn", "yp", "yn", "zp", "zn"};
  return (i >= 0 && i < 6) ? labels[i] : "?";
}

// --------------- Correcao das leituras ---------------
void corrigir(int16_t ax, int16_t ay, int16_t az, int16_t gx, int16_t gy, int16_t gz,
              float cal[6]) {
  const int16_t a[3] = {ax, ay, az};
  const int16_t g[3] = {gx, gy, gz};
  for (int i = 0; i < 3; i++) {
    cal[i]     = (a[i] - accel_offset_lsb[i]) / accel_scale_lsb[i];   // g
    cal[i + 3] = (g[i] - gyro_bias_lsb[i]) * LSB_TO_RADPS;            // rad/s
  }
}

// --------------- Inicio / fim das coletas ---------------
void iniciarColeta(Modo m, int n, int pos) {
  modo = m; n_alvo = n; n_ok = 0; n_falha = 0; pos_atual = pos;
  for (int i = 0; i < 3; i++) { soma[i] = 0; soma2[i] = 0; }
  t_inicio_ms = millis();
  t_prox_us = micros();
  JsonDocument doc;
  doc["coleta"] = (m == COLETA_GIRO) ? "gyro_bias" : posLabel(pos);
  doc["n"] = n;
  doc["duracao_s"] = n * (TS_COLETA_US / 1e6);
  publishResult("coleta_iniciada", doc);
}

void finalizarColeta() {
  Modo m = modo;
  modo = OCIOSO;
  if (n_ok < n_alvo / 2) {
    publishMsg("error", "muitas falhas de leitura do MPU (verifique fios/pinos)");
    return;
  }
  float media[3], dp[3];
  for (int i = 0; i < 3; i++) {
    media[i] = soma[i] / n_ok;
    double var = soma2[i] / n_ok - (double)media[i] * media[i];
    dp[i] = var > 0 ? sqrt(var) : 0;
  }
  JsonDocument doc;
  doc["amostras"] = n_ok;
  doc["falhas"] = n_falha;
  doc["dt_ms"] = millis() - t_inicio_ms;
  if (m == COLETA_GIRO) {
    for (int i = 0; i < 3; i++) { gyro_bias_lsb[i] = media[i]; gyro_std_lsb[i] = dp[i]; }
    gyro_bias_done = true;
    doc["bias_p_radps"] = media[0] * LSB_TO_RADPS;
    doc["bias_q_radps"] = media[1] * LSB_TO_RADPS;
    doc["bias_r_radps"] = media[2] * LSB_TO_RADPS;
    doc["std_p_radps"]  = dp[0] * LSB_TO_RADPS;
    doc["std_q_radps"]  = dp[1] * LSB_TO_RADPS;
    doc["std_r_radps"]  = dp[2] * LSB_TO_RADPS;
    publishResult("gyro_bias_ok", doc);
  } else {
    AccelPos &p = accel_pos[pos_atual];
    for (int i = 0; i < 3; i++) { p.mean[i] = media[i]; p.sd[i] = dp[i]; }
    p.has = true;
    doc["pos"]   = posLabel(pos_atual);
    doc["ax_g"]  = media[0] / ACCEL_LSB_PER_G;
    doc["ay_g"]  = media[1] / ACCEL_LSB_PER_G;
    doc["az_g"]  = media[2] / ACCEL_LSB_PER_G;
    doc["sd_ax_g"] = dp[0] / ACCEL_LSB_PER_G;
    doc["sd_ay_g"] = dp[1] / ACCEL_LSB_PER_G;
    doc["sd_az_g"] = dp[2] / ACCEL_LSB_PER_G;
    publishResult("accel_pos_ok", doc);
  }
}

void passoColeta() {
  if ((int32_t)(micros() - t_prox_us) < 0) return;
  t_prox_us += TS_COLETA_US;
  int16_t ax, ay, az, gx, gy, gz;
  if (mpuReadAll(ax, ay, az, gx, gy, gz)) {
    float v[3];
    if (modo == COLETA_GIRO) { v[0] = gx; v[1] = gy; v[2] = gz; }
    else                     { v[0] = ax; v[1] = ay; v[2] = az; }
    for (int i = 0; i < 3; i++) { soma[i] += v[i]; soma2[i] += (double)v[i] * v[i]; }
    n_ok++;
  } else {
    n_falha++;
  }
  if (n_ok + n_falha >= n_alvo) finalizarColeta();
}

void passoStream() {
  if (millis() >= t_fim_stream_ms) {
    modo = OCIOSO;
    publishMsg("stream_fim", "stream encerrado");
    return;
  }
  if ((int32_t)(micros() - t_prox_us) < 0) return;
  t_prox_us += TS_STREAM_US;
  int16_t ax, ay, az, gx, gy, gz;
  if (!mpuReadAll(ax, ay, az, gx, gy, gz)) return;
  float cal[6];
  corrigir(ax, ay, az, gx, gy, gz, cal);
  char buf[300];
  snprintf(buf, sizeof(buf),
           "{\"t\":%lu,\"raw\":[%.5f,%.5f,%.5f,%.6f,%.6f,%.6f],"
           "\"cal\":[%.5f,%.5f,%.5f,%.6f,%.6f,%.6f],\"phi\":%.3f}",
           (unsigned long)(millis() - t_inicio_ms),
           ax / ACCEL_LSB_PER_G, ay / ACCEL_LSB_PER_G, az / ACCEL_LSB_PER_G,
           gx * LSB_TO_RADPS, gy * LSB_TO_RADPS, gz * LSB_TO_RADPS,
           cal[0], cal[1], cal[2], cal[3], cal[4], cal[5],
           atan2f(cal[1], cal[2]) * 180.0f / 3.14159265f);
  mqtt.publish(TOPIC_STREAM, buf);
}

// --------------- Offsets e escalas do acelerometro ---------------
void computeAccel() {
  for (int i = 0; i < 6; i++) {
    if (!accel_pos[i].has) {
      JsonDocument doc;
      doc["msg"] = "faltam posicoes do acel";
      doc["missing"] = posLabel(i);
      publishResult("error", doc);
      return;
    }
  }
  // eixo i: posicao + = indice 2i, posicao - = indice 2i+1
  for (int i = 0; i < 3; i++) {
    float mais  = accel_pos[2 * i].mean[i];
    float menos = accel_pos[2 * i + 1].mean[i];
    accel_offset_lsb[i] = (mais + menos) / 2.0f;
    accel_scale_lsb[i]  = (mais - menos) / 2.0f;   // LSB por 1 g
  }
  bool ok = true;
  for (int i = 0; i < 3; i++) {
    float r = accel_scale_lsb[i] / ACCEL_LSB_PER_G;
    if (r < 0.8f || r > 1.2f) ok = false;          // posicao trocada ou sensor errado
  }
  JsonDocument doc;
  doc["off_x_g"] = accel_offset_lsb[0] / ACCEL_LSB_PER_G;
  doc["off_y_g"] = accel_offset_lsb[1] / ACCEL_LSB_PER_G;
  doc["off_z_g"] = accel_offset_lsb[2] / ACCEL_LSB_PER_G;
  doc["esc_x"]   = accel_scale_lsb[0] / ACCEL_LSB_PER_G;   // 1.0 = nominal
  doc["esc_y"]   = accel_scale_lsb[1] / ACCEL_LSB_PER_G;
  doc["esc_z"]   = accel_scale_lsb[2] / ACCEL_LSB_PER_G;
  if (!ok) {
    for (int i = 0; i < 3; i++) { accel_offset_lsb[i] = 0; accel_scale_lsb[i] = ACCEL_LSB_PER_G; }
    accel_cal_done = false;
    doc["msg"] = "escala fora de [0.8, 1.2]: confira as posicoes e repita";
    publishResult("error", doc);
    return;
  }
  accel_cal_done = true;
  publishResult("accel_cal_ok", doc);
}

// --------------- NVS ---------------
void nvsSave() {
  prefs.begin("imucal", false);
  prefs.putFloat("gbx", gyro_bias_lsb[0]);
  prefs.putFloat("gby", gyro_bias_lsb[1]);
  prefs.putFloat("gbz", gyro_bias_lsb[2]);
  prefs.putFloat("gsx", gyro_std_lsb[0]);
  prefs.putFloat("gsy", gyro_std_lsb[1]);
  prefs.putFloat("gsz", gyro_std_lsb[2]);
  prefs.putBool("gbok", gyro_bias_done);
  prefs.putFloat("aox", accel_offset_lsb[0]);
  prefs.putFloat("aoy", accel_offset_lsb[1]);
  prefs.putFloat("aoz", accel_offset_lsb[2]);
  prefs.putFloat("asx", accel_scale_lsb[0]);
  prefs.putFloat("asy", accel_scale_lsb[1]);
  prefs.putFloat("asz", accel_scale_lsb[2]);
  prefs.putBool("aook", accel_cal_done);
  prefs.end();
  publishMsg("saved", "calibracao gravada em NVS");
}

void nvsLoad() {
  prefs.begin("imucal", true);
  gyro_bias_done = prefs.getBool("gbok", false);
  gyro_bias_lsb[0] = prefs.getFloat("gbx", 0);
  gyro_bias_lsb[1] = prefs.getFloat("gby", 0);
  gyro_bias_lsb[2] = prefs.getFloat("gbz", 0);
  gyro_std_lsb[0]  = prefs.getFloat("gsx", 0);
  gyro_std_lsb[1]  = prefs.getFloat("gsy", 0);
  gyro_std_lsb[2]  = prefs.getFloat("gsz", 0);
  accel_cal_done = prefs.getBool("aook", false);
  accel_offset_lsb[0] = prefs.getFloat("aox", 0);
  accel_offset_lsb[1] = prefs.getFloat("aoy", 0);
  accel_offset_lsb[2] = prefs.getFloat("aoz", 0);
  accel_scale_lsb[0]  = prefs.getFloat("asx", ACCEL_LSB_PER_G);
  accel_scale_lsb[1]  = prefs.getFloat("asy", ACCEL_LSB_PER_G);
  accel_scale_lsb[2]  = prefs.getFloat("asz", ACCEL_LSB_PER_G);
  prefs.end();
  // NVS sem escala gravada: garante valor nominal
  for (int i = 0; i < 3; i++)
    if (accel_scale_lsb[i] < 1000.0f) accel_scale_lsb[i] = ACCEL_LSB_PER_G;
}

void nvsReset() {
  prefs.begin("imucal", false);
  prefs.clear();
  prefs.end();
  gyro_bias_done = false;
  accel_cal_done = false;
  for (int i = 0; i < 3; i++) {
    gyro_bias_lsb[i] = 0; gyro_std_lsb[i] = 0;
    accel_offset_lsb[i] = 0; accel_scale_lsb[i] = ACCEL_LSB_PER_G;
  }
  for (int i = 0; i < 6; i++) accel_pos[i].has = false;
  publishMsg("reset", "NVS e RAM limpas");
}

void publishShow() {
  JsonDocument doc;
  doc["gyro_done"]  = gyro_bias_done;
  doc["accel_done"] = accel_cal_done;
  doc["bias_p_radps"] = gyro_bias_lsb[0] * LSB_TO_RADPS;
  doc["bias_q_radps"] = gyro_bias_lsb[1] * LSB_TO_RADPS;
  doc["bias_r_radps"] = gyro_bias_lsb[2] * LSB_TO_RADPS;
  doc["std_p_radps"]  = gyro_std_lsb[0] * LSB_TO_RADPS;
  doc["std_q_radps"]  = gyro_std_lsb[1] * LSB_TO_RADPS;
  doc["std_r_radps"]  = gyro_std_lsb[2] * LSB_TO_RADPS;
  doc["off_x_g"] = accel_offset_lsb[0] / ACCEL_LSB_PER_G;
  doc["off_y_g"] = accel_offset_lsb[1] / ACCEL_LSB_PER_G;
  doc["off_z_g"] = accel_offset_lsb[2] / ACCEL_LSB_PER_G;
  doc["esc_x"]   = accel_scale_lsb[0] / ACCEL_LSB_PER_G;
  doc["esc_y"]   = accel_scale_lsb[1] / ACCEL_LSB_PER_G;
  doc["esc_z"]   = accel_scale_lsb[2] / ACCEL_LSB_PER_G;
  JsonArray pos = doc["posicoes_ram"].to<JsonArray>();
  for (int i = 0; i < 6; i++) if (accel_pos[i].has) pos.add(posLabel(i));
  publishResult("show", doc);
}

// --------------- Comandos ---------------
void onMsg(char* topic, byte* payload, unsigned int length) {
  if (String(topic) != String(TOPIC_CMD)) return;
  String cmd;
  cmd.reserve(length + 1);
  for (unsigned int i = 0; i < length; i++) cmd += (char)payload[i];
  cmd.trim();
  Serial.print("CMD: "); Serial.println(cmd);

  if (cmd == "stop") {
    modo = OCIOSO;
    publishMsg("parado", "coleta/stream interrompido");
    return;
  }
  if (modo != OCIOSO) {
    publishMsg("ocupado", "aguarde o fim da coleta/stream ou envie stop");
    return;
  }
  if (cmd == "gyro_bias") {
    iniciarColeta(COLETA_GIRO, N_GYRO, -1);
  } else if (cmd.startsWith("accel ")) {
    String p = cmd.substring(6); p.trim();
    int idx = posIndex(p);
    if (idx < 0) publishMsg("error", "posicao invalida (use xp,xn,yp,yn,zp,zn)");
    else iniciarColeta(COLETA_ACEL, N_ACCEL, idx);
  } else if (cmd == "compute") {
    computeAccel();
  } else if (cmd == "save") {
    nvsSave();
  } else if (cmd == "show") {
    publishShow();
  } else if (cmd == "reset") {
    nvsReset();
  } else if (cmd.startsWith("stream")) {
    int s = cmd.length() > 6 ? cmd.substring(6).toInt() : 30;
    if (s < 1 || s > 120) s = 30;
    modo = STREAM;
    t_inicio_ms = millis();
    t_fim_stream_ms = t_inicio_ms + (uint32_t)s * 1000UL;
    t_prox_us = micros();
    JsonDocument doc;
    doc["duracao_s"] = s;
    doc["usa_calibracao_gyro"] = gyro_bias_done;
    doc["usa_calibracao_accel"] = accel_cal_done;
    publishResult("stream_inicio", doc);
  } else {
    publishMsg("error", "comando desconhecido");
  }
}

void setup() {
  Serial.begin(115200);
  delay(200);
  for (int i = 0; i < 6; i++) accel_pos[i].has = false;
  mpuBegin();
  nvsLoad();
  connectWiFi();
  mqtt.setServer(BROKER_IP, BROKER_PORT);
  mqtt.setCallback(onMsg);
  mqtt.setBufferSize(1024);
  Serial.println("CalibracaoIMU_v2 pronto (SDA=13, SCL=14). Comandos em lab/esp32/calib/cmd.");
}

void loop() {
  if (WiFi.status() != WL_CONNECTED) connectWiFi();
  if (!mqtt.connected()) ensureMqtt();
  mqtt.loop();
  if (modo == COLETA_GIRO || modo == COLETA_ACEL) passoColeta();
  else if (modo == STREAM) passoStream();
}
