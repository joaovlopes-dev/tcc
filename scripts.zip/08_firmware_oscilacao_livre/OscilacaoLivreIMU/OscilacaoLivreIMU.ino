#include <WiFi.h>
#include <Wire.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <Preferences.h>
#include <ESP32Servo.h>
#include <math.h>

//================= AJUSTES =================
const char* WIFI_SSID   = "SEU_WIFI";
const char* WIFI_PASS   = "SUA_SENHA";
const char* BROKER_IP   = "IP_DO_BROKER";
const uint16_t BROKER_PORT = 1883;

const char* TOPIC_START  = "lab/esp32/control/start";
const char* TOPIC_HB     = "lab/esp32/heartbeat";
const char* TOPIC_CMD    = "lab/esp32/openloop/cmd";
const char* TOPIC_TELEM  = "lab/esp32/openloop/telemetry";
const char* TOPIC_STATE  = "lab/esp32/openloop/state";
const char* TOPIC_STATUS = "lab/esp32/status";

const int I2C_SDA = 13;
const int I2C_SCL = 14;
const uint8_t MPU_ADDR = 0x68;

const int PINO_MOTOR[4] = {25, 26, 27, 33};   // M1 traseiro, M2 esq., M3 diant., M4 dir.
const int ESC_MIN_US = 1000;
const int ESC_MAX_US = 2000;
const int PWM_ZONA_MORTA_US = 1040;          // abaixo disso o conjunto não gera empuxo

// Curva de empuxo medida (eq:ajuste_empuxo): T = A*PWM^2 + B*PWM + C [N], PWM em us
const float CURVA_A = 3.597e-6f;
const float CURVA_B = -6.182e-3f;
const float CURVA_C = 2.723f;
const float T_MAX_N = 4.71f;                  // empuxo a 2000 us
const float T0_N    = 2.35f;                  // ponto de operação (PWM0 ~ 1657 us)

const uint32_t TS_US      = 5000;             // eq:Ts_final
const float    TS_S       = 0.005f;
const uint32_t RAMPA_MS   = 2000;             // rampa até T0 ao armar
const uint32_t DUR_MAX_MS = 2000;             // duração máxima de um degrau
const float    U1_MAX_N   = 1.0f;             // limites dos comandos (antes da saturação)
const float    U2_MAX_N   = 2.0f;
const uint32_t HB_TIMEOUT_MS = 500;
const int      FALHAS_IMU_MAX = 20;           // 100 ms

const float TAU_INICIAL_S = 1.0f;             // tau_c inicial (alpha = 0,995)

const int   N_BIAS_BOOT = 600;                // 3 s a 200 Hz
const float BIAS_STD_MAX_RADPS  = 0.005f;     // acima disso houve movimento
const float BIAS_DIF_MAX_RADPS  = 0.03f;      // divergência máxima em relação à NVS

const float GYRO_LSB_PER_DPS = 65.5f;         // +-500 dps
const float GYRO_LSB_NVS     = 131.0f;        // escala em que a NVS foi gravada (+-250 dps)
const float SINAL_ROLL       = 1.0f;          // +1 ou -1: sentido positivo de roll
const float ACCEL_LSB_PER_G  = 16384.0f;      // +-2 g
const float LSB_TO_RADPS     = (3.14159265f / 180.0f) / GYRO_LSB_PER_DPS;
const float RAD2DEG          = 57.2957795f;
//===========================================

WiFiClient   espClient;
PubSubClient mqtt(espClient);
Preferences  prefs;
// Sem objetos Servo: nenhum PWM é gerado neste firmware.

// ---------------- Calibração (LSB) ----------------
float gyro_bias_nvs[3] = {0, 0, 0};
float gyro_bias_lsb[3] = {0, 0, 0};
bool  gyro_nvs_ok = false;
float acc_off_lsb[3]   = {0, 0, 0};
float acc_esc_lsb[3]   = {ACCEL_LSB_PER_G, ACCEL_LSB_PER_G, ACCEL_LSB_PER_G};
bool  acc_nvs_ok = false;

// ---------------- Comunicação entre núcleos ----------------
enum TipoCmd : uint8_t { CMD_ON, CMD_OFF, CMD_STEP_ROLL, CMD_STEP_YAW, CMD_DUB_ROLL, CMD_DUB_YAW, CMD_U0,
                         CMD_ALPHA, CMD_ZERO, CMD_BIAS };
struct Comando { TipoCmd tipo; float valor; uint32_t dur_ms; };

struct Amostra {
  uint32_t t;
  float phi, phi_a, phi_g, psi, p, q, r, ax, ay, az, u1, u2;
  uint16_t pwm[4];
  uint8_t arm;
};

QueueHandle_t filaCmd;     // núcleo 0 -> núcleo 1
QueueHandle_t filaTelem;   // núcleo 1 -> núcleo 0
QueueHandle_t filaEvento;  // núcleo 1 -> núcleo 0 (texto curto)

volatile uint32_t lastHb  = 0;
volatile bool     linkOk  = false;
volatile bool     telemOn = true;
volatile float    alphaAtual = TAU_INICIAL_S / (TAU_INICIAL_S + TS_S);
volatile bool     armadoPub = false;
volatile char     motivoPub[16] = "boot";

struct Evento { char txt[160]; };

// ============================================================
// MPU-6050
// ============================================================
void mpuWrite(uint8_t reg, uint8_t val) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(reg);
  Wire.write(val);
  Wire.endTransmission();
}

void mpuBegin() {
  mpuWrite(0x6B, 0x00);  // PWR_MGMT_1: acorda
  delay(10);
  mpuWrite(0x1A, 0x03);  // DLPF_CFG = 3
  mpuWrite(0x1B, 0x08);  // FS_SEL = 1: +-500 dps
  mpuWrite(0x1C, 0x00);  // +-2 g
}

// Sensor -> corpo. Entradas já calibradas, por eixo do sensor.
// Sensor alinhado com o corpo (x_s = x_c); SINAL_ROLL = -1 se girado 180° em z.
static inline void remapear(const float as[3], const float ws[3], float ac[3], float wc[3]) {
  ac[0] =  as[0];                 wc[0] =  SINAL_ROLL * ws[0];   // p
  ac[1] =  SINAL_ROLL * as[1];    wc[1] =  ws[1];                // q (pitch travado)
  ac[2] =  as[2];                 wc[2] =  ws[2];                // r
}

// Reduz um ângulo [rad] ao intervalo [-pi, pi].
static inline float wrapPi(float x) {
  return atan2f(sinf(x), cosf(x));
}

// Lê acelerômetro e giroscópio (LSB). Retorna false em falha de I2C ou se o
// sensor voltou em sleep (todas as leituras exatamente zero).
bool mpuRead(int16_t a[3], int16_t g[3]) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(0x3B);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom((int)MPU_ADDR, 14) < 14) return false;
  for (int i = 0; i < 3; i++) a[i] = (Wire.read() << 8) | Wire.read();
  Wire.read(); Wire.read();
  for (int i = 0; i < 3; i++) g[i] = (Wire.read() << 8) | Wire.read();
  if (a[0] == 0 && a[1] == 0 && a[2] == 0 && g[0] == 0 && g[1] == 0 && g[2] == 0) {
    mpuBegin();   // acorda de novo; a amostra é descartada
    return false;
  }
  return true;
}

void nvsLoad() {
  prefs.begin("imucal", true);
  gyro_nvs_ok = prefs.getBool("gbok", false);
  const float k = GYRO_LSB_PER_DPS / GYRO_LSB_NVS;   // NVS em +-250 dps -> escala atual
  gyro_bias_nvs[0] = prefs.getFloat("gbx", 0) * k;
  gyro_bias_nvs[1] = prefs.getFloat("gby", 0) * k;
  gyro_bias_nvs[2] = prefs.getFloat("gbz", 0) * k;
  acc_nvs_ok = prefs.getBool("aook", false);
  acc_off_lsb[0] = prefs.getFloat("aox", 0);
  acc_off_lsb[1] = prefs.getFloat("aoy", 0);
  acc_off_lsb[2] = prefs.getFloat("aoz", 0);
  acc_esc_lsb[0] = prefs.getFloat("asx", ACCEL_LSB_PER_G);
  acc_esc_lsb[1] = prefs.getFloat("asy", ACCEL_LSB_PER_G);
  acc_esc_lsb[2] = prefs.getFloat("asz", ACCEL_LSB_PER_G);
  prefs.end();
  for (int i = 0; i < 3; i++) {
    if (acc_esc_lsb[i] < 1000.0f) acc_esc_lsb[i] = ACCEL_LSB_PER_G;
    gyro_bias_lsb[i] = gyro_bias_nvs[i];
  }
}

// ============================================================
// Mapeamento u -> T_i -> PWM (eq:T13_map a eq:T4_map, eq:T_sat, eq:pwm_inversa)
// ============================================================
int pwmDeEmpuxo(float T) {
  if (T <= 0.0f) return ESC_MIN_US;
  if (T >= T_MAX_N) return ESC_MAX_US;
  float disc = CURVA_B * CURVA_B - 4.0f * CURVA_A * (CURVA_C - T);
  if (disc < 0.0f) return PWM_ZONA_MORTA_US;   // abaixo do mínimo do ajuste
  float pwm = (-CURVA_B + sqrtf(disc)) / (2.0f * CURVA_A);
  if (pwm < PWM_ZONA_MORTA_US) pwm = PWM_ZONA_MORTA_US;
  if (pwm > ESC_MAX_US) pwm = ESC_MAX_US;
  return (int)lroundf(pwm);
}

float sat(float x, float lo, float hi) { return x < lo ? lo : (x > hi ? hi : x); }

// T0 = empuxo base (rampa ao armar); preenche pwm[4]
void mapear(float Tbase, float u1, float u2, uint16_t pwm[4]) {
  float T[4];
  T[0] = Tbase - u2 / 4.0f;                 // M1 traseiro
  T[2] = Tbase - u2 / 4.0f;                 // M3 dianteiro
  T[1] = Tbase + u2 / 4.0f - u1 / 2.0f;     // M2 esquerdo
  T[3] = Tbase + u2 / 4.0f + u1 / 2.0f;     // M4 direito
  for (int i = 0; i < 4; i++) pwm[i] = pwmDeEmpuxo(sat(T[i], 0.0f, T_MAX_N));
}

void escreverEscs(const uint16_t pwm[4]) {
  (void)pwm;                                   // ignora o pedido: sem sinal nos ESCs
  for (int i = 0; i < 4; i++) digitalWrite(PINO_MOTOR[i], LOW);
}

void enviarEvento(const char* txt) {
  Evento e;
  strncpy(e.txt, txt, sizeof(e.txt) - 1);
  e.txt[sizeof(e.txt) - 1] = 0;
  xQueueSend(filaEvento, &e, 0);
}

// ============================================================
// Bias do giroscópio no boot / sob comando (núcleo 1, desarmado)
// ============================================================
void medirBiasGiro(const char* origem) {
  double s[3] = {0, 0, 0}, s2[3] = {0, 0, 0};
  int n = 0;
  int16_t a[3], g[3];
  TickType_t t0 = xTaskGetTickCount();
  for (int k = 0; k < N_BIAS_BOOT; k++) {
    if (mpuRead(a, g)) {
      for (int i = 0; i < 3; i++) { s[i] += g[i]; s2[i] += (double)g[i] * g[i]; }
      n++;
    }
    vTaskDelayUntil(&t0, pdMS_TO_TICKS(5));
  }
  char buf[160];
  if (n < N_BIAS_BOOT / 2) {
    snprintf(buf, sizeof(buf), "{\"evento\":\"bias\",\"origem\":\"%s\",\"usado\":\"nvs\",\"motivo\":\"falha_imu\"}", origem);
    enviarEvento(buf);
    return;
  }
  float media[3], dp_max = 0, dif_max = 0;
  for (int i = 0; i < 3; i++) {
    media[i] = s[i] / n;
    float dp = sqrt(fmax(0.0, s2[i] / n - (double)media[i] * media[i])) * LSB_TO_RADPS;
    dp_max = fmaxf(dp_max, dp);
    dif_max = fmaxf(dif_max, fabsf(media[i] - gyro_bias_nvs[i]) * LSB_TO_RADPS);
  }
  bool ok = dp_max < BIAS_STD_MAX_RADPS && (!gyro_nvs_ok || dif_max < BIAS_DIF_MAX_RADPS);
  if (ok) for (int i = 0; i < 3; i++) gyro_bias_lsb[i] = media[i];
  else    for (int i = 0; i < 3; i++) gyro_bias_lsb[i] = gyro_bias_nvs[i];
  snprintf(buf, sizeof(buf),
           "{\"evento\":\"bias\",\"origem\":\"%s\",\"usado\":\"%s\",\"b\":[%.5f,%.5f,%.5f],\"dp_max\":%.5f,\"dif_nvs\":%.5f}",
           origem, ok ? "boot" : "nvs",
           gyro_bias_lsb[0] * LSB_TO_RADPS, gyro_bias_lsb[1] * LSB_TO_RADPS,
           gyro_bias_lsb[2] * LSB_TO_RADPS, dp_max, dif_max);
  enviarEvento(buf);
}

// ============================================================
// Tarefa de controle (núcleo 1, 200 Hz)
// ============================================================
void tarefaControle(void*) {
  const uint16_t PWM_DESARMADO[4] = {0, 0, 0, 0};
  escreverEscs(PWM_DESARMADO);
  medirBiasGiro("boot");        // ESCs sem sinal

  bool armado = false;
  uint32_t t_arm_ms = 0;
  float u1 = 0, u2 = 0;
  uint32_t t_fim_degrau = 0, t_inverte = 0;
  bool em_degrau = false, dublete = false;
  float phi = 0, phi_g = 0, psi = 0;
  bool phi_init = false;
  int falhas = 0;
  uint8_t div = 0;
  uint16_t pwm[4] = {0, 0, 0, 0};

  auto desarmar = [&](const char* motivo) {
    bool estava = armado;
    armado = false; em_degrau = false; dublete = false; u1 = u2 = 0;
    for (int i = 0; i < 4; i++) pwm[i] = 0;
    escreverEscs(pwm);
    armadoPub = false;
    strncpy((char*)motivoPub, motivo, sizeof(motivoPub) - 1);
    if (estava) {
      char buf[96];
      snprintf(buf, sizeof(buf), "{\"evento\":\"desarmado\",\"motivo\":\"%s\"}", motivo);
      enviarEvento(buf);
    }
  };

  TickType_t ultimo = xTaskGetTickCount();
  for (;;) {
    vTaskDelayUntil(&ultimo, pdMS_TO_TICKS(5));
    uint32_t agora = millis();

    // ---------- comandos ----------
    Comando c;
    while (xQueueReceive(filaCmd, &c, 0) == pdTRUE) {
      char buf[128];
      switch (c.tipo) {
        case CMD_ON:   // firmware sem motores: nunca arma
          enviarEvento("{\"evento\":\"recusado\",\"motivo\":\"firmware de oscilacao livre, motores sem sinal\"}");
          break;
        case CMD_OFF:
          desarmar("painel");
          break;
        case CMD_STEP_ROLL:
        case CMD_STEP_YAW:
        case CMD_DUB_ROLL:
        case CMD_DUB_YAW: {
          if (!armado || agora - t_arm_ms < RAMPA_MS) {
            enviarEvento("{\"evento\":\"recusado\",\"motivo\":\"desarmado ou em rampa\"}");
            break;
          }
          bool roll = (c.tipo == CMD_STEP_ROLL || c.tipo == CMD_DUB_ROLL);
          dublete = (c.tipo == CMD_DUB_ROLL || c.tipo == CMD_DUB_YAW);
          if (roll) { u1 = sat(c.valor, -U1_MAX_N, U1_MAX_N); u2 = 0; }
          else      { u2 = sat(c.valor, -U2_MAX_N, U2_MAX_N); u1 = 0; }
          uint32_t fase = dublete ? (c.dur_ms > DUR_MAX_MS / 2 ? DUR_MAX_MS / 2 : c.dur_ms)
                                  : (c.dur_ms > DUR_MAX_MS ? DUR_MAX_MS : c.dur_ms);
          t_inverte = agora + fase;
          t_fim_degrau = agora + (dublete ? 2 * fase : fase);
          em_degrau = true;
          snprintf(buf, sizeof(buf), "{\"evento\":\"%s\",\"u1\":%.3f,\"u2\":%.3f,\"ms\":%lu}",
                   dublete ? "dublete" : "degrau", u1, u2, (unsigned long)fase);
          enviarEvento(buf);
          break;
        }
        case CMD_U0:
          u1 = u2 = 0; em_degrau = false; dublete = false;
          break;
        case CMD_ALPHA:
          alphaAtual = c.valor;
          snprintf(buf, sizeof(buf), "{\"evento\":\"alpha\",\"alpha\":%.5f,\"tau_s\":%.4f}",
                   c.valor, c.valor * TS_S / (1.0f - c.valor));
          enviarEvento(buf);
          break;
        case CMD_ZERO:
          psi = 0; phi = wrapPi(phi); phi_g = phi;
          enviarEvento("{\"evento\":\"zero\"}");
          break;
        case CMD_BIAS:
          if (armado) enviarEvento("{\"evento\":\"recusado\",\"motivo\":\"bias so desarmado\"}");
          else { medirBiasGiro("comando"); ultimo = xTaskGetTickCount(); }
          break;
      }
    }

    // ---------- segurança ----------
    if (armado) {
      if (!linkOk) desarmar("link");
      else if (agora - lastHb > HB_TIMEOUT_MS) desarmar("heartbeat");
    }

    // ---------- IMU e filtro ----------
    int16_t a[3], g[3];
    if (!mpuRead(a, g)) {
      if (++falhas >= FALHAS_IMU_MAX && armado) desarmar("imu");
      continue;
    }
    falhas = 0;
    float as[3], ws[3], ac[3], w[3];
    for (int i = 0; i < 3; i++) {
      as[i] = (a[i] - acc_off_lsb[i]) / acc_esc_lsb[i];          // g, eixos do sensor
      ws[i] = (g[i] - gyro_bias_lsb[i]) * LSB_TO_RADPS;          // rad/s, eixos do sensor
    }
    remapear(as, ws, ac, w);                                      // corpo: ac[], w = (p, q, r)
    float phi_a = atan2f(ac[1], ac[2]);                           // eq:phi_acel, em [-pi, pi]
    if (!phi_init) { phi = phi_g = phi_a; phi_init = true; }
    float al = alphaAtual;
    // eq:complementar escrita como predição + correção. A diferença entre a
    // medida do acelerômetro e a predição é reduzida a [-pi, pi], de modo que
    // o filtro não "puxa" phi por 360° quando atan2 salta entre +pi e -pi.
    float phi_pred = phi + w[0] * TS_S;
    phi   = phi_pred + (1.0f - al) * wrapPi(phi_a - phi_pred);
    phi_a = phi + wrapPi(phi_a - phi);                            // mesmo ramo de phi (telemetria)
    phi_g = phi_g + w[0] * TS_S;                                  // só giroscópio
    psi   = psi + w[2] * TS_S;                                    // eq:complementar_yaw

    // ---------- excitação e motores ----------
    if (em_degrau && dublete && (int32_t)(agora - t_inverte) >= 0) {
      u1 = -u1; u2 = -u2; dublete = false;      // segunda metade do dublete
    }
    if (em_degrau && (int32_t)(agora - t_fim_degrau) >= 0) {
      u1 = u2 = 0; em_degrau = false;
      enviarEvento("{\"evento\":\"fim_degrau\"}");
    }
    if (armado) {
      uint32_t dt = agora - t_arm_ms;
      float Tbase = dt < RAMPA_MS ? T0_N * dt / (float)RAMPA_MS : T0_N;
      mapear(Tbase, u1, u2, pwm);
    } else {
      for (int i = 0; i < 4; i++) pwm[i] = 0;
    }
    escreverEscs(pwm);

    // ---------- telemetria a 100 Hz ----------
    if (telemOn && (++div & 1)) {
      Amostra s;
      s.t = agora;
      s.phi = phi * RAD2DEG; s.phi_a = phi_a * RAD2DEG; s.phi_g = phi_g * RAD2DEG;
      s.psi = psi * RAD2DEG;
      s.p = w[0]; s.q = w[1]; s.r = w[2];
      s.ax = ac[0]; s.ay = ac[1]; s.az = ac[2];
      s.u1 = u1; s.u2 = u2;
      for (int i = 0; i < 4; i++) s.pwm[i] = pwm[i];
      s.arm = armado;
      xQueueSend(filaTelem, &s, 0);   // se a fila encher, a amostra é perdida
    }
  }
}

// ============================================================
// Comunicação (núcleo 0)
// ============================================================
void publicarEstado(const char* json) {
  mqtt.publish(TOPIC_STATE, json);
  Serial.println(json);
}

void publicarShow() {
  char buf[400];
  float al = alphaAtual;
  snprintf(buf, sizeof(buf),
           "{\"evento\":\"show\",\"armado\":%d,\"motivo_ultimo_desarme\":\"%s\",\"alpha\":%.5f,"
           "\"tau_s\":%.4f,\"T0\":%.3f,\"pwm0\":%d,\"nvs_giro\":%d,\"nvs_acel\":%d,"
           "\"b\":[%.5f,%.5f,%.5f],\"telem\":%d}",
           (int)armadoPub, (const char*)motivoPub, al, al * TS_S / (1.0f - al), T0_N,
           pwmDeEmpuxo(T0_N), (int)gyro_nvs_ok, (int)acc_nvs_ok,
           gyro_bias_lsb[0] * LSB_TO_RADPS, gyro_bias_lsb[1] * LSB_TO_RADPS,
           gyro_bias_lsb[2] * LSB_TO_RADPS, (int)telemOn);
  publicarEstado(buf);
}

void enviarCmd(TipoCmd t, float v = 0, uint32_t ms = 0) {
  Comando c{t, v, ms};
  xQueueSend(filaCmd, &c, 0);
}

void callback(char* topic, byte* payload, unsigned int len) {
  String msg;
  for (unsigned int i = 0; i < len; i++) msg += (char)payload[i];
  msg.trim();
  String tp(topic);

  if (tp == TOPIC_HB) { lastHb = millis(); return; }

  if (tp == TOPIC_START) {
    if (msg.equalsIgnoreCase("on"))  enviarCmd(CMD_ON);   // só arma com heartbeat em dia
    if (msg.equalsIgnoreCase("off")) enviarCmd(CMD_OFF);
    return;
  }
  if (tp != TOPIC_CMD) return;

  msg.toLowerCase();
  float v = 0; unsigned long ms = 0;
  if (msg.startsWith("step_roll") && sscanf(msg.c_str(), "step_roll %f %lu", &v, &ms) == 2 && ms > 0) {
    enviarCmd(CMD_STEP_ROLL, v, ms);
  } else if (msg.startsWith("step_yaw") && sscanf(msg.c_str(), "step_yaw %f %lu", &v, &ms) == 2 && ms > 0) {
    enviarCmd(CMD_STEP_YAW, v, ms);
  } else if (msg.startsWith("dub_roll") && sscanf(msg.c_str(), "dub_roll %f %lu", &v, &ms) == 2 && ms > 0) {
    enviarCmd(CMD_DUB_ROLL, v, ms);
  } else if (msg.startsWith("dub_yaw") && sscanf(msg.c_str(), "dub_yaw %f %lu", &v, &ms) == 2 && ms > 0) {
    enviarCmd(CMD_DUB_YAW, v, ms);
  } else if (msg == "u0") {
    enviarCmd(CMD_U0);
  } else if (msg.startsWith("tau") && sscanf(msg.c_str(), "tau %f", &v) == 1 && v > 0 && v < 100) {
    enviarCmd(CMD_ALPHA, v / (v + TS_S));
  } else if (msg.startsWith("alpha") && sscanf(msg.c_str(), "alpha %f", &v) == 1 && v > 0 && v < 1) {
    enviarCmd(CMD_ALPHA, v);
  } else if (msg == "zero") {
    enviarCmd(CMD_ZERO);
  } else if (msg == "bias") {
    enviarCmd(CMD_BIAS);
  } else if (msg.startsWith("telem")) {
    telemOn = msg.endsWith("1");
    publicarEstado(telemOn ? "{\"evento\":\"telem\",\"on\":1}" : "{\"evento\":\"telem\",\"on\":0}");
  } else if (msg == "show") {
    publicarShow();
  } else {
    publicarEstado("{\"evento\":\"erro\",\"msg\":\"comando desconhecido\"}");
  }
}

bool conectarMqtt() {
  String id = "esp32openloop-" + String((uint32_t)ESP.getEfuseMac(), HEX);
  if (id.length() > 23) id = id.substring(0, 23);
  if (!mqtt.connect(id.c_str(), TOPIC_STATUS, 0, true, "offline")) return false;
  mqtt.subscribe(TOPIC_START);
  mqtt.subscribe(TOPIC_HB);
  mqtt.subscribe(TOPIC_CMD);
  mqtt.publish(TOPIC_STATUS, "online", true);
  publicarShow();
  return true;
}

void publicarAmostra(const Amostra& s) {
  char buf[400];
  snprintf(buf, sizeof(buf),
           "{\"t\":%lu,\"phi\":%.3f,\"phi_a\":%.3f,\"phi_g\":%.3f,\"psi\":%.3f,"
           "\"p\":%.5f,\"q\":%.5f,\"r\":%.5f,\"ax\":%.4f,\"ay\":%.4f,\"az\":%.4f,"
           "\"u1\":%.3f,\"u2\":%.3f,\"pwm\":[%u,%u,%u,%u],\"arm\":%u}",
           (unsigned long)s.t, s.phi, s.phi_a, s.phi_g, s.psi, s.p, s.q, s.r,
           s.ax, s.ay, s.az, s.u1, s.u2,
           s.pwm[0], s.pwm[1], s.pwm[2], s.pwm[3], s.arm);
  mqtt.publish(TOPIC_TELEM, buf);
}

void tarefaComunicacao(void*) {
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.setAutoReconnect(true);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  mqtt.setServer(BROKER_IP, BROKER_PORT);
  mqtt.setCallback(callback);
  mqtt.setBufferSize(1024);
  mqtt.setKeepAlive(2);
  mqtt.setSocketTimeout(1);

  uint32_t ultimaTentativa = 0;
  for (;;) {
    bool wifiOk = WiFi.status() == WL_CONNECTED;
    if (wifiOk && !mqtt.connected() && millis() - ultimaTentativa > 2000) {
      ultimaTentativa = millis();
      Serial.print("MQTT...");
      Serial.println(conectarMqtt() ? "conectado" : "falhou");
    }
    if (mqtt.connected()) mqtt.loop();
    linkOk = wifiOk && mqtt.connected();

    Evento e;
    while (xQueueReceive(filaEvento, &e, 0) == pdTRUE) {
      if (mqtt.connected()) publicarEstado(e.txt);
      else Serial.println(e.txt);
    }
    Amostra s;
    int n = 0;
    while (n < 8 && xQueueReceive(filaTelem, &s, 0) == pdTRUE) {
      if (mqtt.connected()) publicarAmostra(s);
      n++;
    }
    vTaskDelay(pdMS_TO_TICKS(2));
  }
}

// ============================================================
void setup() {
  Serial.begin(115200);
  delay(200);

  // Pinos dos ESCs em nível baixo, sem pulso: os ESCs não armam
  for (int i = 0; i < 4; i++) {
    pinMode(PINO_MOTOR[i], OUTPUT);
    digitalWrite(PINO_MOTOR[i], LOW);
  }

  Wire.begin(I2C_SDA, I2C_SCL, 400000);
  delay(10);
  mpuBegin();
  delay(50);
  nvsLoad();
  Serial.printf("NVS: giro %s, acel %s\n", gyro_nvs_ok ? "ok" : "AUSENTE", acc_nvs_ok ? "ok" : "AUSENTE");

  filaCmd    = xQueueCreate(16, sizeof(Comando));
  filaTelem  = xQueueCreate(64, sizeof(Amostra));
  filaEvento = xQueueCreate(16, sizeof(Evento));

  xTaskCreatePinnedToCore(tarefaComunicacao, "com", 8192, nullptr, 1, nullptr, 0);
  xTaskCreatePinnedToCore(tarefaControle, "ctrl", 8192, nullptr, configMAX_PRIORITIES - 2, nullptr, 1);
  Serial.println("OscilacaoLivreIMU: MOTORES SEM SINAL. Bias do giro sendo medido (3 s, manter imovel).");
}

void loop() {
  vTaskDelete(nullptr);   // tudo roda nas duas tarefas
}
