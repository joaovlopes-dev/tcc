import json
from pathlib import Path

import numpy as np
from scipy.signal import cont2discrete
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

AQUI = Path(__file__).resolve().parent
G5 = json.loads((AQUI / "dados" / "ganhos_pid_v5.json").read_text(encoding="utf-8"))
RJ = json.loads((AQUI / "dados" / "reprojeto_roll_atuador.json").read_text(encoding="utf-8"))
W0Q = G5["w0_quadrado"]; W0 = np.sqrt(W0Q); Z0 = 0.03
T0, TMAX, TS = G5["T0_N"], G5["T_max_N"], 0.005
BPHI, BPSI = RJ["identificacao"]["beta"], G5["beta_psi"]   # beta de projeto do roll (~20, identificação) e nominal do yaw
ESC_KP, ESC_KI, ESC_KD = 1.2, 2.0, 1.0            # ajuste fino em bancada (roll)
FR = 3.0                                          # corte do filtro de r [Hz]
TAU_ID, TD_ID = RJ["identificacao"]["tau_a_s"], RJ["identificacao"]["Td_s"]
MOD = RJ["modelos_atuador"]                       # 4 modelos (tau, Td, beta) do vale de identificação
virg = FuncFormatter(lambda v, _: f"{v:g}".replace(".", ","))
plt.rcParams.update({"font.size": 10, "axes.formatter.use_locale": False})


def f2(x, n=2):
    return f"{x:.{n}f}".replace(".", ",")


# ------------------------------------------------------------------ 1. ganhos
def ganhos(zeta, wn, rho, beta, w0q=0.0):
    Kd = (2 * zeta + rho) * wn / beta
    Kp = ((1 + 2 * zeta * rho) * wn**2 + w0q) / beta
    Ki = rho * wn**3 / beta
    return np.array([Kp, Ki, Kd])


KR_PROJ = ganhos(0.9, 2.0, 0.5, BPHI, W0Q)
KR = KR_PROJ * np.array([ESC_KP, ESC_KI, ESC_KD])
KY = ganhos(0.7, 1.0, 2.0, BPSI)


def polos(K, beta, w0q=0.0):
    Kp, Ki, Kd = K
    return np.roots([1, beta * Kd, beta * Kp - w0q, beta * Ki])


# ------------------------------------------------------------------ 2. malha discreta e margem
def zmax(K, beta, a, tau, Td, amort=True, fr=0.0, ret_eig=False):
    """max|z| de um canal discreto: planta [y, y'(, u_ef)], atuador tau, fila de Td (inclui cálculo),
    integrador de Tustin, filtro de 1ª ordem opcional na velocidade da parcela derivativa."""
    Kp, Ki, Kd = K
    c = 2 * Z0 * W0 if amort else 0.0
    if tau > 0:
        Ac = np.array([[0, 1, 0], [a, -c, beta], [0, 0, -1 / tau]]); Bc = np.array([[0], [0], [1 / tau]])
    else:
        Ac = np.array([[0, 1], [a, -c]]); Bc = np.array([[0], [beta]])
    n = Ac.shape[0]
    Ad, Bd, *_ = cont2discrete((Ac, Bc, np.eye(n), np.zeros((n, 1))), TS, "zoh")
    N = max(1, int(round(Td / TS)))
    af = np.exp(-2 * np.pi * fr * TS) if fr > 0 else 0.0
    # estados: x (n) | e | eprev | vf | fila u (N)
    ie, iep, iv, iu = n, n + 1, n + 2, n + 3
    dim = n + 3 + N
    M = np.zeros((dim, dim))
    M[:n, :n] = Ad; M[:n, iu + N - 1] = Bd[:, 0]
    # e[k+1] = e[k] + Ts/2 (err[k] + err[k-1]),  err = -y (referência nula)
    M[ie, ie] = 1; M[ie, 0] = -TS / 2; M[ie, iep] = TS / 2
    M[iep, 0] = -1                                    # guarda err[k] = -y[k]
    # vf[k+1] = af vf[k] + (1-af) y'[k]
    M[iv, iv] = af; M[iv, 1] = 1 - af
    # u[k] = -Kp y - Kd v + Ki e_novo ; e_novo = e + Ts/2(-y + eprev)
    v_row = np.zeros(dim)
    if fr > 0:
        v_row[iv] = af; v_row[1] = 1 - af             # usa o filtro já atualizado
    else:
        v_row[1] = 1
    urow = -Kp * np.eye(dim)[0] - Kd * v_row + Ki * (np.eye(dim)[ie] - TS / 2 * np.eye(dim)[0] + TS / 2 * np.eye(dim)[iep])
    M[iu] = urow
    for q in range(1, N):
        M[iu + q, iu + q - 1] = 1
    ev = np.linalg.eigvals(M)
    return ev if ret_eig else float(np.max(np.abs(ev)))


def margem(K, beta, a, tau, Td, **kw):
    if zmax(K, beta, a, tau, Td, **kw) >= 1:
        return 0.0
    extra = 0.0
    while extra < 0.3 and zmax(K, beta, a, tau, Td + extra + TS, **kw) < 1:
        extra += TS
    return extra


def pior(K, eixo, fatores=(0.8, 1.0, 1.25), fb=1.0):
    """Pior caso em 4 modelos do atuador x fatores de beta (roll também em phi = 180°)."""
    zs, ms = [], []
    for m in MOD:
        for f in fatores:
            if eixo == "roll":
                for a in (W0Q, -W0Q):
                    b = m["beta"] * f * fb
                    zs.append(zmax(K, b, a, m["tau"], m["Td"] + TS)); ms.append(margem(K, b, a, m["tau"], m["Td"] + TS))
            else:
                b = BPSI * f * fb
                zs.append(zmax(K, b, 0.0, m["tau"], m["Td"] + TS, amort=False, fr=FR))
                ms.append(margem(K, b, 0.0, m["tau"], m["Td"] + TS, amort=False, fr=FR))
    return max(zs), min(ms)


# ------------------------------------------------------------------ 3. simulação temporal
def limita(u1, u2):
    """Prioridade do roll (eq:u1_lim, eq:u2_lim)."""
    lim1 = 2 * min(T0, TMAX - T0)
    u1s = np.clip(u1, -lim1, lim1)
    # u2 na folga restante: T1,3 = T0 - u2/4 ; T2,4 = T0 + u2/4 -+ u1/2
    hi = min(4 * (T0 - 0), 4 * (TMAX - T0 - abs(u1s) / 2))
    lo = max(-4 * (TMAX - T0), -4 * (T0 - abs(u1s) / 2))
    u2s = np.clip(u2, lo, hi)
    return u1s, u2s, u1s != u1, u2s != u2


def simula(KR_, KY_, bphi=BPHI, bpsi=BPSI, ref_phi=10.0, ref_psi=30.0, t_ref=1.0, tf=30.0,
           Ts=0.0, tau=0.0, Td=0.0, fr=0.0, perturb=None, dt=0.001):
    """Planta não linear (sen phi). Ts = 0: controlador contínuo (a cada dt). perturb = (t, N.m roll)."""
    n = int(tf / dt)
    t = np.arange(n) * dt
    x = np.zeros(4)                    # phi, psi, p, r
    e = np.zeros(2); errp = np.zeros(2); rf = 0.0
    u_cmd = np.zeros(2); u_act = np.zeros(2)
    passo = max(1, int(round(Ts / dt))) if Ts > 0 else 1
    h = Ts if Ts > 0 else dt
    nd = int(round(Td / dt))
    fila = [np.zeros(2)] * (nd + 1)
    af = np.exp(-2 * np.pi * fr * h) if fr > 0 else 0.0
    I_XX = 0.212 / bphi                         # inércia coerente com o beta simulado (perturbação)
    out = np.zeros((n, 8))
    for k in range(n):
        rph = np.radians(ref_phi) if t[k] >= t_ref else 0.0
        rps = np.radians(ref_psi) if t[k] >= t_ref else 0.0
        if k % passo == 0:
            rf = af * rf + (1 - af) * x[3] if fr > 0 else x[3]
            err = np.array([rph - x[0], rps - x[1]])
            en = e + h / 2 * (err + errp) if Ts > 0 else e + h * err
            u1 = -KR_[0] * x[0] - KR_[2] * x[2] + KR_[1] * en[0]
            u2 = -KY_[0] * x[1] - KY_[2] * rf + KY_[1] * en[1]
            u1s, u2s, s1, s2 = limita(u1, u2)
            if s1 and err[0] * u1 > 0: en[0] = e[0]
            if s2 and err[1] * u2 > 0: en[1] = e[1]
            e = en; errp = err
            u_cmd = np.array([u1s, u2s])
        fila.append(u_cmd.copy()); ud = fila.pop(0)
        if tau > 0:
            u_act = u_act + dt / tau * (ud - u_act)
        else:
            u_act = ud
        tq = perturb[1] / I_XX if (perturb and t[k] >= perturb[0]) else 0.0
        pd = W0Q * np.sin(x[0]) + bphi * u_act[0] + tq
        rd = bpsi * u_act[1]
        x = x + dt * np.array([x[2], x[3] / np.cos(x[0]), pd, rd])
        out[k] = [t[k], x[0], x[1], x[2], x[3], u_cmd[0], u_cmd[1], 0]
    T = np.c_[T0 - out[:, 6] / 4, T0 + out[:, 6] / 4 - out[:, 5] / 2, T0 - out[:, 6] / 4, T0 + out[:, 6] / 4 + out[:, 5] / 2]
    return out, T


def metricas(t, y, ref, t_ref=1.0, faixa=0.02):
    m = t >= t_ref
    tt, yy = t[m] - t_ref, np.degrees(y[m]) / ref
    i10 = np.argmax(yy >= 0.1); i90 = np.argmax(yy >= 0.9)
    tr = tt[i90] - tt[i10]
    mp = max(0.0, (yy.max() - 1) * 100)
    fora = np.where(np.abs(yy - 1) > faixa)[0]
    ts = tt[fora[-1]] if len(fora) else 0.0
    err = np.radians(ref) - y[m]
    iae = np.trapezoid(np.abs(err), tt); itae = np.trapezoid(tt * np.abs(err), tt)
    return dict(tr=float(tr), Mp=float(mp), ts=float(ts), IAE=float(iae), ITAE=float(itae))


# ------------------------------------------------------------------ 4. polos discretos (ideal)
def polos_discretos(K, beta, w0q, Ts=TS):
    """Malha discreta ideal (sem atuador, sem atraso de cálculo): planta ZOH + Tustin."""
    Ac = np.array([[0, 1], [w0q, 0]]); Bc = np.array([[0], [beta]])
    Ad, Bd, *_ = cont2discrete((Ac, Bc, np.eye(2), np.zeros((2, 1))), Ts, "zoh")
    Kp, Ki, Kd = K
    # estados [y, y', e, eprev]; u[k] = -Kp y - Kd y' + Ki (e + Ts/2(-y + eprev))
    urow = np.array([-Kp - Ki * Ts / 2, -Kd, Ki, Ki * Ts / 2])
    M = np.zeros((4, 4))
    M[:2, :2] = Ad; M[:2] += np.outer(Bd[:, 0], urow)
    M[2] = [-Ts / 2, 0, 1, Ts / 2]; M[3] = [-1, 0, 0, 0]
    ev = np.linalg.eigvals(M)
    return ev[np.abs(ev) > 1e-9]


def main():
    out = {}
    # ---------------- 1
    pr_proj = polos(KR_PROJ, BPHI, W0Q); pr_fin = polos(KR, BPHI, W0Q); py = polos(KY, BPSI)
    def zw(p):
        c = p[np.abs(p.imag) > 1e-9][0]; r = p[np.abs(p.imag) <= 1e-9][0].real
        wn = abs(c); return dict(par=[float(c.real), float(abs(c.imag))], real=float(r), wn=float(wn),
                                  zeta=float(-c.real / wn), rho=float(-r / wn))
    G6 = dict(T0_N=T0, T_max_N=TMAX, Ts=TS, beta_phi_projeto=BPHI, beta_psi=BPSI, w0_quadrado=W0Q,
              roll_projeto=dict(zeta=0.9, wn=2.0, rho=0.5, Kp=KR_PROJ[0], Ki=KR_PROJ[1], Kd=KR_PROJ[2], polos=zw(pr_proj)),
              escalas_ajuste_fino=dict(Kp=ESC_KP, Ki=ESC_KI, Kd=ESC_KD),
              roll=dict(Kp=KR[0], Ki=KR[1], Kd=KR[2], polos=zw(pr_fin)),
              yaw=dict(zeta=0.7, wn=1.0, rho=2.0, Kp=KY[0], Ki=KY[1], Kd=KY[2], filtro_r_Hz=FR, polos=zw(py)))
    (AQUI / "dados" / "ganhos_pid_v6.json").write_text(json.dumps(G6, indent=2, ensure_ascii=False, default=float), encoding="utf-8")
    print("1) ganhos")
    print("   roll projeto", np.round(KR_PROJ, 4), "polos", np.round(pr_proj, 3))
    print("   roll final  ", np.round(KR, 4), "polos", np.round(pr_fin, 3), zw(pr_fin))
    print("   yaw         ", np.round(KY, 4), "polos", np.round(py, 3))
    out["ganhos"] = G6

    # ---------------- 2
    m_proj = pior(KR_PROJ, "roll"); m_fin = pior(KR, "roll"); m_y = pior(KY, "yaw", fatores=(1.0, 1.22, 1.44))
    print(f"2) margem de atraso (pior caso): roll projeto {m_proj[1]*1000:.0f} ms (max|z| {m_proj[0]:.4f}), "
          f"roll final {m_fin[1]*1000:.0f} ms (max|z| {m_fin[0]:.4f}), yaw {m_y[1]*1000:.0f} ms (max|z| {m_y[0]:.4f})")
    out["margem_atraso_ms"] = dict(roll_projeto=m_proj[1] * 1000, roll_final=m_fin[1] * 1000, yaw=m_y[1] * 1000)
    # figura da escolha (varredura da reprojeto, cenário 50 Hz)
    V = RJ["varredura"]
    fig, axs = plt.subplots(1, 3, figsize=(10, 3.3), sharey=True)
    cores = {0.5: "C0", 1.0: "C1", 1.5: "C2", 2.0: "C3", 3.0: "C4"}
    for ax, zeta in zip(axs, (0.5, 0.7, 0.9)):
        for rho, cor in cores.items():
            pts = sorted([(v["wn"], v["50 Hz (atual)"]["margem_atraso_s"] * 1000) for v in V if v["zeta"] == zeta and v["rho"] == rho])
            ax.plot(*zip(*pts), "o-", ms=3, color=cor, label=f"ρ = {f2(rho,1)}")
        ax.set_title(f"ζ = {f2(zeta,1)}"); ax.set_xlabel("ω$_n$ [rad/s]"); ax.grid(alpha=.3)
        ax.xaxis.set_major_formatter(virg)
        if zeta == 0.9:
            ax.plot(2.0, m_proj[1] * 1000, "k*", ms=12, label="escolha")
    axs[0].set_ylabel("margem de atraso [ms]"); axs[2].legend(fontsize=8)
    fig.tight_layout(); fig.savefig(AQUI / "graficos" / "escolha_roll_margem_v6.png", dpi=200); plt.close(fig)

    # ---------------- 3
    sims = {}
    cfg = {"continua": dict(Ts=0.0), "discreta": dict(Ts=TS),
           "atuador": dict(Ts=TS, tau=TAU_ID, Td=TD_ID + TS, fr=FR)}
    for nome, c in cfg.items():
        o, T = simula(KR, KY, **c)
        mr = metricas(o[:, 0], o[:, 1], 10.0); my = metricas(o[:, 0], o[:, 2], 30.0)
        sims[nome] = dict(o=o, T=T, roll=mr, yaw=my, Tmin=float(T.min()), Tmax=float(T.max()),
                          u1max=float(np.abs(o[:, 5]).max()), u2max=float(np.abs(o[:, 6]).max()),
                          u1_final=float(o[-1, 5]))
        print(f"3{nome[0]}) {nome:9s} roll t_r {mr['tr']:.2f} Mp {mr['Mp']:.1f} t_s {mr['ts']:.2f} IAE {mr['IAE']:.4f} ITAE {mr['ITAE']:.4f}"
              f" | yaw t_r {my['tr']:.2f} Mp {my['Mp']:.1f} t_s {my['ts']:.2f} IAE {my['IAE']:.4f} ITAE {my['ITAE']:.4f}"
              f" | T [{T.min():.2f}, {T.max():.2f}] |u1| {sims[nome]['u1max']:.3f} |u2| {sims[nome]['u2max']:.3f}")
    out["simulacoes"] = {k: {kk: vv for kk, vv in v.items() if kk not in ("o", "T")} for k, v in sims.items()}
    dif = {k: float(np.degrees(np.abs(sims["continua"]["o"][:, i] - sims["discreta"]["o"][:, i]).max())) for k, i in (("roll", 1), ("yaw", 2))}
    out["dif_continua_discreta_graus"] = dif
    print("   max diferença contínua x discreta [°]", dif)
    # séries para comparação com o ensaio (degrau isolado, a partir do comando)
    o = sims["atuador"]["o"]
    np.savez(AQUI / "dados" / "simulacao_controlador_final_series.npz", t=o[:, 0] - 1.0, phi=np.degrees(o[:, 1]) / 10.0,
             psi=np.degrees(o[:, 2]) / 30.0, t_id=sims["discreta"]["o"][:, 0] - 1.0,
             phi_id=np.degrees(sims["discreta"]["o"][:, 1]) / 10.0, psi_id=np.degrees(sims["discreta"]["o"][:, 2]) / 30.0)

    # figuras: resposta contínua + polos, empuxos, contínua x discreta x atuador
    oc, Tc = sims["continua"]["o"], sims["continua"]["T"]
    fig, axs = plt.subplots(2, 2, figsize=(10, 6.5))
    for ax, i, ref, nome in ((axs[0, 0], 1, 10, "φ"), (axs[0, 1], 2, 30, "ψ")):
        ax.plot(oc[:, 0], np.degrees(oc[:, i]), lw=1.5, label=nome)
        ax.axhline(ref, ls="--", color="k", lw=.8, label="referência")
        ax.axhspan(ref * .98, ref * 1.02, color="gray", alpha=.25, label="±2 %")
        ax.set_xlabel("t [s]"); ax.set_ylabel(f"{nome} [°]"); ax.grid(alpha=.3); ax.legend(fontsize=8)
        ax.xaxis.set_major_formatter(virg); ax.yaxis.set_major_formatter(virg)
    for ax, p, nome in ((axs[1, 0], pr_fin, "roll"), (axs[1, 1], py, "yaw")):
        ax.plot(p.real, p.imag, "x", ms=10, mew=2); ax.axvline(0, color="k", lw=.8); ax.axhline(0, color="k", lw=.8)
        ax.set_xlabel("Re(s) [rad/s]"); ax.set_ylabel("Im(s) [rad/s]"); ax.set_title(f"Polos de malha fechada, {nome}")
        ax.grid(alpha=.3); ax.xaxis.set_major_formatter(virg); ax.yaxis.set_major_formatter(virg)
    fig.tight_layout(); fig.savefig(AQUI / "graficos" / "resposta_pid_v6.png", dpi=200); plt.close(fig)

    fig, axs = plt.subplots(1, 2, figsize=(10, 3.6))
    axs[0].plot(oc[:, 0], oc[:, 5], label="$u_1$"); axs[0].plot(oc[:, 0], oc[:, 6], label="$u_2$")
    axs[0].set_ylabel("entrada [N]")
    for j in range(4):
        axs[1].plot(oc[:, 0], Tc[:, j], label=f"$T_{j+1}$")
    for v, l in ((0, "0"), (TMAX, "$T_{max}$"), (T0, "$T_0$")):
        axs[1].axhline(v, ls=":", color="k", lw=.8)
    axs[1].set_ylabel("empuxo [N]")
    for ax in axs:
        ax.set_xlabel("t [s]"); ax.grid(alpha=.3); ax.legend(fontsize=8); ax.xaxis.set_major_formatter(virg); ax.yaxis.set_major_formatter(virg)
    fig.tight_layout(); fig.savefig(AQUI / "graficos" / "empuxos_pid_v6.png", dpi=200); plt.close(fig)

    fig, axs = plt.subplots(2, 2, figsize=(10, 6.5), sharex=True)
    for nome, est in (("continua", dict(lw=2, label="contínua")), ("discreta", dict(ls="--", label="discreta, $T_s$ = 5 ms")),
                      ("atuador", dict(lw=1.2, label="discreta com atuador identificado"))):
        o = sims[nome]["o"]
        axs[0, 0].plot(o[:, 0], np.degrees(o[:, 1]), **est); axs[0, 1].plot(o[:, 0], np.degrees(o[:, 2]), **est)
        axs[1, 0].plot(o[:, 0], o[:, 5], **est); axs[1, 1].plot(o[:, 0], o[:, 6], **est)
    for ax, yl in zip(axs.flat, ("φ [°]", "ψ [°]", "$u_1$ [N]", "$u_2$ [N]")):
        ax.set_ylabel(yl); ax.grid(alpha=.3); ax.xaxis.set_major_formatter(virg); ax.yaxis.set_major_formatter(virg)
    axs[1, 0].set_xlabel("t [s]"); axs[1, 1].set_xlabel("t [s]"); axs[0, 0].legend(fontsize=8)
    fig.tight_layout(); fig.savefig(AQUI / "graficos" / "resposta_pid_discreto_v6.png", dpi=200); plt.close(fig)

    # ---------------- 4
    pdr = polos_discretos(KR, BPHI, W0Q); pdy = polos_discretos(KY, BPSI, 0.0)
    out["polos_discretos"] = dict(
        roll=dict(continuo=[[float(p.real), float(p.imag)] for p in pr_fin], esperado=[[float(np.exp(p * TS).real), float(np.exp(p * TS).imag)] for p in pr_fin],
                  malha=[[float(p.real), float(p.imag)] for p in pdr]),
        yaw=dict(continuo=[[float(p.real), float(p.imag)] for p in py], esperado=[[float(np.exp(p * TS).real), float(np.exp(p * TS).imag)] for p in py],
                 malha=[[float(p.real), float(p.imag)] for p in pdy]))
    print("4) polos discretos roll: esperado", np.round(np.exp(pr_fin * TS), 5), "malha", np.round(pdr, 5))
    print("   polos discretos yaw : esperado", np.round(np.exp(py * TS), 5), "malha", np.round(pdy, 5))
    print("   max|z| ideal:", float(max(np.abs(np.r_[pdr, pdy]))))
    # mesma simulação para Ts maiores (estabilidade da amostragem)
    for Ts_ in (0.01, 0.02, 0.05, 0.1, 0.2):
        zr = max(np.abs(polos_discretos(KR, BPHI, W0Q, Ts_))); zy = max(np.abs(polos_discretos(KY, BPSI, 0.0, Ts_)))
        print(f"   Ts = {Ts_*1000:.0f} ms: max|z| roll {zr:.4f} yaw {zy:.4f}")
        out.setdefault("Ts_maiores", {})[f"{Ts_*1000:.0f} ms"] = dict(roll=float(zr), yaw=float(zy))

    # ---------------- 5
    rob = {"roll": [], "yaw": []}
    for f in (0.5, 0.66, 1.0, 1.25, 1.5):
        mz, ma = pior(KR, "roll", fatores=(1.0,), fb=f)
        o, T = simula(KR, KY, bphi=BPHI * f, Ts=TS, tau=TAU_ID, Td=TD_ID + TS, fr=FR, ref_psi=0.0, tf=20.0)
        op, _ = simula(KR, KY, bphi=BPHI * f, Ts=TS, tau=TAU_ID, Td=TD_ID + TS, fr=FR, ref_phi=0.0, ref_psi=0.0, tf=20.0, perturb=(1.0, 0.01))
        mr = metricas(o[:, 0], o[:, 1], 10.0)
        rob["roll"].append(dict(f=f, zmax=mz, margem_ms=ma * 1000, Mp=mr["Mp"], ts=mr["ts"], umax=float(np.abs(o[:, 5]).max()),
                                pico_perturb=float(np.degrees(np.abs(op[:, 1]).max())), T=[float(T.min()), float(T.max())], serie=o, serie_p=op))
    for f in (0.75, 1.0, 1.22, 1.5):
        mz, ma = pior(KY, "yaw", fatores=(1.0,), fb=f)
        o, T = simula(KR, KY, bpsi=BPSI * f, Ts=TS, tau=TAU_ID, Td=TD_ID + TS, fr=FR, ref_phi=0.0, tf=20.0)
        my = metricas(o[:, 0], o[:, 2], 30.0)
        rob["yaw"].append(dict(f=f, zmax=mz, margem_ms=ma * 1000, Mp=my["Mp"], ts=my["ts"], umax=float(np.abs(o[:, 6]).max()),
                               T=[float(T.min()), float(T.max())], serie=o))
    # faixa estável em f (pior caso dos 4 modelos)
    fs = np.round(np.arange(0.1, 3.01, 0.02), 2)
    zr = [pior(KR, "roll", fatores=(1.0,), fb=f)[0] for f in fs]
    zy = [pior(KY, "yaw", fatores=(1.0,), fb=f)[0] for f in fs]
    est_r = fs[np.array(zr) < 1]; est_y = fs[np.array(zy) < 1]
    out["robustez"] = {k: [{kk: vv for kk, vv in d.items() if not kk.startswith("serie")} for d in v] for k, v in rob.items()}
    out["robustez"]["faixa_estavel_roll"] = [float(est_r.min()), float(est_r.max())] if len(est_r) else None
    out["robustez"]["faixa_estavel_yaw"] = [float(est_y.min()), float(est_y.max())] if len(est_y) else None
    print("5) robustez (pior caso dos 4 modelos do atuador)")
    for k in ("roll", "yaw"):
        for d in rob[k]:
            print(f"   {k} f={d['f']:.2f}: max|z| {d['zmax']:.4f} margem {d['margem_ms']:.0f} ms Mp {d['Mp']:.1f} ts {d['ts']:.2f} |u| {d['umax']:.3f}"
                  + (f" pico perturb {d['pico_perturb']:.1f}°" if k == "roll" else "") + f" T {d['T'][0]:.2f}-{d['T'][1]:.2f}")
    print("   faixa estável roll", out["robustez"]["faixa_estavel_roll"], " yaw", out["robustez"]["faixa_estavel_yaw"], "(varredura 0,1 a 3)")
    fig, axs = plt.subplots(2, 2, figsize=(10, 6.5))
    for d in [d for d in rob["roll"] if d["zmax"] < 1]:
        axs[0, 0].plot(d["serie"][:, 0], np.degrees(d["serie"][:, 1]), label=f"$f_\\phi$ = {f2(d['f'])}")
        axs[1, 0].plot(d["serie_p"][:, 0], np.degrees(d["serie_p"][:, 1]), label=f"$f_\\phi$ = {f2(d['f'])}")
    for d in rob["yaw"]:
        axs[0, 1].plot(d["serie"][:, 0], np.degrees(d["serie"][:, 2]), label=f"$f_\\psi$ = {f2(d['f'])}")
    axs[1, 1].plot(fs, zr, label="roll"); axs[1, 1].plot(fs, zy, label="yaw"); axs[1, 1].axhline(1, color="k", ls=":")
    axs[1, 1].set_ylim(0.97, 1.02)
    for ax, yl, xl in zip(axs.flat, ("φ [°]", "ψ [°]", "φ [°]", "max|z|"), ("t [s]", "t [s]", "t [s]", "fator f")):
        ax.set_ylabel(yl); ax.set_xlabel(xl); ax.grid(alpha=.3); ax.legend(fontsize=7)
        ax.xaxis.set_major_formatter(virg); ax.yaxis.set_major_formatter(virg)
    for ax, l in zip(axs.flat, "abcd"):
        ax.set_title(f"({l})", loc="left")
    fig.tight_layout(); fig.savefig(AQUI / "graficos" / "robustez_pid_v6.png", dpi=200); plt.close(fig)

    (AQUI / "dados" / "simulacao_controlador_final.json").write_text(json.dumps(out, indent=2, ensure_ascii=False, default=float), encoding="utf-8")


if __name__ == "__main__":
    main()
