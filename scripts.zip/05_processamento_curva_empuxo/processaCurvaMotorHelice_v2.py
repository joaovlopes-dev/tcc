import csv
import json
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

# ------------------------------------------------------------------
# Parâmetros da bancada
# ------------------------------------------------------------------
G = 9.81            # m/s^2
L_BRACO = 0.155     # m, braço da balança (d_b) em relação ao pivô O
RAZAO_EMPUXO = 1.0  # braços iguais (d_m = d_b = 155 mm)
T_MIN_KAPPA = 1.0   # N, abaixo disso a leitura de arrasto (2-5 g) é dominada pela resolução da balança

BASE = Path(__file__).resolve().parent
CSV_IN = BASE / "dados" / "ensaio_empuxo.csv"
OUT_DIR = BASE / "graficos"
JSON_OUT = BASE / "dados" / "curva_motor_helice.json"

# Paleta (slots categóricos 1 e 2) e tinta de texto/eixos
COR_DADO = "#2a78d6"
COR_AJUSTE = "#eb6834"
TINTA = "#3d3d3a"
GRADE = "#d9d8d2"


def num_br(x):
    return float(str(x).replace(",", "."))


def ler_csv(caminho):
    pwm, forca_g, arrasto_g = [], [], []
    with open(caminho, encoding="utf-8") as f:
        for linha in csv.DictReader(f):
            pwm.append(num_br(linha["pwm_us"]))
            forca_g.append(num_br(linha["forca_g"]))
            arrasto_g.append(num_br(linha["arrasto_g"]) if linha["arrasto_g"] != "" else np.nan)
    return np.array(pwm), np.array(forca_g), np.array(arrasto_g)


def ajuste_quadratico(x, y):
    """Ajuste y = c2 x^2 + c1 x + c0 por mínimos quadrados; retorna coeficientes e R^2."""
    c = np.polyfit(x, y, 2)
    y_hat = np.polyval(c, x)
    r2 = 1.0 - np.sum((y - y_hat) ** 2) / np.sum((y - np.mean(y)) ** 2)
    return c, r2


def formatar_eixos(ax, xlabel, ylabel):
    virgula = FuncFormatter(lambda v, _: f"{v:g}".replace(".", ","))
    ax.xaxis.set_major_formatter(virgula)
    ax.yaxis.set_major_formatter(virgula)
    ax.set_xlabel(xlabel, color=TINTA)
    ax.set_ylabel(ylabel, color=TINTA)
    ax.grid(True, color=GRADE, linewidth=0.6)
    ax.set_axisbelow(True)
    for lado in ("top", "right"):
        ax.spines[lado].set_visible(False)
    for lado in ("left", "bottom"):
        ax.spines[lado].set_color(GRADE)
    ax.tick_params(colors=TINTA)


def grafico_curva(x, y, x_fit, y_fit, xlabel, ylabel, rotulo_fit, arquivo):
    fig, ax = plt.subplots(figsize=(6.4, 4.0), dpi=200)
    ax.plot(x_fit, y_fit, color=COR_AJUSTE, linewidth=2, label=rotulo_fit, zorder=2)
    ax.plot(x, y, "o", color=COR_DADO, markersize=4.5, markeredgecolor="white",
            markeredgewidth=0.8, label="Medido", zorder=3)
    formatar_eixos(ax, xlabel, ylabel)
    ax.legend(frameon=False, labelcolor=TINTA)
    fig.tight_layout()
    fig.savefig(arquivo)
    plt.close(fig)


def main():
    OUT_DIR.mkdir(exist_ok=True)
    pwm, forca_g, arrasto_g = ler_csv(CSV_IN)

    T = forca_g / 1000.0 * G * RAZAO_EMPUXO          # N
    Q = arrasto_g / 1000.0 * G * L_BRACO             # N.m

    # Zona morta do ESC: último PWM com empuxo nulo
    pwm_zona_morta = pwm[T <= 0].max()

    # Ajustes acima da zona morta
    m_T = T > 0
    cT, r2T = ajuste_quadratico(pwm[m_T], T[m_T])
    m_Q = (Q > 0) & ~np.isnan(Q)
    cQ, r2Q = ajuste_quadratico(pwm[m_Q], Q[m_Q])

    # Razão torque/empuxo
    m_k = (T >= T_MIN_KAPPA) & ~np.isnan(Q)
    kappa = Q[m_k] / T[m_k]
    kappa_med, kappa_dp = float(np.mean(kappa)), float(np.std(kappa, ddof=1))

    # Ganho estático local dT/dPWM em alguns pontos
    def dT(p):
        return 2 * cT[0] * p + cT[1]

    ganhos = {int(p): float(dT(p)) for p in (1300, 1500, 1700)}

    x_fit = np.linspace(pwm[m_T].min(), pwm.max(), 300)

    grafico_curva(pwm, T, x_fit, np.polyval(cT, x_fit),
                  "PWM (µs)", "Empuxo T (N)",
                  f"Ajuste quadrático (R² = {r2T:.4f})".replace(".", ","),
                  OUT_DIR / "curva_empuxo_pwm.png")

    xq = np.linspace(pwm[m_Q].min(), pwm.max(), 300)
    grafico_curva(pwm, Q, xq, np.polyval(cQ, xq),
                  "PWM (µs)", "Torque de reação Q (N·m)",
                  f"Ajuste quadrático (R² = {r2Q:.4f})".replace(".", ","),
                  OUT_DIR / "curva_torque_pwm.png")

    # Gráfico de kappa: pontos usados x descartados
    fig, ax = plt.subplots(figsize=(6.4, 4.0), dpi=200)
    m_desc = (T > 0) & (T < T_MIN_KAPPA) & (Q > 0)
    ax.plot(pwm[m_desc], Q[m_desc] / T[m_desc], "o", markersize=4.5,
            markerfacecolor="white", markeredgecolor=COR_DADO, markeredgewidth=1.2,
            label=f"T < {T_MIN_KAPPA:g} N (resolução da balança)".replace(".", ","))
    ax.plot(pwm[m_k], kappa, "o", color=COR_DADO, markersize=4.5,
            markeredgecolor="white", markeredgewidth=0.8, label="Usados na média")
    ax.axhline(kappa_med, color=COR_AJUSTE, linewidth=2,
               label=f"Média κ = {kappa_med:.4f} m".replace(".", ","))
    formatar_eixos(ax, "PWM (µs)", "κ = Q / T (m)")
    ax.legend(frameon=False, labelcolor=TINTA)
    fig.tight_layout()
    fig.savefig(OUT_DIR / "curva_kappa_pwm.png")
    plt.close(fig)

    resultado = {
        "fonte": str(CSV_IN.relative_to(BASE.parent)),
        "bancada": {"g": G, "L_braco_m": L_BRACO, "razao_empuxo": RAZAO_EMPUXO,
                    "helice": "8 polegadas"},
        "pwm_zona_morta_us": float(pwm_zona_morta),
        "empuxo_N_vs_pwm_us": {"c2": cT[0], "c1": cT[1], "c0": cT[2], "R2": r2T,
                               "faixa_us": [float(pwm[m_T].min()), float(pwm.max())]},
        "torque_Nm_vs_pwm_us": {"c2": cQ[0], "c1": cQ[1], "c0": cQ[2], "R2": r2Q,
                                "faixa_us": [float(pwm[m_Q].min()), float(pwm.max())]},
        "F_max_N": float(T.max()),
        "Q_max_Nm": float(np.nanmax(Q)),
        "kappa_m": {"media": kappa_med, "desvio_padrao": kappa_dp,
                    "n_pontos": int(m_k.sum()), "criterio": f"T >= {T_MIN_KAPPA} N"},
        "ganho_estatico_dT_dPWM_N_por_us": ganhos,
    }
    resultado = json.loads(json.dumps(resultado, default=float))
    JSON_OUT.write_text(json.dumps(resultado, indent=2, ensure_ascii=False), encoding="utf-8")

    print(f"Zona morta do ESC: PWM <= {pwm_zona_morta:.0f} us")
    print(f"T(PWM) = {cT[0]:.4e} PWM^2 + {cT[1]:.4e} PWM + {cT[2]:.4e}   [N]   R2 = {r2T:.4f}")
    print(f"Q(PWM) = {cQ[0]:.4e} PWM^2 + {cQ[1]:.4e} PWM + {cQ[2]:.4e}   [N.m] R2 = {r2Q:.4f}")
    print(f"F_max = {T.max():.2f} N  |  Q_max = {np.nanmax(Q):.4f} N.m")
    print(f"kappa = {kappa_med:.4f} +- {kappa_dp:.4f} m  ({m_k.sum()} pontos com T >= {T_MIN_KAPPA} N)")
    for p, gk in ganhos.items():
        print(f"dT/dPWM @ {p} us = {gk*1000:.3f} mN/us")
    print(f"Gráficos em {OUT_DIR}; coeficientes em {JSON_OUT}")


if __name__ == "__main__":
    main()
