import json
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

AQUI = Path(__file__).resolve().parent
LOG = AQUI / "dados" / "controlador_motores_v5_T5_log.txt"
SIM = np.load(AQUI / "dados" / "simulacao_controlador_final_series.npz")
virg = FuncFormatter(lambda v, _: f"{v:g}".replace(".", ","))
H = 15.0          # horizonte das métricas da média [s]


def carrega():
    tel, ops, cur, seg, lt = [], [], None, 0, None
    for linha in LOG.open(encoding="utf-8", errors="ignore"):
        tp, _, pl = linha.strip().partition(" ")
        if tp.endswith("telemetry"):
            try:
                d = json.loads(pl)
            except json.JSONDecodeError:
                continue
            if lt is not None and d["t"] < lt:
                seg += 1                                   # reinício do ESP32 (relógio volta a zero)
            lt = d["t"]; d["seg"] = seg; tel.append(d)
        elif tp.endswith("state") and lt is not None:
            if '"modo":"operacao"' in pl:
                cur = dict(seg=seg, a=lt / 1000, refs=[])
            elif cur is not None and '"referencia"' in pl:
                d = json.loads(pl); cur["refs"].append((lt / 1000, d["phi_ref"], d["psi_ref"]))
            elif cur is not None and "desarmado" in pl:
                cur["b"] = lt / 1000; cur["fim"] = json.loads(pl)["motivo"]; ops.append(cur); cur = None
    A = {k: np.array([d[k] for d in tel], float) for k in ("t", "phi", "psi", "p", "r", "u1", "u2", "seg")}
    A["t"] /= 1000
    return A, ops


def degraus(op, eixo):
    """Lista de degraus (t0, de, para, fim) de um eixo, ignorando comandos repetidos."""
    i = 1 if eixo == "phi" else 2
    out, prev = [], 0.0
    refs = op["refs"]
    mud = [(t, r[i - 1]) for t, *r in [(x[0], x[1], x[2]) for x in refs]]
    mud = []
    for t, rp, rs in refs:
        v = rp if eixo == "phi" else rs
        if v != prev:
            mud.append((t, prev, v)); prev = v
    for j, (t, a, b) in enumerate(mud):
        fim = mud[j + 1][0] if j + 1 < len(mud) else op["b"]
        out.append((t, a, b, fim))
    return out


def main():
    A, ops = carrega()
    tt = np.arange(-1, H + 5, 0.01)
    res = {"operacoes": [dict(duracao_s=o["b"] - o["a"], fim=o["fim"], n_refs=len(o["refs"])) for o in ops]}
    medias = {}
    for eixo, amp_nom in (("phi", 10.0), ("psi", 30.0)):
        Y, lin = [], []
        for o in ops:
            m_op = A["seg"] == o["seg"]
            t, y = A["t"][m_op], A[eixo][m_op]
            for (t0, a, b, fim) in degraus(o, eixo):
                dur = fim - t0
                if dur < 3.0:
                    continue                                   # degrau interrompido (corte logo após o comando)
                yn = np.interp(tt + t0, t, (y - a) / (b - a))
                yn[tt > dur] = np.nan
                Y.append(yn)
                pos = (tt >= 0) & (tt <= dur)
                ys = np.convolve(np.nan_to_num(yn), np.ones(25) / 25, "same")       # média móvel 0,25 s
                i10 = np.argmax((ys >= 0.1) & pos); i90 = np.argmax((ys >= 0.9) & pos)
                tr = tt[i90] - tt[i10] if ((ys >= 0.9) & pos).any() else np.nan
                tf_ = min(dur, tt[-1])
                fin = (tt > tf_ - 3) & (tt <= tf_)
                lin.append(dict(de=a, para=b, duracao_s=dur, tr_s=float(tr), Mp_pct=float(max(0, (np.nanmax(ys[pos]) - 1) * 100)),
                                erro_final_graus=float(np.nanmean(yn[fin]) * (b - a) - (b - a)) if dur >= 15 else None))
        Y = np.array(Y)
        n = np.sum(~np.isnan(Y), 0)
        ym = np.nanmean(Y, 0); sd = np.nanstd(Y, 0)
        pos = (tt >= 0) & (tt <= H)
        ysm = np.convolve(np.nan_to_num(ym), np.ones(25) / 25, "same")
        i10 = np.argmax((ysm >= 0.1) & pos); i90 = np.argmax((ysm >= 0.9) & pos)
        # simulação com o atuador identificado, mesmo horizonte
        ts_ = SIM["t"]; ysim = SIM["phi"] if eixo == "phi" else SIM["psi"]
        ysim_i = np.interp(tt, ts_, ysim)
        def iae(y_):
            e = np.abs(1 - y_[pos]) * np.radians(amp_nom)
            return float(np.trapezoid(e, tt[pos])), float(np.trapezoid(tt[pos] * e, tt[pos]))
        ie, ite = iae(ym); ies, ites = iae(ysim_i)
        fin = (tt >= 10) & (tt <= H)
        medias[eixo] = dict(tt=tt, ym=ym, sd=sd, n=n, ysim=ysim_i)
        res[eixo] = dict(degraus=lin, n_degraus=len(Y), n_completos_15s=int(np.sum(~np.isnan(Y[:, np.argmin(abs(tt - H))]))),
                         media=dict(tr_s=float(tt[i90] - tt[i10]), Mp_pct=float(max(0, (ysm[pos].max() - 1) * 100)),
                                    valor_10_15s=float(np.nanmean(ym[fin])), sd_entre_degraus_10_15s=float(np.nanmean(sd[fin])),
                                    IAE=ie, ITAE=ite),
                         simulacao=dict(IAE=ies, ITAE=ites, Mp_pct=float(max(0, (ysim_i[pos].max() - 1) * 100)),
                                        tr_s=float(tt[np.argmax(ysim_i >= .9)] - tt[np.argmax(ysim_i >= .1)])))
        print(f"{eixo}: {len(Y)} degraus ({res[eixo]['n_completos_15s']} com 15 s); média t_r {res[eixo]['media']['tr_s']:.2f} s, "
              f"M_p {res[eixo]['media']['Mp_pct']:.0f} %, valor 10-15 s {res[eixo]['media']['valor_10_15s']:.2f} "
              f"(dispersão {res[eixo]['media']['sd_entre_degraus_10_15s']:.2f}), IAE {ie:.3f} ITAE {ite:.3f} | "
              f"simulação t_r {res[eixo]['simulacao']['tr_s']:.2f} M_p {res[eixo]['simulacao']['Mp_pct']:.1f} IAE {ies:.3f} ITAE {ites:.3f}")
        for d in lin:
            print(f"   {d['de']:+4.0f} -> {d['para']:+4.0f}  {d['duracao_s']:5.1f} s  t_r {d['tr_s']:.1f}  M_p {d['Mp_pct']:.0f} %"
                  + (f"  erro final {d['erro_final_graus']:+.2f}°" if d["erro_final_graus"] is not None else ""))

    # ---------------- oscilação com referência nula (antes do 1º comando de cada operação)
    par = []
    for o in ops:
        m = (A["seg"] == o["seg"]) & (A["t"] > o["a"] + 3) & (A["t"] < (o["refs"][0][0] if o["refs"] else o["b"]))
        if m.sum() < 500:
            continue
        ph, ps = A["phi"][m], A["psi"][m]
        x = ph - ph.mean(); X = np.abs(np.fft.rfft(x))**2 / len(x)**2 * 2; f = np.fft.rfftfreq(len(x), 0.01)
        banda = lambda lo, hi: float(np.sqrt(X[(f >= lo) & (f < hi)].sum()))
        par.append(dict(duracao_s=float(m.sum() / 100), sd_phi=float(ph.std()), sd_psi=float(ps.std()), media_phi=float(ph.mean()),
                        banda_0_03=banda(0, 0.3), banda_03_1=banda(0.3, 1), banda_acima_15=banda(1.5, 50)))
    res["referencia_nula"] = par
    print("referência nula:", [(round(d["duracao_s"]), round(d["sd_phi"], 2), round(d["sd_psi"], 2)) for d in par])
    # ---------------- efeito dos degraus de yaw no roll
    acop = []
    for o in ops:
        m_op = A["seg"] == o["seg"]
        for (t0, a, b, fim) in degraus(o, "psi"):
            mb = m_op & (A["t"] >= t0 - 5) & (A["t"] < t0); ma = m_op & (A["t"] >= t0) & (A["t"] < t0 + 4)
            if mb.sum() > 100 and ma.sum() > 100 and fim - t0 >= 3.0:
                acop.append(dict(degrau=f"{a:+.0f}->{b:+.0f}", sd_antes=float(A["phi"][mb].std()),
                                 desvio_max_4s=float(np.abs(A["phi"][ma] - A["phi"][mb].mean()).max())))
    res["acoplamento_yaw_roll"] = acop
    print("acoplamento:", [(d["degrau"], round(d["desvio_max_4s"], 1)) for d in acop])

    # ---------------- figuras
    fig, axs = plt.subplots(1, 2, figsize=(10, 3.8))
    for ax, eixo, amp, nome in ((axs[0], "phi", 10, "φ"), (axs[1], "psi", 30, "ψ")):
        M = medias[eixo]; k = M["tt"] <= H + 3
        ax.fill_between(M["tt"][k], (M["ym"] - M["sd"])[k] * amp, (M["ym"] + M["sd"])[k] * amp, color="C0", alpha=.2, label="± 1 desvio-padrão")
        ax.plot(M["tt"][k], M["ym"][k] * amp, "C0", lw=1.5, label=f"média medida ({res[eixo]['n_degraus']} degraus)")
        ax.plot(M["tt"][k], M["ysim"][k] * amp, "C3--", lw=1.5, label="simulação com atuador")
        ax.axhline(amp, color="k", ls=":", lw=.8)
        ax.set_xlabel("tempo após o comando [s]"); ax.set_ylabel(f"{nome} normalizado [°]"); ax.grid(alpha=.3)
        ax.legend(fontsize=7, loc="lower right"); ax.xaxis.set_major_formatter(virg); ax.yaxis.set_major_formatter(virg)
    axs[0].set_title("(a) Roll, degraus de 10°", loc="left"); axs[1].set_title("(b) Yaw, degraus de 30°", loc="left")
    fig.tight_layout(); fig.savefig(AQUI / "graficos" / "malha_fechada_media_v6.png", dpi=200); plt.close(fig)

    fig, axs = plt.subplots(2, 1, figsize=(10, 5.5))
    for ax, o, eixo, nome in ((axs[0], ops[0], "phi", "φ"), (axs[1], ops[2], "psi", "ψ")):
        m = (A["seg"] == o["seg"]) & (A["t"] >= o["a"] + 0.5) & (A["t"] <= o["b"])   # psi é zerado ao ligar o yaw
        t = A["t"][m] - o["a"]
        ref = np.zeros_like(t)
        for (t0, a, b, fim) in degraus(o, eixo):
            ref[t >= t0 - o["a"]] = b
        ax.plot(t, A[eixo][m], lw=.8, label=f"{nome} medido"); ax.plot(t, ref, "k--", lw=1, label="referência")
        if eixo == "psi":
            ax.plot(t, A["phi"][m], lw=.6, color="C2", alpha=.8, label="φ medido")
        ax.set_ylabel("ângulo [°]"); ax.grid(alpha=.3); ax.legend(fontsize=7, ncol=3); ax.xaxis.set_major_formatter(virg)
    axs[1].set_xlabel("tempo de operação [s]")
    axs[0].set_title("(a) Rodada de roll", loc="left"); axs[1].set_title("(b) Rodada de yaw", loc="left")
    fig.tight_layout(); fig.savefig(AQUI / "graficos" / "malha_fechada_registro_v6.png", dpi=200); plt.close(fig)

    (AQUI / "dados" / "ensaio_malha_fechada.json").write_text(json.dumps(res, indent=2, ensure_ascii=False, default=float), encoding="utf-8")


if __name__ == "__main__":
    main()
