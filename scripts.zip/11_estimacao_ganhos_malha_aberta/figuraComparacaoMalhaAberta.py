import json
from pathlib import Path

import numpy as np
from scipy.optimize import least_squares
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

import analisaEnsaioMalhaAberta_v2 as v2
import analisaEnsaioMalhaAberta_v3 as v3

AQUI = Path(__file__).resolve().parent
W0, Z0 = v3.W0, v3.Z0
B_PHI, B_PSI = v2.BETA_PHI_T, v2.BETA_PSI_T
PRE, POS_ROLL, POS_YAW = 0.5, 1.5, 0.5
virgula = FuncFormatter(lambda v, _: f"{v:g}".replace(".", ","))
CORES = ["tab:blue", "tab:orange", "tab:green", "tab:purple"]


def sim_roll(tt, d0, p0, uu, a, beta):
    """RK4 de eq:ensaio_roll com u segurado entre amostras."""
    x = np.array([d0, p0]); out = np.empty(len(tt)); out[0] = x[0]
    for k in range(len(tt) - 1):
        h = tt[k + 1] - tt[k]
        f = lambda x_: np.array([x_[1], -W0**2 * np.sin(x_[0]) - 2 * Z0 * W0 * x_[1] + a + beta * uu[k]])
        k1 = f(x); k2 = f(x + h / 2 * k1); k3 = f(x + h / 2 * k2); k4 = f(x + h * k3)
        x = x + h / 6 * (k1 + 2 * k2 + 2 * k3 + k4); out[k + 1] = x[0]
    return out


def sim_yaw(tt, r0, uu, a, beta):
    r = np.empty(len(tt)); r[0] = r0
    for k in range(len(tt) - 1):
        r[k + 1] = r[k] + (beta * uu[k] + a) * (tt[k + 1] - tt[k])
    return r


def rms(e):
    return float(np.sqrt(np.mean(e ** 2)))


def roll_janelas(D, n):
    t, d, p, u = D["t"], D["delta"], D["p"], D["u1"]
    ident = v3.roll_trocas(D)
    res = []
    for k, i in enumerate(v3.trocas(u)):
        ts = t[i]
        m = (t >= ts - PRE) & (t <= ts + POS_ROLL); i0 = int(np.argmax(m))
        tt, yy, uu = t[m], d[m], u[m]
        mp = tt < ts
        # a estimado só na pré-janela, com beta nominal (u constante antes da troca)
        s = least_squares(lambda q: sim_roll(tt[mp], d[i0], p[i0], uu[mp], q[0], B_PHI) - yy[mp], [0.0])
        a_est = float(s.x[0])
        e_id = ident[k]
        curvas = {"nominal_a0": sim_roll(tt, d[i0], p[i0], uu, 0.0, B_PHI),
                  "nominal_aest": sim_roll(tt, d[i0], p[i0], uu, a_est, B_PHI),
                  "identificado": sim_roll(tt, d[i0], p[i0], uu, e_id["a"], e_id["beta_phi"])}
        post = tt >= ts
        res.append(dict(n=n, troca=k, t=float(ts), du=float(u[i] - u[i - 1]), a_est=a_est,
                        a_id=e_id["a"], beta_id=e_id["beta_phi"], r2_id=e_id["r2"],
                        rms_graus={c: rms(np.degrees(y[post] - yy[post])) for c, y in curvas.items()},
                        _tau=tt - ts, _med=np.degrees(yy), _sim={c: np.degrees(y) for c, y in curvas.items()}))
    return res


def yaw_janelas(D, n):
    t, r, u = D["t"], D["r"], D["u2"]
    dub = v3.yaw_dubletes(D)
    res = []
    for k, e in enumerate(dub):
        ts = e["t"]; tf = ts + 2.0
        m = (t >= ts - PRE - 1e-9) & (t <= tf + POS_YAW); i0 = int(np.argmax(m))
        tt, yy, uu = t[m], r[m], u[m]
        mp = tt < ts
        a_est = float(np.polyfit(tt[mp], yy[mp], 1)[0])
        a_id = e["s1"] - e["beta_psi"] * e["u_mais"]
        curvas = {"nominal_a0": sim_yaw(tt, r[i0], uu, 0.0, B_PSI),
                  "nominal_aest": sim_yaw(tt, r[i0], uu, a_est, B_PSI),
                  "identificado": sim_yaw(tt, r[i0], uu, a_id, e["beta_psi"])}
        post = (tt >= ts) & (tt < tf)
        res.append(dict(n=n, dublete=k, t=float(ts), u_mais=e["u_mais"], a_est=a_est, a_id=float(a_id),
                        beta_id=e["beta_psi"],
                        rms_rad_s={c: rms(y[post] - yy[post]) for c, y in curvas.items()},
                        _tau=tt - ts, _med=yy, _sim=curvas))
    return res


def limpa(lst):
    return [{k: v for k, v in e.items() if not k.startswith("_")} for e in lst]


def resumo(lst, chave):
    return {c: [float(np.mean([e[chave][c] for e in lst])), float(np.std([e[chave][c] for e in lst], ddof=1))]
            for c in ("nominal_a0", "nominal_aest", "identificado")}


def painel(ax, grupo, titulo, unid, fmt):
    for e in grupo:
        c = CORES[(e["n"] - 1) % 4]
        ax.plot(e["_tau"], e["_med"], color=c, lw=1.3)
        ax.plot(e["_tau"], e["_sim"]["nominal_aest"], "--", color=c, lw=1.2)
    ax.axvline(0, color="k", lw=0.8)
    ch = "rms_graus" if unid == "°" else "rms_rad_s"
    v = np.array([e[ch]["nominal_aest"] for e in grupo])
    ax.text(0.02, 0.97, f"RMS nominal: {fmt(v.mean())} {unid}", transform=ax.transAxes,
            va="top", fontsize=8, bbox=dict(fc="white", ec="0.7", alpha=0.85))
    ax.set_title(titulo, fontsize=10); ax.grid(alpha=0.3)
    ax.xaxis.set_major_formatter(virgula); ax.yaxis.set_major_formatter(virgula)


def legenda(fig, reps):
    from matplotlib.lines import Line2D
    h = [Line2D([], [], color=CORES[(n - 1) % 4], lw=1.5, label=f"repetição {n}") for n in reps]
    h += [Line2D([], [], color="0.3", lw=1.3, label="medido"),
          Line2D([], [], color="0.3", lw=1.2, ls="--", label="simulado (modelo nominal)")]
    fig.legend(handles=h, loc="lower center", ncol=len(h), fontsize=8, frameon=False)


def main():
    L = v2.LOG.read_text(encoding="utf-8").splitlines()
    rot, ini, fim, pwm0, _ = v2.SESSOES[1]
    ens = [(tp, n, v2.arrays(am)) for tp, n, am in v2.le_sessao(L, ini, fim) if (rot, tp, n) not in v2.EXCLUIR]
    R = [e for tp, n, D in ens if tp == "roll" for e in roll_janelas(D, n)]
    Y = [e for tp, n, D in ens if tp == "yaw" for e in yaw_janelas(D, n)]
    g2 = lambda x: f"{x:.1f}".replace(".", ",")
    g3 = lambda x: f"{x:.3f}".replace(".", ",")

    # ---- roll
    fig, axs = plt.subplots(2, 2, figsize=(10, 7), sharex=True)
    rotulos = ["$u_1$: 0 → +0,1 N", "$u_1$: +0,1 → 0 N", "$u_1$: 0 → −0,1 N", "$u_1$: −0,1 → 0 N"]
    for k, ax in enumerate(axs.flat):
        painel(ax, [e for e in R if e["troca"] == k], f"({'abcd'[k]}) {rotulos[k]}", "°", g2)
    for ax in axs[:, 0]: ax.set_ylabel(r"$\phi - 180°$ [°]")
    for ax in axs[1]: ax.set_xlabel("Tempo desde a troca [s]")
    legenda(fig, sorted({e["n"] for e in R}))
    fig.tight_layout(rect=(0, 0.04, 1, 1))
    fig.savefig(AQUI / "graficos" / "comparacao_malha_aberta_roll.png", dpi=200)

    # ---- yaw
    fig, axs = plt.subplots(1, 2, figsize=(10, 3.9), sharey=True)
    rotulos = ["dublete $u_2$ = +0,5 / −0,5 N", "dublete $u_2$ = −0,5 / +0,5 N"]
    for k, ax in enumerate(axs):
        painel(ax, [e for e in Y if e["dublete"] == k], f"({'ab'[k]}) {rotulos[k]}", "rad/s", g3)
        ax.axvline(1.0, color="k", lw=0.5, ls=":"); ax.axvline(2.0, color="k", lw=0.8)
        ax.set_xlabel("Tempo desde o início do dublete [s]")
    axs[0].set_ylabel("$r$ [rad/s]")
    legenda(fig, sorted({e["n"] for e in Y}))
    fig.tight_layout(rect=(0, 0.07, 1, 1))
    fig.savefig(AQUI / "graficos" / "comparacao_malha_aberta_yaw.png", dpi=200)

    out = {"pwm0": pwm0, "modelo": {"beta_phi": B_PHI, "beta_psi": B_PSI, "w0": W0, "zeta0": Z0},
           "janelas": {"pre_s": PRE, "pos_roll_s": POS_ROLL, "pos_yaw_s": POS_YAW},
           "roll": {"janelas": limpa(R), "rms_graus_media_dp": resumo(R, "rms_graus")},
           "yaw": {"janelas": limpa(Y), "rms_rad_s_media_dp": resumo(Y, "rms_rad_s")}}
    (AQUI / "dados" / "comparacao_malha_aberta.json").write_text(json.dumps(out, indent=2, ensure_ascii=False), encoding="utf-8")

    print("ROLL  (RMS em °, 0 a 1,5 s após a troca)    a0    a_est   ident   | a_est   a_id")
    for e in R:
        r_ = e["rms_graus"]
        print(f"  rep {e['n']} troca {e['troca']} du={e['du']:+.1f}:  {r_['nominal_a0']:6.1f} {r_['nominal_aest']:6.1f} "
              f"{r_['identificado']:6.1f}   | {e['a_est']:+6.2f} {e['a_id']:+6.2f}")
    print("  média ± dp:", {c: f"{m:.1f} ± {s:.1f}" for c, (m, s) in out['roll']['rms_graus_media_dp'].items()})
    print("YAW   (RMS em rad/s, durante o dublete)      a0     a_est   ident   | a_est   a_id")
    for e in Y:
        r_ = e["rms_rad_s"]
        print(f"  rep {e['n']} dub {e['dublete']}:  {r_['nominal_a0']:.3f}  {r_['nominal_aest']:.3f}  "
              f"{r_['identificado']:.3f}   | {e['a_est']:+.3f} {e['a_id']:+.3f}")
    print("  média ± dp:", {c: f"{m:.3f} ± {s:.3f}" for c, (m, s) in out['yaw']['rms_rad_s_media_dp'].items()})


if __name__ == "__main__":
    main()
