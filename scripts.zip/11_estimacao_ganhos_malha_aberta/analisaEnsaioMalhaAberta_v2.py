import json
from pathlib import Path

import numpy as np
from scipy.optimize import least_squares
from scipy.signal import savgol_filter
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

AQUI = Path(__file__).resolve().parent
LOG = AQUI / "dados" / "ensaio_malha_aberta_log.txt"
G5 = json.loads((AQUI / "dados" / "ganhos_pid_v5.json").read_text(encoding="utf-8"))
BETA_PHI_T, BETA_PSI_T, W0_T = G5["beta_phi"], G5["beta_psi"], G5["w0"]
# sessões: (rótulo, linha inicial, linha final, pwm0, yaw travado no roll?)
SESSOES = [("1200", 171000, 239905, 1200, True), ("1300", 239905, None, 1300, False)]
EXCLUIR = {("1200", "yaw", 5)}
FASES_U1 = {1: 0.0, 2: 0.1, 3: 0.0, 4: -0.1, 5: 0.0}
virgula = FuncFormatter(lambda v, _: f"{v:g}".replace(".", ","))


def le_sessao(L, ini, fim):
    fim = fim or len(L)
    out, i = [], ini
    while i < fim:
        if '"ensaio_inicio"' in L[i]:
            ev = json.loads(L[i].split(" ", 1)[1])
            j = i + 1
            while j < fim and '"ensaio_fim"' not in L[j] and '"ensaio_abortado"' not in L[j]:
                j += 1
            ok = j < fim and '"ensaio_fim"' in L[j]
            am = [json.loads(l.split(" ", 1)[1]) for l in L[i:j + 1] if l.startswith("lab/esp32/openloop/telemetry ")]
            am = sorted({d["t"]: d for d in am if d.get("ens")}.values(), key=lambda d: d["t"])
            if ok:
                out.append((ev["tipo"], ev["n"], am))
            i = j
        i += 1
    return out


def arrays(am):
    t = np.array([d["t"] for d in am]) / 1000.0
    t -= t[0]
    g = lambda k: np.array([d[k] for d in am], float)
    phi = np.unwrap(np.radians(g("phi")))
    delta = phi - np.pi * np.round(np.median(phi) / np.pi)
    return dict(t=t, delta=delta, p=g("p"), r=g("r"), u1=g("u1"), u2=g("u2"), fase=g("fase"))


def r2(y, yh):
    return 1 - np.sum((y - yh) ** 2) / np.sum((y - np.mean(y)) ** 2)


def sim2(t, d0, p0, w, z, df):
    """Resposta exata do sistema linear de 2ª ordem a partir de (d0, p0)."""
    x = np.array([d0 - df, p0]); A = np.array([[0, 1], [-w * w, -2 * z * w]])
    lam, V = np.linalg.eig(A); c = np.linalg.solve(V, x)
    y = (V[0, :] * c) @ np.exp(np.outer(lam, t - t[0]))
    return np.real(y) + df


def roll_degraus(D):
    rep = np.where(D["fase"] == 1)[0]
    rep = rep[D["t"][rep] >= D["t"][rep[-1]] - 3.0]
    df_ant, u_ant = float(np.mean(D["delta"][rep])), 0.0
    res = []
    for f in (2, 3, 4, 5):
        idx = np.where(D["fase"] == f)[0]
        t, y = D["t"][idx], D["delta"][idx]
        d0, p0 = y[0], D["p"][idx[0]]
        fun = lambda q: sim2(t, d0, p0, q[0], q[1], q[2]) - y
        s = least_squares(fun, [W0_T, 0.1, np.mean(y[-200:])], bounds=([0.5, 0.0, -np.pi], [8.0, 1.5, np.pi]))
        w, z, df = s.x
        u = FASES_U1[f]
        K = (df - df_ant) / (u - u_ant)
        res.append(dict(fase=f, u1=u, w=float(w), zeta=float(z), delta_f_deg=float(np.degrees(df)),
                        K_rad_por_N=float(K), beta_local=float(K * w * w), beta_com_w0=float(K * W0_T**2),
                        r2=float(r2(y, sim2(t, d0, p0, w, z, df)))))
        df_ant, u_ant = df, u
    return res, float(np.degrees(np.mean(D["delta"][rep])))


def ident_yaw(D):
    m = D["fase"] >= 1
    acc = savgol_filter(D["r"], 15, 3, deriv=1, delta=0.01)[m]
    X = np.column_stack([D["u2"][m], np.ones(m.sum()), -D["r"][m]])
    (b, d, c), *_ = np.linalg.lstsq(X, acc, rcond=None)
    return dict(beta_psi=float(b), d=float(d), c_r=float(c), r2_acel=float(r2(acc, X @ np.array([b, d, c]))))


def sim_yaw(D, b, d, c):
    t, u = D["t"], D["u2"]; i0 = int(np.argmax(D["fase"] >= 1))
    r = np.full_like(t, np.nan); r[i0] = D["r"][i0]
    for k in range(i0, len(t) - 1):
        r[k + 1] = r[k] + (b * u[k] + d - c * r[k]) * (t[k + 1] - t[k])
    return r


def main():
    L = LOG.read_text(encoding="utf-8").splitlines()
    saida = {"modelo": {"beta_phi": BETA_PHI_T, "beta_psi": BETA_PSI_T, "w0": W0_T}}
    for rot, ini, fim, pwm0, travado in SESSOES:
        ens = [(tp, n, arrays(am)) for tp, n, am in le_sessao(L, ini, fim) if (rot, tp, n) not in EXCLUIR]
        rolls = [(n, D) for tp, n, D in ens if tp == "roll"]
        yaws = [(n, D) for tp, n, D in ens if tp == "yaw"]
        S = {"pwm0": pwm0, "yaw_travado_no_roll": travado, "roll": [], "yaw": []}
        print(f"\n===== PWM base {pwm0} us (yaw {'travado' if travado else 'livre'} no roll): "
              f"{len(rolls)} roll, {len(yaws)} yaw")

        fig, axs = plt.subplots(len(rolls), 1, figsize=(10, 2.8 * len(rolls)), sharex=True, squeeze=False)
        for ax, (n, D) in zip(axs[:, 0], rolls):
            deg, rep = roll_degraus(D)
            rmax = float(np.max(np.abs(D["r"][D["fase"] >= 1])))
            S["roll"].append(dict(n=n, repouso_deg=rep, degraus=deg, r_max=rmax))
            print(f"roll {n}: repouso {rep:+.1f}°, |r|max {rmax:.2f} rad/s")
            for e in deg:
                print(f"   fase {e['fase']} u1={e['u1']:+.1f}: w={e['w']:.2f} zeta={e['zeta']:.2f} "
                      f"delta_f={e['delta_f_deg']:+6.1f}°  K={np.degrees(e['K_rad_por_N']):6.1f} °/N  "
                      f"beta_local={e['beta_local']:6.1f}  beta(w0)={e['beta_com_w0']:6.1f}  R²={e['r2']:.2f}")
            ax.plot(D["t"], np.degrees(D["delta"]), lw=1.2, label="medido")
            for f in (2, 3, 4, 5):
                idx = np.where(D["fase"] == f)[0]; e = deg[f - 2]
                yy = sim2(D["t"][idx], D["delta"][idx[0]], D["p"][idx[0]], e["w"], e["zeta"], np.radians(e["delta_f_deg"]))
                ax.plot(D["t"][idx], np.degrees(yy), "--", color="tab:orange", lw=1.0,
                        label="2ª ordem ajustada por degrau" if f == 2 else None)
            ax2 = ax.twinx(); ax2.step(D["t"], D["u1"], where="post", color="gray", lw=0.8)
            ax2.set_ylim(-0.4, 0.4); ax2.set_ylabel("$u_1$ [N]"); ax2.yaxis.set_major_formatter(virgula)
            ax.set_ylabel(r"$\phi - 180°$ [°]"); ax.grid(alpha=0.3); ax.yaxis.set_major_formatter(virgula)
            ax.set_title(f"Roll {n} (PWM base {pwm0} µs)", fontsize=10)
        axs[0, 0].legend(fontsize=8, loc="upper left"); axs[-1, 0].set_xlabel("Tempo [s]")
        axs[-1, 0].xaxis.set_major_formatter(virgula)
        fig.tight_layout(); fig.savefig(AQUI / "graficos" / f"ensaio_malha_aberta_roll_{pwm0}.png", dpi=200)

        fig, axs = plt.subplots(len(yaws), 1, figsize=(10, 2.4 * len(yaws)), sharex=True, squeeze=False)
        for ax, (n, D) in zip(axs[:, 0], yaws):
            idf = ident_yaw(D)
            m = D["fase"] >= 1
            ri = sim_yaw(D, idf["beta_psi"], idf["d"], idf["c_r"])
            rt = sim_yaw(D, BETA_PSI_T, idf["d"], idf["c_r"])
            idf.update(n=n, r2_sim_id=float(r2(D["r"][m], ri[m])), r2_sim_beta_teorico=float(r2(D["r"][m], rt[m])))
            S["yaw"].append(idf)
            print(f"yaw {n}: beta={idf['beta_psi']:.3f} (teo {BETA_PSI_T:.3f})  d={idf['d']:+.3f}  c_r={idf['c_r']:.3f}  "
                  f"R² sim id={idf['r2_sim_id']:.2f}  com beta teórico={idf['r2_sim_beta_teorico']:.2f}")
            ax.plot(D["t"], D["r"], lw=1.0, label="medido")
            ax.plot(D["t"], ri, ":", lw=1.4, label=r"modelo identificado")
            ax.plot(D["t"], rt, "--", lw=1.0, label=r"$\beta_\psi$ teórico (mesmos $d$, $c_r$)")
            ax2 = ax.twinx(); ax2.step(D["t"], D["u2"], where="post", color="gray", lw=0.8)
            ax2.set_ylim(-1.0, 1.0); ax2.set_ylabel("$u_2$ [N]"); ax2.yaxis.set_major_formatter(virgula)
            ax.set_ylabel("$r$ [rad/s]"); ax.grid(alpha=0.3); ax.yaxis.set_major_formatter(virgula)
            ax.set_title(f"Yaw {n} (PWM base {pwm0} µs)", fontsize=10)
        axs[0, 0].legend(fontsize=8, loc="upper left"); axs[-1, 0].set_xlabel("Tempo [s]")
        axs[-1, 0].xaxis.set_major_formatter(virgula)
        fig.tight_layout(); fig.savefig(AQUI / "graficos" / f"ensaio_malha_aberta_yaw_{pwm0}.png", dpi=200)

        b = np.array([e["beta_psi"] for e in S["yaw"]])
        Kp = np.array([e["K_rad_por_N"] for r_ in S["roll"] for e in r_["degraus"] if e["fase"] == 2])
        Kall = np.array([e["K_rad_por_N"] for r_ in S["roll"] for e in r_["degraus"]])
        bl = np.array([e["beta_local"] for r_ in S["roll"] for e in r_["degraus"]])
        w = np.array([e["w"] for r_ in S["roll"] for e in r_["degraus"]])
        S["resumo"] = dict(beta_psi=[float(b.mean()), float(b.std(ddof=1))],
                           K_primeiro_degrau_graus_por_N=[float(np.degrees(Kp.mean())), float(np.degrees(Kp.std(ddof=1)))],
                           K_todos_graus_por_N=[float(np.degrees(Kall.mean())), float(np.degrees(Kall.std(ddof=1)))],
                           K_teorico_graus_por_N=float(np.degrees(BETA_PHI_T / W0_T**2)),
                           beta_local=[float(bl.mean()), float(bl.std(ddof=1))],
                           w=[float(w.mean()), float(w.std(ddof=1))])
        print(f"RESUMO {pwm0}: beta_psi = {b.mean():.3f} ± {b.std(ddof=1):.3f} (teo {BETA_PSI_T:.3f}); "
              f"K 1º degrau = {np.degrees(Kp.mean()):.0f} ± {np.degrees(Kp.std(ddof=1)):.0f} °/N, "
              f"K todos = {np.degrees(Kall.mean()):.0f} ± {np.degrees(Kall.std(ddof=1)):.0f} °/N "
              f"(teo {np.degrees(BETA_PHI_T / W0_T**2):.0f}); w = {w.mean():.2f} ± {w.std(ddof=1):.2f} (w0 {W0_T:.2f}); "
              f"beta_local = {bl.mean():.1f} ± {bl.std(ddof=1):.1f} (teo {BETA_PHI_T:.1f})")
        saida[f"pwm_{pwm0}"] = S
    (AQUI / "dados" / "ensaio_malha_aberta_v2.json").write_text(json.dumps(saida, indent=2, ensure_ascii=False), encoding="utf-8")
    print("\nsalvo dados/ensaio_malha_aberta_v2.json e figuras")


if __name__ == "__main__":
    main()
