import json
from pathlib import Path

import numpy as np
from scipy.optimize import least_squares
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

import analisaEnsaioMalhaAberta_v2 as v2

AQUI = Path(__file__).resolve().parent
W0, Z0 = v2.W0_T, 0.03
virgula = FuncFormatter(lambda v, _: f"{v:g}".replace(".", ","))


def trocas(u):
    return np.where(np.abs(np.diff(u)) > 1e-6)[0] + 1


def yaw_dubletes(D):
    t, r, u = D["t"], D["r"], D["u2"]
    tr = trocas(u)
    res = []
    for k in range(len(tr) - 1):
        i, j = tr[k], tr[k + 1]
        if u[i] == 0 or u[j] == 0 or np.sign(u[i]) == np.sign(u[j]):
            continue
        fim = tr[k + 2] if k + 2 < len(tr) else len(t)
        m1 = (t >= t[i] + 0.1) & (t < t[j]); m2 = (t >= t[j] + 0.1) & (t < t[fim - 1])
        s1 = np.polyfit(t[m1], r[m1], 1)[0]; s2 = np.polyfit(t[m2], r[m2], 1)[0]
        res.append(dict(t=float(t[i]), u_mais=float(u[i]), s1=float(s1), s2=float(s2),
                        beta_psi=float((s1 - s2) / (u[i] - u[j]))))
    return res


def roll_trocas(D, meia=0.5):
    t, d, p, u = D["t"], D["delta"], D["p"], D["u1"]
    res = []
    for i in trocas(u):
        m = (t >= t[i] - meia) & (t <= t[i] + meia)
        tt, yy, uu = t[m], d[m], u[m]
        i0 = np.argmax(m)
        def sim(q):
            a, beta = q
            x = np.array([d[i0], p[i0]]); out = np.empty(len(tt)); out[0] = x[0]
            for k in range(len(tt) - 1):
                h = tt[k + 1] - tt[k]
                f = lambda x_: np.array([x_[1], -W0**2 * np.sin(x_[0]) - 2 * Z0 * W0 * x_[1] + a + beta * uu[k]])
                k1 = f(x); k2 = f(x + h / 2 * k1); k3 = f(x + h / 2 * k2); k4 = f(x + h * k3)
                x = x + h / 6 * (k1 + 2 * k2 + 2 * k3 + k4); out[k + 1] = x[0]
            return out
        s = least_squares(lambda q: sim(q) - yy, [0.0, v2.BETA_PHI_T])
        yh = sim(s.x)
        res.append(dict(t=float(t[i]), du=float(u[i] - u[i - 1]), a=float(s.x[0]), beta_phi=float(s.x[1]),
                        r2=float(v2.r2(yy, yh)), _tt=tt, _yy=yy, _yh=yh))
    return res


def main():
    L = v2.LOG.read_text(encoding="utf-8").splitlines()
    out = {"modelo": {"beta_phi": v2.BETA_PHI_T, "beta_psi": v2.BETA_PSI_T, "w0": W0, "zeta0": Z0}}
    fig, axs = plt.subplots(1, 2, figsize=(11, 4))
    for c, (rot, ini, fim, pwm0, trav) in enumerate(v2.SESSOES):
        ens = [(tp, n, v2.arrays(am)) for tp, n, am in v2.le_sessao(L, ini, fim) if (rot, tp, n) not in v2.EXCLUIR]
        by = [dict(n=n, **e) for tp, n, D in ens if tp == "yaw" for e in yaw_dubletes(D)]
        br = []
        for tp, n, D in ens:
            if tp != "roll":
                continue
            for e in roll_trocas(D):
                br.append(dict(n=n, **e))
        bpsi = np.array([e["beta_psi"] for e in by])
        bphi = np.array([e["beta_phi"] for e in br]); r2s = np.array([e["r2"] for e in br])
        bom = r2s > 0.9
        print(f"\n== PWM base {pwm0} us ==")
        print(f"yaw : {len(bpsi)} dubletes, beta_psi = {bpsi.mean():.3f} ± {bpsi.std(ddof=1):.3f}  "
              f"(teo {v2.BETA_PSI_T:.3f}, razão {bpsi.mean()/v2.BETA_PSI_T:.2f})  valores: {np.round(bpsi, 3)}")
        print(f"roll: {len(bphi)} trocas, R²>0,9 em {bom.sum()}; beta_phi (R²>0,9) = {bphi[bom].mean():.1f} ± {bphi[bom].std(ddof=1):.1f}  "
              f"(teo {v2.BETA_PHI_T:.1f}, razão {bphi[bom].mean()/v2.BETA_PHI_T:.2f})")
        for e in br:
            print(f"   roll {e['n']} t={e['t']:5.1f} du={e['du']:+.1f}: beta={e['beta_phi']:6.1f} a={e['a']:+6.2f} R²={e['r2']:.3f}")
        out[f"pwm_{pwm0}"] = dict(
            yaw=dict(dubletes=by, beta_psi=[float(bpsi.mean()), float(bpsi.std(ddof=1))]),
            roll=dict(trocas=[{k: v for k, v in e.items() if not k.startswith("_")} for e in br],
                      beta_phi_r2_0_9=[float(bphi[bom].mean()), float(bphi[bom].std(ddof=1)), int(bom.sum())]))
        axs[0].plot(np.full(len(bphi[bom]), pwm0) + np.random.uniform(-8, 8, bom.sum()), bphi[bom], "o", mfc="none")
        axs[1].plot(np.full(len(bpsi), pwm0) + np.random.uniform(-8, 8, len(bpsi)), bpsi, "o", mfc="none")
    for a_, val, nome in ((axs[0], v2.BETA_PHI_T, r"$\beta_\phi$ [1/(kg.m)]"), (axs[1], v2.BETA_PSI_T, r"$\beta_\psi$ [1/(kg.m)]")):
        a_.axhline(val, color="r", ls="--", lw=1, label="modelo")
        a_.set_xlabel("PWM base [µs]"); a_.set_ylabel(nome); a_.grid(alpha=0.3); a_.legend(fontsize=8)
        a_.set_xticks([1200, 1300]); a_.yaxis.set_major_formatter(virgula)
    axs[0].set_title("Roll: estimativa local em cada degrau (R² > 0,9)", fontsize=10)
    axs[1].set_title("Yaw: diferença de inclinações em cada dublete", fontsize=10)
    fig.tight_layout(); fig.savefig(AQUI / "graficos" / "ensaio_malha_aberta_locais.png", dpi=200)
    (AQUI / "dados" / "ensaio_malha_aberta_v3.json").write_text(json.dumps(out, indent=2, ensure_ascii=False), encoding="utf-8")
    print("\nsalvo dados/ensaio_malha_aberta_v3.json e graficos/ensaio_malha_aberta_locais.png")


if __name__ == "__main__":
    np.random.seed(0)
    main()
