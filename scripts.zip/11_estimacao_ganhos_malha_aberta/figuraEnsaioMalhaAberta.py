from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

import analisaEnsaioMalhaAberta_v2 as v2
import analisaEnsaioMalhaAberta_v3 as v3

AQUI = Path(__file__).resolve().parent
virgula = FuncFormatter(lambda v, _: f"{v:g}".replace(".", ","))
ROLL_N, YAW_N = 2, 3


def main():
    L = v2.LOG.read_text(encoding="utf-8").splitlines()
    rot, ini, fim, pwm0, _ = v2.SESSOES[1]
    ens = {(tp, n): v2.arrays(am) for tp, n, am in v2.le_sessao(L, ini, fim)}
    R, Y = ens[("roll", ROLL_N)], ens[("yaw", YAW_N)]

    fig, ax = plt.subplots(2, 1, figsize=(10, 7.5))
    a = ax[0]
    a.plot(R["t"], np.degrees(R["delta"]), lw=1.3, label="medido")
    for k, e in enumerate(v3.roll_trocas(R)):
        a.axvspan(e["_tt"][0], e["_tt"][-1], color="gray", alpha=0.12)
        a.plot(e["_tt"], np.degrees(e["_yh"]), "--", color="tab:red", lw=1.6,
               label="modelo ajustado na janela de ±0,5 s" if k == 0 else None)
    a2 = a.twinx(); a2.step(R["t"], R["u1"], where="post", color="k", lw=0.8)
    a2.set_ylim(-0.4, 0.4); a2.set_ylabel("$u_1$ [N]"); a2.yaxis.set_major_formatter(virgula)
    a.set(title="(a) Roll", xlabel="Tempo [s]", ylabel=r"$\phi - 180°$ [°]")
    a.legend(fontsize=8, loc="lower left")

    a = ax[1]
    a.plot(Y["t"], Y["r"], lw=1.0, label="medido")
    t, r, u = Y["t"], Y["r"], Y["u2"]
    for k, e in enumerate(v3.yaw_dubletes(Y)):
        tr = v3.trocas(u); i = int(np.argmin(np.abs(t - e["t"]))); j = tr[tr > i][0]
        fimd = tr[tr > j][0] if np.any(tr > j) else len(t) - 1
        for (a0, a1) in ((i, j), (j, fimd)):
            m = (t >= t[a0] + 0.1) & (t < t[a1])
            c = np.polyfit(t[m], r[m], 1)
            a.plot(t[m], np.polyval(c, t[m]), color="tab:red", lw=2,
                   label="retas ajustadas em cada metade do dublete" if (k == 0 and a0 == i) else None)
    a2 = a.twinx(); a2.step(t, u, where="post", color="k", lw=0.8)
    a2.set_ylim(-1.0, 1.0); a2.set_ylabel("$u_2$ [N]"); a2.yaxis.set_major_formatter(virgula)
    a.set(title="(b) Yaw", xlabel="Tempo [s]", ylabel="$r$ [rad/s]")
    a.legend(fontsize=8, loc="lower left")
    for a in ax:
        a.grid(alpha=0.3); a.xaxis.set_major_formatter(virgula); a.yaxis.set_major_formatter(virgula)
        a.title.set_fontsize(10)
    fig.tight_layout()
    saida = AQUI / "graficos" / "ensaio_malha_aberta_texto.png"
    fig.savefig(saida, dpi=200)
    print("salvo", saida)


if __name__ == "__main__":
    main()
