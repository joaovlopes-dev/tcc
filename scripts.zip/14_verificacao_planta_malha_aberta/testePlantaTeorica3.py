import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
import numpy as np
from scipy import signal

AQUI = Path(__file__).resolve().parent
G5 = json.load(open(AQUI / "dados" / "ganhos_pid_v5.json", encoding="utf-8"))
beta_phi, beta_psi, a = G5["beta_phi"], G5["beta_psi"], G5["w0_quadrado"]

virgula = FuncFormatter(lambda v, _: f"{v:g}".replace(".", ","))

A = np.array([[0, 0, 1, 0],
              [0, 0, 0, 1],
              [a, 0, 0, 0],
              [0, 0, 0, 0]], dtype=float)
B = np.array([[0, 0], [0, 0], [beta_phi, 0], [0, beta_psi]], dtype=float)
C = np.array([[1, 0, 0, 0], [0, 1, 0, 0]], dtype=float)
D = np.zeros((2, 2))

n = 4
ctrl = np.hstack([np.linalg.matrix_power(A, i) @ B for i in range(n)])
obs = np.vstack([C @ np.linalg.matrix_power(A, i) for i in range(n)])
print(f"w0^2 = {a:.3f} s^-2, beta_phi = {beta_phi:.3f}, beta_psi = {beta_psi:.4f}")
print(f"posto controlabilidade = {np.linalg.matrix_rank(ctrl)}, observabilidade = {np.linalg.matrix_rank(obs)}")
print("polos da planta:", np.round(np.linalg.eigvals(A), 4))

sys = signal.StateSpace(A, B, C, D)
t_r = np.arange(0, 1.0, 1e-3)
t_y = np.arange(0, 5.0, 1e-3)
_, _, x_roll = signal.lsim(sys, np.column_stack([np.ones(len(t_r)), np.zeros(len(t_r))]), t_r)
_, _, x_yaw = signal.lsim(sys, np.column_stack([np.zeros(len(t_y)), np.ones(len(t_y))]), t_y)
print(f"roll em 1 s: phi = {np.degrees(x_roll[-1, 0]):.0f} graus; yaw em 5 s: psi = {np.degrees(x_yaw[-1, 1]):.0f} graus")

fig, axes = plt.subplots(2, 2, figsize=(11, 7))
paineis = [
    (axes[0, 0], t_r, x_roll[:, 0], r"(a) Degrau em $u_1$: ângulo de \textit{roll}", r"$\phi$ [°]", "tab:blue"),
    (axes[1, 0], t_r, x_roll[:, 2], r"(b) Degrau em $u_1$: velocidade de \textit{roll}", r"$p$ [°/s]", "tab:orange"),
    (axes[0, 1], t_y, x_yaw[:, 1], r"(c) Degrau em $u_2$: ângulo de \textit{yaw}", r"$\psi$ [°]", "tab:green"),
    (axes[1, 1], t_y, x_yaw[:, 3], r"(d) Degrau em $u_2$: velocidade de \textit{yaw}", r"$r$ [°/s]", "tab:red"),
]
for ax, t, y, titulo, ylabel, cor in paineis:
    ax.plot(t, np.degrees(y), color=cor)
    ax.set_title(titulo.replace(r"\textit{roll}", "roll").replace(r"\textit{yaw}", "yaw"), fontsize=10)
    ax.set_xlabel("Tempo [s]")
    ax.set_ylabel(ylabel)
    ax.grid(True, alpha=0.4)
    ax.xaxis.set_major_formatter(virgula)
    ax.yaxis.set_major_formatter(virgula)
plt.tight_layout()
caminho = AQUI / "graficos" / "resposta_malha_aberta_v3.png"
plt.savefig(caminho, dpi=200)
print("salvo", caminho)
