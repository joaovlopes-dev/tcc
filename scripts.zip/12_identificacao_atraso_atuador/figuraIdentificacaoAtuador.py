import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

import reprojetoRollAtuador as R

virg = FuncFormatter(lambda v, _: f"{v:g}".replace(".", ","))


def main():
    runs = R.carrega_disparos()
    idt = R.identifica(runs)
    tau, Td = idt["tau"], idt["Td"]
    print(f"melhor ajuste: tau_a {tau*1000:.0f} ms, Td {Td*1000:.0f} ms, beta {idt['beta_id']:.1f}, R2 {idt['r2']:.3f}; "
          f"tau_a 8 ms sem atraso: R2 {idt['r2_8ms']:.3f}")
    fig, ax = plt.subplots(1, 2, figsize=(11, 4))
    a = ax[0]
    im = a.contourf(idt["nds"] * 10, idt["taus"] * 1000, idt["R2"], levels=20, cmap="viridis")
    a.plot(Td * 1000, tau * 1000, "r*", ms=12, label="melhor ajuste")
    a.plot(0, 8, "wo", ms=8, mec="k", label=r"$\tau_a$ = 8 ms, sem atraso")
    cb = fig.colorbar(im, ax=a, label="$R^2$"); cb.ax.yaxis.set_major_formatter(virg)
    a.set(xlabel="atraso puro $T_d$ [ms]", ylabel=r"$\tau_a$ [ms]")
    a.set_title("(a) Coeficiente de determinação do ajuste", loc="left")
    a.legend(fontsize=8, loc="upper right")
    a = ax[1]
    r = runs[2]; nd = int(round(Td / 0.01)); uf = R.filtra(r["u"], tau, nd)
    _, th = R.regressao([r], tau, nd)
    p_mod = np.zeros_like(r["p"]); p_mod[0] = r["p"][0]
    for k in range(1, len(p_mod)):
        p_mod[k] = p_mod[k - 1] + 0.01 * (R.W0Q * np.sin(r["phi"][k - 1]) - 2 * R.Z0 * R.W0 * p_mod[k - 1] + th[0] * uf[k - 1] + th[1])
    a.plot(r["t"], r["p"], lw=1.2, label="medido")
    a.plot(r["t"], p_mod, lw=1.2, ls="--", label=fr"modelo, $\tau_a$ = {tau*1000:.0f} ms e $T_d$ = {Td*1000:.0f} ms")
    a.set(xlabel="tempo [s]", ylabel="$p$ [rad/s]")
    a.set_title("(b) Velocidade de roll em um dos registros", loc="left")
    a.legend(fontsize=8)
    for a in ax:
        a.grid(alpha=0.3); a.xaxis.set_major_formatter(virg); a.yaxis.set_major_formatter(virg)
    fig.tight_layout(); fig.savefig(R.AQUI / "graficos" / "identificacao_atuador_v6.png", dpi=200)


if __name__ == "__main__":
    main()
