import json
from pathlib import Path

import numpy as np
from scipy.signal import cont2discrete
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

AQUI = Path(__file__).resolve().parent
G = json.loads((AQUI / "dados" / "ganhos_pid_v5.json").read_text(encoding="utf-8"))
BPHI_NOM, BPSI_NOM, W0Q = G["beta_phi"], G["beta_psi"], G["w0_quadrado"]
W0 = np.sqrt(W0Q); Z0 = 0.03
T0, TMAX, TS = G["T0_N"], G["T_max_N"], G["Ts"]
K_ATUAL = (G["roll"]["Kp"], G["roll"]["Ki"], G["roll"]["Kd"])
KY = (G["yaw"]["Kp"], G["yaw"]["Ki"], G["yaw"]["Kd"])
CA, CB, CC = 3.597e-6, -6.182e-3, 2.723                    # eq:ajuste_empuxo
I_XX = 0.212 / BPHI_NOM
virgula = FuncFormatter(lambda v, _: f"{v:g}".replace(".", ","))
LOG = AQUI / "dados" / "controlador_motores_log.txt"
DISPAROS = [(34100, 34300), (35250, 35460), (45500, 45745), (51550, 51770)]   # linhas do log


def empuxo(pwm):
    pwm = np.asarray(pwm, float)
    return np.where(pwm <= 1040, 0.0, np.clip(CA * pwm**2 + CB * pwm + CC, 0, TMAX))


# ------------------------------------------------------------------ 1. identificação
def carrega_disparos():
    L = LOG.read_text(encoding="utf-8").splitlines()
    runs = []
    for a, b in DISPAROS:
        R = [json.loads(l.split(" ", 1)[1]) for l in L[a - 1:b] if l.startswith("lab/esp32/controle/telemetry")]
        R = [r for r in R if r["modo"] > 0]
        pw = np.array([r["pwm"] for r in R], float)
        runs.append(dict(t=(np.array([r["t"] for r in R]) - R[0]["t"]) / 1000,
                         phi=np.radians([r["phi"] for r in R]), p=np.array([r["p"] for r in R]),
                         u=empuxo(pw[:, 3]) - empuxo(pw[:, 1])))
    return runs


def filtra(u, tau, nd, dt=0.01):
    """u (ZOH a cada dt) -> atraso de nd amostras -> 1ª ordem tau."""
    if nd:
        u = np.concatenate([np.zeros(nd), u[:-nd]])
    if tau <= 0:
        return np.concatenate([[0.0], u[:-1]])
    a = 1 - np.exp(-dt / tau); y = np.zeros_like(u)
    for k in range(1, len(u)):
        y[k] = y[k - 1] + a * (u[k - 1] - y[k - 1])
    return y


def regressao(runs, tau, nd, dt=0.01):
    X, Y = [], []
    for r in runs:
        uf = filtra(r["u"], tau, nd, dt); p = r["p"]
        dp = (p[2:] - p[:-2]) / (2 * dt)
        Y.append(dp - (W0Q * np.sin(r["phi"][1:-1]) - 2 * Z0 * W0 * p[1:-1]))
        X.append(np.c_[uf[1:-1], np.ones(len(dp))])
    X = np.vstack(X); Y = np.concatenate(Y)
    th, *_ = np.linalg.lstsq(X, Y, rcond=None)
    return 1 - np.var(Y - X @ th) / np.var(Y), th


def identifica(runs):
    taus = np.arange(0, 0.155, 0.005); nds = np.arange(0, 9)
    R2 = np.zeros((len(taus), len(nds))); BE = np.zeros_like(R2)
    for i, tau in enumerate(taus):
        for j, nd in enumerate(nds):
            r2, th = regressao(runs, tau, nd); R2[i, j] = r2; BE[i, j] = th[0]
    i, j = np.unravel_index(np.argmax(R2), R2.shape)
    r2_8, th_8 = regressao(runs, 0.008, 0)
    return dict(taus=taus, nds=nds, R2=R2, beta=BE, tau=float(taus[i]), Td=float(nds[j] * 0.01),
                r2=float(R2[i, j]), beta_id=float(BE[i, j]), r2_8ms=float(r2_8), beta_8ms=float(th_8[0]))


# ------------------------------------------------------------------ 3. análise linear discreta
def ganhos(wn, zeta, rho, beta):
    """Alocação de polos (s²+2 zeta wn s+wn²)(s+rho wn) para p' = w0² phi + beta u (Seção 3.4)."""
    Kd = (2 * zeta + rho) * wn / beta
    Kp = ((1 + 2 * zeta * rho) * wn**2 + W0Q) / beta
    Ki = rho * wn**3 / beta
    return Kp, Ki, Kd


def zmax(K, beta, a, tau, Td):
    """max|z| da malha discreta de um canal: planta [y, y', u_ef], atuador tau, atraso Td (+1 amostra
    de cálculo já incluída em Td), integrador como no firmware. a = +w0² (phi=0) ou -w0² (phi=180°)."""
    Kp, Ki, Kd = K
    if tau > 0:
        Ac = np.array([[0, 1, 0], [a, -2 * Z0 * W0, beta], [0, 0, -1 / tau]]); Bc = np.array([[0], [0], [1 / tau]])
    else:
        Ac = np.array([[0, 1], [a, -2 * Z0 * W0]]); Bc = np.array([[0], [beta]])
    n = Ac.shape[0]
    Ad, Bd, *_ = cont2discrete((Ac, Bc, np.eye(n), np.zeros((n, 1))), TS, "zoh")
    N = max(1, int(round(Td / TS)))                      # nº de amostras de atraso (>= 1: cálculo)
    dim = n + 1 + N                                      # [x, e, fila de u (N)]
    M = np.zeros((dim, dim))
    M[:n, :n] = Ad; M[:n, n + N] = Bd[:, 0]              # entra o u mais antigo da fila
    M[n, 0] = -TS; M[n, n] = 1                           # e[k+1] = e[k] - Ts y[k]
    M[n + 1, 0] = -Kp; M[n + 1, 1] = -Kd; M[n + 1, n] = Ki
    for q in range(1, N):
        M[n + 1 + q, n + q] = 1                          # desloca a fila
    return float(np.max(np.abs(np.linalg.eigvals(M))))


def margem_atraso(K, beta, a, tau, Td, passo=0.005, maximo=0.2):
    """Maior atraso ADICIONAL (s) com a malha ainda estável (0 se já instável)."""
    if zmax(K, beta, a, tau, Td) >= 1:
        return 0.0
    extra = 0.0
    while extra < maximo and zmax(K, beta, a, tau, Td + extra + passo) < 1:
        extra += passo
    return extra


# ------------------------------------------------------------------ 2 e 4. simulação não linear
def simula(Kr, beta, tau, Td, phi_ini=np.radians(170), t_sub=12.0, t_op=14.0, ref_phi=None, ref_psi=None,
           empurrao_yaw=None, tau_d=0.03, a_psi=0.05, bpsi_f=1.3, dt=0.0005, so_rampa=False, ff=False, beta_hat=None):
    """Sequência do firmware: rampa (2 s, phi_traj = phi_ini) -> subida cossenoidal até 0 -> operação.
    Lei de rastreamento do firmware, alocação com prioridade do roll, integração condicional por
    canal, cortes de segurança. Atuador: atraso Td (inclui a amostra de cálculo) + 1ª ordem tau em cada empuxo."""
    t_ramp = 2.0; dur_sub = t_sub * abs(phi_ini) / np.pi
    t_fim = t_ramp + (0.0 if so_rampa else dur_sub + t_op) + (1.0 if so_rampa else 0.0)
    n = int(t_fim / dt); m = int(round(TS / dt)); N = max(1, int(round(Td / TS)))
    phi, p, Om, psi = phi_ini, 0.0, 0.0, 0.0
    e = np.zeros(2); errant = np.zeros(2); yaw_on = False
    fila = [np.zeros(4)] * N; Tef = np.zeros(4); Tcmd = np.zeros(4)
    corte = None; H = {k: [] for k in ("t", "phi", "phitr", "psi", "u1", "p")}
    for k in range(n):
        t = k * dt
        if k % m == 0 and corte is None:
            pddtr = 0.0
            if t < t_ramp:
                modo, ptr, pdtr, Tb = 1, phi_ini, 0.0, T0 * t / t_ramp
            elif t < t_ramp + dur_sub:
                s = np.pi * (t - t_ramp) / dur_sub
                modo, Tb = 2, T0
                ptr = phi_ini * (1 - (1 - np.cos(s)) / 2); pdtr = -phi_ini * np.pi / (2 * dur_sub) * np.sin(s)
                pddtr = -phi_ini * np.pi**2 / (2 * dur_sub**2) * np.cos(s)
            else:
                modo, ptr, pdtr, Tb = 3, 0.0, 0.0, T0
            uff = (pddtr - W0Q * np.sin(ptr)) / beta_hat if (ff and modo != 3) else 0.0
            if modo == 3 and not yaw_on and abs(phi) < np.radians(10) and abs(p) < 0.2:
                yaw_on = True; psi = 0.0; e[1] = 0.0; errant[1] = 0.0
            r_b = Om * np.cos(phi)
            # cortes
            erro_c = abs(phi) if modo == 3 else abs(phi - ptr)
            if erro_c > np.radians(45):
                corte = (t, "limite_phi" if modo == 3 else "erro_rastreamento")
            elif abs(p) > 3:
                corte = (t, "limite_p")
            elif abs(r_b) > 3:
                corte = (t, "limite_r")
            if corte is not None:
                fila = [np.zeros(4)] * N; Tcmd = np.zeros(4)
            else:
                alvo_phi = (ref_phi(t) if ref_phi else 0.0) if modo == 3 else ptr
                alvo_psi = ref_psi(t) if ref_psi else 0.0
                err = np.array([alvo_phi - phi, alvo_psi - psi])
                en = e + 0.5 * TS * (err + errant)
                u1 = Kr[0] * (ptr - phi) + Kr[2] * (pdtr - p) + Kr[1] * en[0] + uff
                u2 = (-KY[0] * psi - KY[2] * r_b + KY[1] * en[1]) if yaw_on else float(np.clip(-KY[2] * r_b, -1, 1))
                m1 = 2 * min(Tb, TMAX - Tb); u1s = float(np.clip(u1, -m1, m1)); aa = abs(u1s) / 2
                u2s = float(np.clip(u2, 4 * max(aa - Tb, Tb - TMAX), 4 * min(TMAX - Tb - aa, Tb)))
                if (u1s != u1) and err[0] * u1 > 0:
                    en[0] = e[0]
                if (u2s != u2) and err[1] * u2 > 0:
                    en[1] = e[1]
                e[0] = en[0]; errant[0] = err[0]
                if yaw_on:
                    e[1] = en[1]; errant[1] = err[1]
                T = np.array([Tb - u2s / 4, Tb + u2s / 4 - u1s / 2, Tb - u2s / 4, Tb + u2s / 4 + u1s / 2])
                fila = fila[1:] + [T]; Tcmd = fila[0]
        Tef += (Tcmd - Tef) * (dt / tau if tau > 0 else 1.0)
        u1e = Tef[3] - Tef[1]; u2e = Tef[1] + Tef[3] - Tef[0] - Tef[2]
        on = Tef.max() > 1e-3
        dp = W0Q * np.sin(phi) - 2 * Z0 * W0 * p + beta * u1e + (tau_d / I_XX if on else 0.0)
        dOm = BPSI_NOM * bpsi_f * u2e * np.cos(phi) + (a_psi if on else 0.0)
        if empurrao_yaw and empurrao_yaw[0] <= t < empurrao_yaw[0] + 0.1:
            dOm += empurrao_yaw[1] / 0.1
        p += dp * dt; Om += dOm * dt; phi += p * dt; psi += Om * np.cos(phi) * dt
        if k % 20 == 0:
            H["t"].append(t); H["phi"].append(phi); H["psi"].append(psi); H["u1"].append(u1e); H["p"].append(p)
            H["phitr"].append(ptr if corte is None else np.nan)
    H = {k: np.array(v) for k, v in H.items()}; H["corte"] = corte
    return H


def main():
    out = {}
    # ---------------- 1
    runs = carrega_disparos()
    idt = identifica(runs)
    tau_id, Td_id, beta_id = idt["tau"], idt["Td"], idt["beta_id"]
    # vale (tau + Td) bem determinado: lista combinações com R² a menos de 0,01 do máximo
    vale = [(float(idt["taus"][i]), float(idt["nds"][j] * 0.01), float(idt["R2"][i, j]), float(idt["beta"][i, j]))
            for i in range(len(idt["taus"])) for j in range(len(idt["nds"])) if idt["R2"][i, j] > idt["r2"] - 0.01]
    soma = [a + b for a, b, *_ in vale]
    print(f"1) identificação: melhor tau_a = {tau_id*1000:.0f} ms, Td = {Td_id*1000:.0f} ms, beta = {beta_id:.1f}, R² = {idt['r2']:.3f}")
    print(f"   tau_a = 8 ms sem atraso (projeto): R² = {idt['r2_8ms']:.3f}, beta = {idt['beta_8ms']:.1f}")
    print(f"   combinações a menos de 0,01 do melhor R²: tau_a + Td entre {min(soma)*1000:.0f} e {max(soma)*1000:.0f} ms ({len(vale)} pontos)")
    out["identificacao"] = dict(tau_a_s=tau_id, Td_s=Td_id, beta=beta_id, R2=idt["r2"], R2_tau8ms=idt["r2_8ms"],
                                beta_tau8ms=idt["beta_8ms"], vale_tau_mais_Td_s=[min(soma), max(soma)],
                                obs="Td inclui a amostra de telemetria (10 ms), o quadro PWM de 50 Hz, o DLPF do MPU-6050 e o atraso do ESC/motor")

    # modelos do atuador: 4 pontos do vale (tau_a, Td, beta) que explicam os dados igualmente bem
    vale.sort(key=lambda v: v[0])
    # só os pontos do vale com beta compatível com o ensaio em malha aberta (19,7 +- 7,1):
    # os pontos de tau_a alto exigem beta de 30 a 39, fora dessa faixa
    BETA_MA, DBETA_MA = 19.7, 7.1
    vale_c = [v for v in vale if v[3] <= BETA_MA + DBETA_MA]
    out["vale_completo"] = [dict(tau=v[0], Td=v[1], R2=v[2], beta=v[3]) for v in vale]
    idx = np.unique(np.round(np.linspace(0, len(vale_c) - 1, 4)).astype(int))
    MOD = [dict(tau=vale_c[i_][0], Td=vale_c[i_][1], beta=vale_c[i_][3]) for i_ in idx]
    print("   modelos usados no reprojeto (tau_a, Td, beta):", [(round(m_["tau"]*1000), round(m_["Td"]*1000), round(m_["beta"], 1)) for m_ in MOD])
    out["modelos_atuador"] = MOD
    FB = (0.8, 1.0, 1.25)                                         # incerteza adicional em beta
    CEN = {"50 Hz (atual)": 0.0, "ESC 400 Hz": -0.010, "ESC 400 Hz + DLPF 44 Hz": -0.014}
    ATR0 = 0.005                                                  # amostra de cálculo do firmware

    def pior(K, dTd, com_margem=True):
        zs, ms_ = [], []
        for m_ in MOD:
            for f in FB:
                for a in (W0Q, -W0Q):
                    Td = m_["Td"] + ATR0 + dTd
                    zs.append(zmax(K, m_["beta"] * f, a, m_["tau"], Td))
        mz = max(zs)
        if not com_margem or mz >= 1:
            return mz, 0.0
        for m_ in MOD:
            for f in FB:
                for a in (W0Q, -W0Q):
                    ms_.append(margem_atraso(K, m_["beta"] * f, a, m_["tau"], m_["Td"] + ATR0 + dTd))
        return mz, min(ms_)

    # ---------------- 2 (análise linear dos ganhos atuais)
    print("\n2) ganhos atuais com o atuador identificado:")
    out["ganhos_atuais"] = {}
    for nome, d in CEN.items():
        mz, ma = pior(K_ATUAL, d)
        print(f"   {nome:24s}: pior max|z| {mz:.3f} -> {'INSTÁVEL' if mz >= 1 else 'estável'}")
        out["ganhos_atuais"][nome] = dict(zmax=mz)

    # ---------------- 3
    print("\n3) reprojeto por alocação de polos (beta de projeto = melhor ajuste):")
    linhas = []
    for zeta in (0.5, 0.7, 0.9):
        for wn in np.arange(1.0, 3.01, 0.25):
            for rho in (0.5, 1.0, 1.5, 2.0, 3.0):
                K = ganhos(wn, zeta, rho, beta_id)
                res = {nome: pior(K, d) for nome, d in CEN.items()}
                linhas.append(dict(zeta=zeta, wn=float(wn), rho=rho, K=K, res=res))
    out["varredura"] = [dict(zeta=L_["zeta"], wn=L_["wn"], rho=L_["rho"], Kp=L_["K"][0], Ki=L_["K"][1], Kd=L_["K"][2],
                             **{c: dict(zmax=v[0], margem_atraso_s=v[1]) for c, v in L_["res"].items()}) for L_ in linhas]
    top = sorted(linhas, key=lambda L_: (-L_["res"]["50 Hz (atual)"][1], -L_["wn"]))[:10]
    print("   10 melhores pela margem de atraso no cenário de 50 Hz (pior caso em 4 modelos x 3 betas x phi 0/180°):")
    print("   zeta  wn   rho    Kp     Ki     Kd  | margem [ms]: 50 Hz / 400 Hz / 400 Hz+DLPF")
    for L_ in top:
        print(f"   {L_['zeta']:.1f} {L_['wn']:5.2f} {L_['rho']:4.1f} {L_['K'][0]:6.3f} {L_['K'][1]:6.3f} {L_['K'][2]:6.3f} | "
              + " / ".join(f"{L_['res'][c][1]*1000:3.0f}" for c in CEN))
    # escolha: entre os de margem >= 80 % da melhor, o de maior wn (melhor rejeição de perturbação)
    mmax = top[0]["res"]["50 Hz (atual)"][1]
    cand = [L_ for L_ in linhas if L_["res"]["50 Hz (atual)"][1] >= 0.8 * mmax]
    esc = max(cand, key=lambda L_: (L_["wn"], L_["res"]["50 Hz (atual)"][1]))
    Kn = esc["K"]
    print(f"\n   ESCOLHA: zeta = {esc['zeta']}, wn = {esc['wn']:.2f}, rho = {esc['rho']}, Kp = {Kn[0]:.3f}, Ki = {Kn[1]:.3f}, Kd = {Kn[2]:.3f}")
    for c in CEN:
        print(f"     {c:24s}: pior max|z| {esc['res'][c][0]:.4f}, margem de atraso {esc['res'][c][1]*1000:.0f} ms")
    out["escolha"] = dict(zeta=esc["zeta"], wn=esc["wn"], rho=esc["rho"], beta_projeto=beta_id, Kp=Kn[0], Ki=Kn[1], Kd=Kn[2],
                          criterio="margem de atraso >= 80 % da melhor da varredura (50 Hz); entre esses, maior wn",
                          cenarios={c: dict(zmax=v[0], margem_atraso_s=v[1]) for c, v in esc["res"].items()})
    # yaw
    print("\n   yaw (ganhos atuais) com o atuador identificado:")
    out["yaw"] = {}
    for nome, d in CEN.items():
        zs = [zmax(KY, BPSI_NOM * f, 0.0, m_["tau"], m_["Td"] + ATR0 + d) for m_ in MOD for f in (1.0, 1.22, 1.44)]
        ms_ = [margem_atraso(KY, BPSI_NOM * f, 0.0, m_["tau"], m_["Td"] + ATR0 + d) for m_ in MOD for f in (1.0, 1.22, 1.44)]
        print(f"     {nome:24s}: pior max|z| {max(zs):.4f}, margem de atraso {min(ms_)*1000:.0f} ms")
        out["yaw"][nome] = dict(zmax=max(zs), margem_atraso_s=min(ms_))

    # ---------------- 4
    print("\n4) levantamento completo (rampa de 170°, subida, operação, degraus, empurrão no aro), 50 Hz:")
    deg = lambda t0, v: (lambda t, t0=t0, v=v: np.radians(v) if t >= t0 else 0.0)
    casos = {}; out["levantamento"] = []
    for tsub in (12.0, 20.0):
        t_op0 = 2.0 + tsub * 170 / 180
        for ffl in (False, True):
            for m_ in MOD:
                for f in (0.8, 1.25):
                    H = simula(Kn, m_["beta"] * f, m_["tau"], m_["Td"] + ATR0, t_sub=tsub, ref_phi=deg(t_op0 + 4, 5),
                               ref_psi=deg(t_op0 + 8, 30), empurrao_yaw=(t_op0 + 12.5, 1.0), ff=ffl, beta_hat=beta_id)
                    sub = (H["t"] > 2) & (H["t"] < t_op0)
                    erro = float(np.degrees(np.nanmax(np.abs(H["phi"][sub] - H["phitr"][sub]))))
                    out["levantamento"].append(dict(t_sub=tsub, ff=ffl, tau=m_["tau"], Td=m_["Td"], beta=m_["beta"] * f,
                                                    corte=H["corte"], erro_max_subida_graus=erro))
                    casos[(tsub, ffl, m_["tau"], f)] = H
            res = [c for c in out["levantamento"] if c["t_sub"] == tsub and c["ff"] == ffl]
            ncorte = sum(c["corte"] is not None for c in res)
            print(f"   t_sub {tsub:4.0f} s, compensação da gravidade {'SIM' if ffl else 'não'}: "
                  f"{ncorte}/{len(res)} cortes, erro máx. de rastreamento {max(c['erro_max_subida_graus'] for c in res):.1f}°")
    Hatual = simula(K_ATUAL, beta_id, tau_id, Td_id + ATR0)
    print(f"   (ganhos atuais na mesma sequência: corte {Hatual['corte']})")
    Hrep = simula(K_ATUAL, beta_id, tau_id, Td_id + ATR0, so_rampa=True)
    print(f"   reprodução da rampa do ensaio (ganhos atuais, melhor ajuste): corte {Hrep['corte']}")
    out["reproducao_rampa"] = dict(corte=Hrep["corte"])

    # ---------------- figuras
    fig, ax = plt.subplots(1, 2, figsize=(12, 4.2))
    a = ax[0]
    im = a.contourf(idt["nds"] * 10, idt["taus"] * 1000, idt["R2"], levels=20, cmap="viridis")
    a.plot(Td_id * 1000, tau_id * 1000, "r*", ms=12, label="melhor ajuste")
    a.plot(0, 8, "wo", ms=8, label="hipótese do projeto (8 ms)")
    fig.colorbar(im, ax=a, label="R²"); a.set(xlabel="Atraso puro $T_d$ [ms]", ylabel=r"$\tau_a$ [ms]",
                                            title="(a) Ajuste do modelo do atuador aos 4 disparos")
    a.legend(fontsize=8)
    a = ax[1]
    r = runs[2]; uf = filtra(r["u"], tau_id, int(round(Td_id / 0.01)))
    r2, th = regressao([r], tau_id, int(round(Td_id / 0.01)))
    p_mod = np.zeros_like(r["p"]); p_mod[0] = r["p"][0]
    for k in range(1, len(p_mod)):
        p_mod[k] = p_mod[k - 1] + 0.01 * (W0Q * np.sin(r["phi"][k - 1]) - 2 * Z0 * W0 * p_mod[k - 1] + th[0] * uf[k - 1] + th[1])
    a.plot(r["t"], r["p"], lw=1.2, label="medido")
    a.plot(r["t"], p_mod, lw=1.2, ls="--", label=fr"modelo ($\tau_a$ = {tau_id*1000:.0f} ms, $T_d$ = {Td_id*1000:.0f} ms)")
    a.set(xlabel="Tempo desde o LIGAR [s]", ylabel="$p$ [rad/s]", title="(b) Disparo 3: velocidade de roll")
    a.legend(fontsize=8)
    for a in ax:
        a.grid(alpha=0.3); a.xaxis.set_major_formatter(virgula); a.yaxis.set_major_formatter(virgula)
    fig.tight_layout(); fig.savefig(AQUI / "graficos" / "identificacao_atuador.png", dpi=200)

    fig, ax = plt.subplots(2, 2, figsize=(12, 7.5))
    a = ax[0, 0]
    a.plot(Hrep["t"], np.degrees(Hrep["phi"]), label="simulado, ganhos atuais")
    for rr, cor in zip(runs, ("0.6", "0.5", "0.4", "0.3")):
        a.plot(rr["t"], np.degrees(rr["phi"]), color=cor, lw=0.8)
    a.plot([], [], color="0.5", lw=0.8, label="ensaio (4 disparos)")
    a.set(title="(a) Rampa com os ganhos atuais", xlabel="Tempo desde o LIGAR [s]", ylabel=r"$\phi$ [°]"); a.legend(fontsize=8)
    a = ax[0, 1]
    for rho, mk in ((0.5, "o"), (1.0, "s"), (2.0, "^"), (3.0, "v")):
        sel = [L_ for L_ in linhas if L_["rho"] == rho and L_["zeta"] == esc["zeta"]]
        a.plot([L_["wn"] for L_ in sel], [L_["res"]["50 Hz (atual)"][1] * 1000 for L_ in sel], marker=mk, label=fr"$\rho$ = {rho:g}")
    a.plot(esc["wn"], esc["res"]["50 Hz (atual)"][1] * 1000, "r*", ms=14, label="escolha")
    a.set(title=r"(b) Margem de atraso no pior caso, 50 Hz, $\zeta$ = " + f"{esc['zeta']:g}".replace(".", ","), xlabel=r"$\omega_{n,\phi}$ [rad/s]", ylabel="[ms]")
    for (tsub, ffl, tau, f), H in casos.items():
        if tsub != 12.0:
            continue
        cor = "tab:blue" if ffl else "tab:red"
        ax[1, 0].plot(H["t"], np.degrees(H["phi"]), color=cor, lw=0.8, alpha=0.8)
        if ffl:
            ax[1, 1].plot(H["t"], np.degrees(H["psi"]), color=cor, lw=0.8, alpha=0.8)
    ax[1, 0].plot([], [], color="tab:red", label="sem compensação da gravidade")
    ax[1, 0].plot([], [], color="tab:blue", label="com compensação da gravidade")
    Hq = next(H for (ts_, ff_, *_), H in casos.items() if ts_ == 12.0)
    ax[1, 0].plot(Hq["t"], np.degrees(Hq["phitr"]), "k--", lw=0.8, label=r"$\phi_\mathrm{traj}$")
    ax[1, 0].set(title=fr"(c) Levantamento, ganhos novos, 4 modelos x $\beta$ x0,8 e x1,25", xlabel="Tempo [s]", ylabel=r"$\phi$ [°]")
    ax[1, 1].set(title=r"(d) Yaw (com compensação): degrau de 30° e empurrão no aro", xlabel="Tempo [s]", ylabel=r"$\psi$ [°]")
    for a in ax.flat:
        a.grid(alpha=0.3); a.xaxis.set_major_formatter(virgula); a.yaxis.set_major_formatter(virgula)
        if a.get_legend_handles_labels()[0]:
            a.legend(fontsize=8)
    fig.tight_layout(); fig.savefig(AQUI / "graficos" / "reprojeto_roll_atuador.png", dpi=200)
    (AQUI / "dados" / "reprojeto_roll_atuador.json").write_text(json.dumps(out, indent=2, ensure_ascii=False, default=float), encoding="utf-8")
    print("\nsalvo dados/reprojeto_roll_atuador.json, graficos/identificacao_atuador.png, graficos/reprojeto_roll_atuador.png")


if __name__ == "__main__":
    main()
