#include <WiFi.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <ESP32Servo.h>

#define MQTT_VERSION MQTT_VERSION_3_1

//================= AJUSTES =================
const char* WIFI_SSID   = "SEU_WIFI";
const char* WIFI_PASS   = "SUA_SENHA";
const char* BROKER_IP   = "IP_DO_BROKER";
const uint16_t BROKER_PORT = 1883;

const char* TOPIC_MOTOR  = "lab/esp32/motor";
const char* TOPIC_STATUS = "lab/esp32/status";
const char* TOPIC_START  = "lab/esp32/control/start";
//===========================================

bool isRunning = false;

Servo ESC;
const int   ESC_PIN      = 25;
const int   ESC_MIN_US   = 1000;
const int   ESC_MAX_US   = 2000;
const int   ARM_TIME_MS  = 3000;
const int   STEP_HOLD_MS = 1500;
const int   N_STEPS      = 50;

static inline int percentToUs(float percent) {
  percent = constrain(percent, 0.0f, 100.0f);
  return ESC_MIN_US + (int)((ESC_MAX_US - ESC_MIN_US) * (percent / 100.0f));
}

WiFiClient espClient;
PubSubClient mqtt(espClient);

void connectWiFi() {
  if (WiFi.status() == WL_CONNECTED) return;
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  Serial.print("Conectando ao WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.print("\nWiFi OK. IP: ");
  Serial.println(WiFi.localIP());
}

bool ensureMqtt() {
  if (mqtt.connected()) return true;

  Serial.print("Conectando MQTT...");
  String clientId = "esp32thrust-" + String((uint32_t)ESP.getEfuseMac(), HEX);
  clientId.toUpperCase();
  if (clientId.length() > 23) clientId = clientId.substring(0, 23);

  const char* willTopic   = TOPIC_STATUS;
  const char* willMessage = "offline";
  uint8_t     willQos     = 0;
  bool        willRetain  = true;

  bool ok = mqtt.connect(
    clientId.c_str(),
    willTopic, willQos, willRetain, willMessage
  );

  if (ok) {
    Serial.println("conectado.");
    mqtt.subscribe(TOPIC_START);
    mqtt.publish(TOPIC_STATUS, "online", true);
    return true;
  } else {
    Serial.print("falhou (rc=");
    Serial.print(mqtt.state());
    Serial.println(").");
    return false;
  }
}

enum class MotorState { ARMING, UP };
MotorState mState = MotorState::ARMING;
uint32_t   lastStepMs = 0;
int        stepIdx    = 0;
bool       armedDone  = false;

void onMsg(char* topic, byte* payload, unsigned int length) {
  String payloadStr = "";
  payloadStr.reserve(length + 1);
  for (unsigned int i = 0; i < length; i++) payloadStr += (char)payload[i];

  if (String(topic) == String(TOPIC_START)) {
    if (payloadStr == "true") {
      ESC.writeMicroseconds(ESC_MIN_US);
      stepIdx    = 0;
      armedDone  = false;
      mState     = MotorState::ARMING;
      lastStepMs = millis();
      isRunning  = true;
      Serial.println("\n=== INICIO DO ENSAIO EMPUXO x PWM ===");
      Serial.println("Aguardando ARM (3 s) antes da varredura...");
    } else if (payloadStr == "false") {
      isRunning = false;
      ESC.writeMicroseconds(ESC_MIN_US);
      stepIdx    = 0;
      armedDone  = false;
      mState     = MotorState::ARMING;
      Serial.println("\n=== ENSAIO ABORTADO. Motor parado. ===");
    }
    return;
  }
}

void motorBegin() {
  ESC.setPeriodHertz(50);
  ESC.attach(ESC_PIN, ESC_MIN_US, ESC_MAX_US);
  ESC.writeMicroseconds(ESC_MIN_US);
  Serial.println("Arming ESC no minimo...");
  lastStepMs = millis();
  mState = MotorState::ARMING;
  armedDone = false;
}

void publishStep(float pct, int us, const char* dir, int step) {
  if (!isRunning) return;

  StaticJsonDocument<192> doc;
  doc["percent"] = pct;
  doc["pwm_us"]  = us;
  doc["dir"]     = dir;
  doc["step"]    = step;
  doc["n_steps"] = N_STEPS;
  char buf[192];
  serializeJson(doc, buf, sizeof(buf));
  mqtt.publish(TOPIC_MOTOR, buf);
}

void motorFSM() {
  uint32_t now = millis();

  switch (mState) {
    case MotorState::ARMING:
      if (!armedDone && (now - lastStepMs >= (uint32_t)ARM_TIME_MS)) {
        armedDone = true;
        Serial.println("ARM concluido. Iniciando varredura 0% -> 100% em 50 passos de 1,5 s.\n");
        stepIdx = 0;
        lastStepMs = now;
        mState = MotorState::UP;
      }
      break;

    case MotorState::UP:
      if (now - lastStepMs >= (uint32_t)STEP_HOLD_MS) {
        if (stepIdx >= N_STEPS) {
          ESC.writeMicroseconds(ESC_MIN_US);
          publishStep(0.0f, ESC_MIN_US, "done", N_STEPS);
          Serial.println("\n=== ENSAIO CONCLUIDO. Motor parado. ===");
          Serial.println("Salve a planilha CSV para o processamento.\n");
          isRunning  = false;
          stepIdx    = 0;
          mState     = MotorState::ARMING;
          armedDone  = false;
          break;
        }

        float pct = (N_STEPS == 1) ? 0.0f : (100.0f * stepIdx / (N_STEPS - 1));
        int us = percentToUs(pct);
        ESC.writeMicroseconds(us);

        Serial.printf("[STEP %2d/%d]  pct=%6.2f%%  pwm_us=%d  >> FORCA DA BALANCA (gf) <<\n",
                      stepIdx + 1, N_STEPS, pct, us);
        publishStep(pct, us, "up", stepIdx + 1);

        lastStepMs = now;
        stepIdx++;
      }
      break;
  }
}

void setup() {
  Serial.begin(115200);
  connectWiFi();
  mqtt.setServer(BROKER_IP, BROKER_PORT);
  mqtt.setCallback(onMsg);
  motorBegin();
}

void loop() {
  if (WiFi.status() != WL_CONNECTED) connectWiFi();
  if (!mqtt.connected()) ensureMqtt();
  mqtt.loop();

  if (isRunning) {
    motorFSM();
  }
}
