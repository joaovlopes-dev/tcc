import json
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.signal import find_peaks, savgol_filter

AQUI = Path(__file__).resolve().parent
LOG = AQUI / "dados" / "oscilacao_livre_log.txt"
INERCIA = AQUI / "dados" / "inercia_simplificada_v3.json"
SAIDA_JSON = AQUI / "dados" / "oscilacao_livre.json"
GRAF = AQUI / "graficos"

G = 9.81
M_DRONE = 0.8546          # kg, parte que gira em roll (sem o aro)
I_XX_PADRAO = 7.06e-3     # kg m^2, valor de projeto

MEIO_PER = (0.75, 1.10)   # s, faixa de meio período aceita como oscilação livre
P_PARADO = 0.03           # rad/s, abaixo disso considera parado


def le_log():
    t, phi, p, psi = [], [], [], []
    marcas = []
    for linha in LOG.read_text(encoding="utf8").splitlines():
        if linha.startswith("lab/esp32/openloop/telemetry "):
            d = json.loads(linha.split(" ", 1)[1])
            t.append(d["t"] / 1000.0)
            phi.append(d["phi"])
            p.append(d["p"])
            psi.append(d["psi"])
        elif linha.startswith("marca "):
            marcas.append(json.loads(linha.split(" ", 1)[1]))
    t, phi, p, psi = map(np.asarray, (t, phi, p, psi))
    ordem = np.argsort(t, kind="stable")
    return t[ordem], phi[ordem], p[ordem], psi[ordem], marcas


def le_ixx_massa():
    try:
        d = json.loads(INERCIA.read_text(encoding="utf8"))
        return float(d["Ixx_kgm2"]), float(d["m_drone_kg"])
    except Exception:
        return I_XX_PADRAO, M_DRONE


def segmentos(t, phi, p):
    """Cadeias de extremos com meio período de oscilação livre."""
    pk, _ = find_peaks(phi, prominence=3, distance=40)
    vl, _ = find_peaks(-phi, prominence=3, distance=40)
    ext = np.sort(np.concatenate([pk, vl]))
    cadeias, atual = [], [ext[0]]
    for a, b in zip(ext[:-1], ext[1:]):
        dt = t[b] - t[a]
        if MEIO_PER[0] <= dt <= MEIO_PER[1]:
            atual.append(b)
        else:
            if len(atual) >= 3:
                cadeias.append(atual)
            atual = [b]
    if len(atual) >= 3:
        cadeias.append(atual)

    segs = []
    for c in cadeias:
        i0 = c[0]                      # primeiro extremo depois da soltura (mão já fora)
        # fim: depois do último extremo, até ficar parado 0,3 s (ou 1 s no máximo)
        i1 = c[-1]
        lim = min(len(t) - 1, np.searchsorted(t, t[c[-1]] + 1.0))
        while i1 < lim and np.abs(p[i1:i1 + 30]).max() > P_PARADO:
            i1 += 1
        # sem buracos de telemetria dentro do segmento
        if np.max(np.diff(t[i0:i1 + 1])) > 0.05:
            continue
        segs.append((i0, i1, c))
    return segs


def ajusta(t, phi_deg, p):
    phi = np.radians(phi_deg)
    dt = np.median(np.diff(t))
    pdd = savgol_filter(p, 15, 3, deriv=1, delta=dt)
    X = np.column_stack([-np.sin(phi), np.cos(phi), -p, -np.sign(p)])
    coef, *_ = np.linalg.lstsq(X, pdd, rcond=None)
    A, B, c, f = coef
    w0 = np.sqrt(np.hypot(A, B))
    phi_eq = np.degrees(np.arctan2(B, A)) % 360.0
    res = pdd - X @ coef
    r2 = 1 - np.var(res) / np.var(pdd)
    return dict(w0=w0, phi_eq=phi_eq, c=c, f=f, r2=r2)


def simula(t, phi0, p0, w0, phi_eq, c, f):
    """Integra o modelo ajustado a partir do 1º ponto (Euler semi-implícito, passo do log)."""
    x, v = np.radians(phi0), p0
    eq = np.radians(phi_eq)
    out = [x]
    for k in range(1, len(t)):
        h = t[k] - t[k - 1]
        a = -w0**2 * np.sin(x - eq) - c * v - f * np.sign(v)
        v_novo = v + h * a
        if f > 0 and np.sign(v_novo) != np.sign(v) and abs(w0**2 * np.sin(x - eq)) <= f:
            v_novo = 0.0              # preso pelo atrito seco
        v = v_novo
        x = x + h * v
        out.append(x)
    return np.degrees(np.array(out))


def main():
    t, phi, p, psi, marcas = le_log()
    ixx, m_drone = le_ixx_massa()
    segs = segmentos(t, phi, p)
    print(f"{len(t)} amostras, {t[-1] - t[0]:.0f} s, I_xx = {ixx:.4g} kg m^2, m_drone = {m_drone:.4g} kg, {len(segs)} solturas válidas")

    resultados = []
    for n, (i0, i1, c) in enumerate(segs, 1):
        r = ajusta(t[i0:i1], phi[i0:i1], p[i0:i1])
        meios = np.diff(t[c])
        r.update(
            n=n, t_ini=float(t[i0]), t_fim=float(t[i1]),
            amp_ini=float(abs(((phi[i0] - r["phi_eq"] + 180) % 360) - 180)),
            periodo_extremos=float(2 * np.mean(meios)),
            n_meios_ciclos=int(len(meios)),
            psi_var=float(psi[i1] - psi[i0]),
        )
        r["k"] = ixx * r["w0"] ** 2
        r["d_mm"] = 1e3 * r["k"] / (m_drone * G)
        r["zeta"] = r["c"] / (2 * r["w0"])
        r["T_f"] = ixx * r["f"]
        r["banda_atrito_graus"] = float(np.degrees(np.arcsin(min(1.0, abs(r["f"]) / r["w0"] ** 2))))
        resultados.append({k: (float(v) if isinstance(v, (np.floating, float)) else v) for k, v in r.items()})
        print(f"#{n:2d} t={t[i0]:6.1f}  A0={r['amp_ini']:5.1f}°  T={2*np.pi/r['w0']:.3f} s (extremos {r['periodo_extremos']:.3f})"
              f"  phi_eq={r['phi_eq']:6.1f}°  d={r['d_mm']:5.2f} mm  zeta={r['zeta']:.3f}"
              f"  T_f={1e3*r['T_f']:.2f} mN·m  R²={r['r2']:.3f}  Δψ={r['psi_var']:+.1f}°")

    w0s = np.array([r["w0"] for r in resultados])
    resumo = dict(
        n_solturas=len(resultados),
        I_xx=ixx, m_drone=m_drone,
        w0_media=float(w0s.mean()), w0_dp=float(w0s.std(ddof=1)),
        periodo_medio=float(2 * np.pi / w0s.mean()),
        k_media=float(np.mean([r["k"] for r in resultados])),
        k_dp=float(np.std([r["k"] for r in resultados], ddof=1)),
        d_mm_media=float(np.mean([r["d_mm"] for r in resultados])),
        d_mm_dp=float(np.std([r["d_mm"] for r in resultados], ddof=1)),
        zeta_media=float(np.mean([r["zeta"] for r in resultados])),
        T_f_media=float(np.mean([r["T_f"] for r in resultados])),
        T_f_dp=float(np.std([r["T_f"] for r in resultados], ddof=1)),
        phi_eq_lista=[round(r["phi_eq"], 1) for r in resultados],
    )
    print("\nResumo:", json.dumps(resumo, indent=1, ensure_ascii=False))
    SAIDA_JSON.write_text(json.dumps(dict(resumo=resumo, solturas=resultados, marcas=marcas),
                                     indent=1, ensure_ascii=False), encoding="utf8")

    # ---- figuras ----
    GRAF.mkdir(exist_ok=True)
    fig, ax = plt.subplots(2, 1, figsize=(12, 6), sharex=True)
    ax[0].plot(t, phi, lw=0.6)
    for r in resultados:
        ax[0].axvspan(r["t_ini"], r["t_fim"], color="tab:green", alpha=0.15)
        ax[0].hlines(r["phi_eq"], r["t_ini"], r["t_fim"], color="k", lw=1)
    ax[0].set_ylabel(r"$\phi$ [°]")
    ax[0].grid(alpha=0.3)
    ax[1].plot(t, psi, lw=0.6, color="tab:orange")
    ax[1].set_ylabel(r"$\psi$ [°]")
    ax[1].set_xlabel("t [s]")
    ax[1].grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(GRAF / "oscilacao_livre_visao_geral.png", dpi=150)

    n = len(resultados)
    cols = 3
    rows = int(np.ceil(n / cols))
    fig, axs = plt.subplots(rows, cols, figsize=(4.2 * cols, 2.6 * rows), squeeze=False)
    for a, (r, (i0, i1, _)) in zip(axs.flat, zip(resultados, segs)):
        tt = t[i0:i1] - t[i0]
        sim = simula(t[i0:i1], phi[i0], p[i0], r["w0"], r["phi_eq"], r["c"], r["f"])
        a.plot(tt, phi[i0:i1], lw=1.2, label="medido")
        a.plot(tt, sim, "--", lw=1, label="modelo")
        a.set_title(f"#{r['n']}  A0 = {r['amp_ini']:.0f}°, T = {2*np.pi/r['w0']:.2f} s", fontsize=9)
        a.grid(alpha=0.3)
    for a in axs.flat[n:]:
        a.axis("off")
    axs[0, 0].legend(fontsize=8)
    fig.supxlabel("t desde o 1º extremo após soltar [s]")
    fig.supylabel(r"$\phi$ [°]")
    fig.tight_layout()
    fig.savefig(GRAF / "oscilacao_livre_ajuste.png", dpi=150)


if __name__ == "__main__":
    main()
