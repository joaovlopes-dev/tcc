import json
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

import analisaOscilacaoLivre as osc

AQUI = Path(__file__).resolve().parent
R2_MIN = 0.95

virgula = FuncFormatter(lambda v, _: f"{v:g}".replace(".", ","))


def main():
    dados = json.loads((AQUI / "dados" / "oscilacao_livre.json").read_text(encoding="utf8"))
    sol = [s for s in dados["solturas"] if s["r2"] > R2_MIN]
    t, phi, p, _, _ = osc.le_log()

    fig, axs = plt.subplots(2, 2, figsize=(10, 6))
    for n, (a, s) in enumerate(zip(axs.flat, sol), 1):
        i0 = int(np.searchsorted(t, s["t_ini"]))
        i1 = int(np.searchsorted(t, s["t_fim"]))
        tt = t[i0:i1] - t[i0]
        sim = osc.simula(t[i0:i1], phi[i0], p[i0], s["w0"], s["phi_eq"], s["c"], s["f"])
        # desvio em relação a 180° (phi do log em (-180, 180])
        med = (phi[i0:i1] % 360.0) - 180.0
        mod = (sim % 360.0) - 180.0
        a.plot(tt, med, lw=1.3, label="medido")
        a.plot(tt, mod, "--", lw=1.1, label="modelo ajustado")
        titulo = f"Soltura {n}: $A_0$ = {s['amp_ini']:.1f}°, $T_{{\\mathrm{{osc}}}}$ = {2*np.pi/s['w0']:.2f} s"
        a.set_title(titulo.replace(".", ","), fontsize=10)
        a.grid(alpha=0.3)
        a.xaxis.set_major_formatter(virgula)
        a.yaxis.set_major_formatter(virgula)
        print(f"{n}: t = {s['t_ini']:.1f}–{s['t_fim']:.1f} s, A0 = {s['amp_ini']:.1f}°, "
              f"w0 = {s['w0']:.3f}, R² = {s['r2']:.4f}")
    axs[0, 0].legend(fontsize=9)
    fig.supxlabel("Tempo desde o primeiro extremo após a soltura [s]")
    fig.supylabel(r"$\phi - 180°$ [°]")
    fig.tight_layout()
    saida = AQUI / "graficos" / "oscilacao_livre_ajuste_4recortes.png"
    fig.savefig(saida, dpi=200)
    print("salvo", saida)


if __name__ == "__main__":
    main()
