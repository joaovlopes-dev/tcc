#include <WiFi.h>
#include <Wire.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <Preferences.h>
#include <ESP32Servo.h>
#include <math.h>

//================= AJUSTES =================
const char* WIFI_SSID   = "SEU_WIFI";
const char* WIFI_PASS   = "SUA_SENHA";
const char* BROKER_IP   = "IP_DO_BROKER";
const uint16_t BROKER_PORT = 1883;

const char* TOPIC_START  = "lab/esp32/control/start";
const char* TOPIC_HB     = "lab/esp32/heartbeat";
const char* TOPIC_CMD    = "lab/esp32/controle/cmd";
const char* TOPIC_TELEM  = "lab/esp32/controle/telemetry";
const char* TOPIC_STATE  = "lab/esp32/controle/state";
const char* TOPIC_STATUS = "lab/esp32/status";

const int I2C_SDA = 13;
const int I2C_SCL = 14;
const uint8_t MPU_ADDR = 0x68;

const int PINO_MOTOR[4] = {25, 26, 27, 33};   // M1 traseiro, M2 esq., M3 diant., M4 dir.
const int ESC_MIN_US = 1000;
const int ESC_MAX_US = 2000;
const int PWM_ZONA_MORTA_US = 1040;

// Curva de empuxo medida (eq:ajuste_empuxo): T = A*PWM^2 + B*PWM + C [N]
const float CURVA_A = 3.597e-6f;
const float CURVA_B = -6.182e-3f;
const float CURVA_C = 2.723f;
const float T_MAX_N = 4.71f;

// Ganhos do roll
const float KP_PHI_BASE = 1.0716518f, KI_PHI_BASE = 0.1997245f, KD_PHI_BASE = 0.2296832f;
float KP_PHI = KP_PHI_BASE, KI_PHI = KI_PHI_BASE, KD_PHI = KD_PHI_BASE;   // x escalas (comandos kp, ki, kd, kroll)
// Compensação da gravidade na trajetória
const float W0Q_FF = 13.8626f;   // w0² da oscilação livre [rad²/s²]
const float BETA_HAT = 20.0f;    // beta_phi identificado [1/(kg m)]
const int   ESC_TIMER_BITS = 16;
// Ganhos do yaw (conjunto alternativo selecionável pelo comando "yawg 0")
const float KP_PSI_NOVO = 10.030657f, KI_PSI_NOVO = 5.279293f, KD_PSI_NOVO = 8.974798f;
const float KP_PSI_ANT = 21.117172456f, KI_PSI_ANT = 13.198232785f, KD_PSI_ANT = 16.893737965f;
float KP_PSI = KP_PSI_NOVO, KI_PSI = KI_PSI_NOVO, KD_PSI = KD_PSI_NOVO;
const float RFC_PADRAO_HZ = 3.0f;   // corte do filtro de r (parcela derivativa do yaw)
const float T0_PADRAO_N = 2.35f;

const uint32_t TS_US = 5000;
const float    TS_S  = 0.005f;
const uint32_t RAMPA_MS = 2000;               // rampa de T0 ao armar
const float    T_SUB_PADRAO_S = 12.0f;        // subida/descida de 180°
const float    T_TRAJ_MIN_S   = 1.0f;
const uint32_t ESPERA_FIM_DESCIDA_MS = 1000;  // mantém 180° antes de desarmar
const float    U2_AMORT_MAX_N = 1.0f;         // limite do amortecimento de yaw fora da operação

const float PI_F = 3.14159265f;
const float DEG2RAD = PI_F / 180.0f;
const float RAD2DEG = 180.0f / PI_F;
const float CORTE_ERRO_RAD   = 45.0f * DEG2RAD;
const float CORTE_TAXA_RADPS = 3.0f;
const float INICIO_REPOUSO_RAD  = 15.0f * DEG2RAD;   // |phi - 180°| para aceitar "on"
const float INICIO_OPERACAO_RAD = 10.0f * DEG2RAD;   // |phi| para aceitar "on" (manual)
const float INICIO_TAXA_RADPS   = 0.2f;              // drone parado para aceitar "on"
const float YAW_LIGA_PHI_RAD = 10.0f * DEG2RAD;
const float YAW_LIGA_P_RADPS = 0.2f;
const float REF_PHI_MAX_RAD = 20.0f * DEG2RAD;
const float REF_PSI_MAX_RAD = 90.0f * DEG2RAD;

const uint32_t HB_TIMEOUT_MS = 500;
const int      FALHAS_IMU_MAX = 20;

const float TAU_INICIAL_S = 1.0f;
const int   N_BIAS_BOOT = 600;
const float BIAS_STD_MAX_RADPS = 0.005f;
const float BIAS_DIF_MAX_RADPS = 0.03f;

const float GYRO_LSB_PER_DPS = 65.5f;
const float GYRO_LSB_NVS     = 131.0f;
const float SINAL_ROLL       = 1.0f;
const float ACCEL_LSB_PER_G  = 4096.0f;
const float ACCEL_LSB_NVS    = 16384.0f;
const float LSB_TO_RADPS     = DEG2RAD / GYRO_LSB_PER_DPS;
//===========================================

enum Modo : uint8_t { M_DESARMADO = 0, M_RAMPA = 1, M_SUBIDA = 2, M_OPERACAO = 3, M_DESCIDA = 4 };
const char* NOME_MODO[] = {"desarmado", "rampa", "subida", "operacao", "descida"};

WiFiClient   espClient;
PubSubClient mqtt(espClient);
Preferences  prefs;
Servo        esc[4];

float gyro_bias_nvs[3] = {0, 0, 0};
float gyro_bias_lsb[3] = {0, 0, 0};
bool  gyro_nvs_ok = false;
float acc_off_lsb[3] = {0, 0, 0};
float acc_esc_lsb[3] = {ACCEL_LSB_PER_G, ACCEL_LSB_PER_G, ACCEL_LSB_PER_G};
bool  acc_nvs_ok = false;

enum TipoCmd : uint8_t { CMD_ON, CMD_OFF, CMD_REF_PHI, CMD_REF_PSI, CMD_REF0, CMD_T0, CMD_TSUB,
                         CMD_ALPHA, CMD_BIAS, CMD_KROLL, CMD_FF, CMD_ESCHZ, CMD_DLPF,
                         CMD_KP, CMD_KI, CMD_KD, CMD_YAWG, CMD_RFC };
struct Comando { TipoCmd tipo; float valor; };
struct SatCanal { bool roll; bool yaw; };   // canal limitado no mapeamento

struct Amostra {
  uint32_t t;
  float phi, phi_a, phi_tr, phi_ref, psi, psi_ref, p, r, u1, u2, e_phi, e_psi, uff, rf;
  uint16_t pwm[4];
  uint8_t modo, yaw, sat;
};

QueueHandle_t filaCmd, filaTelem, filaEvento;

volatile uint32_t lastHb  = 0;
volatile bool     linkOk  = false;
volatile bool     telemOn = true;
volatile float    alphaAtual = TAU_INICIAL_S / (TAU_INICIAL_S + TS_S);
volatile uint8_t  modoPub = M_DESARMADO;
volatile float    T0Atual = T0_PADRAO_N;
volatile float    TSubAtual = T_SUB_PADRAO_S;
volatile char     motivoPub[24] = "boot";
volatile float    escKp = 1.0f, escKi = 1.0f, escKd = 1.0f;   // escalas dos ganhos do roll
volatile bool     ffOn = true;        // compensação da gravidade ligada
volatile int      escHz = 50;         // frequência do PWM dos ESCs [Hz]
volatile int      dlpfCfg = 4;        // configuração do DLPF do MPU-6050
volatile int      yawGanhos = 1;      // 1 = ganhos principais do yaw, 0 = alternativos
volatile float    rfcHz = RFC_PADRAO_HZ;   // corte do filtro de r [Hz]
volatile float    aRf = 0.9100f;      // exp(-2 pi 3 Hz 5 ms), recalculado no comando rfc

struct Evento { char txt[200]; };

// ============================================================
// MPU-6050
// ============================================================
void mpuWrite(uint8_t reg, uint8_t val) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(reg);
  Wire.write(val);
  Wire.endTransmission();
}

void mpuBegin() {
  mpuWrite(0x6B, 0x00);  // acorda
  delay(10);
  mpuWrite(0x1A, (uint8_t)dlpfCfg);  // DLPF_CFG: 4 = acel. 21 Hz / giro 20 Hz (padrão), 3 = 44/42 Hz (comando dlpf)
  mpuWrite(0x1B, 0x08);  // +-500 dps
  mpuWrite(0x1C, 0x10);  // +-8 g
}

static inline void remapear(const float as[3], const float ws[3], float ac[3], float wc[3]) {
  ac[0] =  as[0];                 wc[0] =  SINAL_ROLL * ws[0];   // p
  ac[1] =  SINAL_ROLL * as[1];    wc[1] =  ws[1];                // q (pitch travado)
  ac[2] =  as[2];                 wc[2] =  ws[2];                // r
}

static inline float wrapPi(float x) { return atan2f(sinf(x), cosf(x)); }

bool mpuRead(int16_t a[3], int16_t g[3]) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(0x3B);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom((int)MPU_ADDR, 14) < 14) return false;
  for (int i = 0; i < 3; i++) a[i] = (Wire.read() << 8) | Wire.read();
  Wire.read(); Wire.read();
  for (int i = 0; i < 3; i++) g[i] = (Wire.read() << 8) | Wire.read();
  if (a[0] == 0 && a[1] == 0 && a[2] == 0 && g[0] == 0 && g[1] == 0 && g[2] == 0) {
    mpuBegin();
    return false;
  }
  return true;
}

void nvsLoad() {
  prefs.begin("imucal", true);
  gyro_nvs_ok = prefs.getBool("gbok", false);
  const float k = GYRO_LSB_PER_DPS / GYRO_LSB_NVS;
  gyro_bias_nvs[0] = prefs.getFloat("gbx", 0) * k;
  gyro_bias_nvs[1] = prefs.getFloat("gby", 0) * k;
  gyro_bias_nvs[2] = prefs.getFloat("gbz", 0) * k;
  acc_nvs_ok = prefs.getBool("aook", false);
  const float kA = ACCEL_LSB_PER_G / ACCEL_LSB_NVS;
  acc_off_lsb[0] = prefs.getFloat("aox", 0) * kA;
  acc_off_lsb[1] = prefs.getFloat("aoy", 0) * kA;
  acc_off_lsb[2] = prefs.getFloat("aoz", 0) * kA;
  acc_esc_lsb[0] = prefs.getFloat("asx", ACCEL_LSB_NVS) * kA;
  acc_esc_lsb[1] = prefs.getFloat("asy", ACCEL_LSB_NVS) * kA;
  acc_esc_lsb[2] = prefs.getFloat("asz", ACCEL_LSB_NVS) * kA;
  prefs.end();
  for (int i = 0; i < 3; i++) {
    if (acc_esc_lsb[i] < 0.5f * ACCEL_LSB_PER_G) acc_esc_lsb[i] = ACCEL_LSB_PER_G;
    gyro_bias_lsb[i] = gyro_bias_nvs[i];
  }
}

// ============================================================
// Mapeamento u -> T_i -> PWM (eq:T13_map a eq:T4_map, eq:T_sat, eq:pwm_inversa)
// ============================================================
int pwmDeEmpuxo(float T) {
  if (T <= 0.0f) return ESC_MIN_US;
  if (T >= T_MAX_N) return ESC_MAX_US;
  float disc = CURVA_B * CURVA_B - 4.0f * CURVA_A * (CURVA_C - T);
  if (disc < 0.0f) return PWM_ZONA_MORTA_US;
  float pwm = (-CURVA_B + sqrtf(disc)) / (2.0f * CURVA_A);
  if (pwm < PWM_ZONA_MORTA_US) pwm = PWM_ZONA_MORTA_US;
  if (pwm > ESC_MAX_US) pwm = ESC_MAX_US;
  return (int)lroundf(pwm);
}

float sat(float x, float lo, float hi) { return x < lo ? lo : (x > hi ? hi : x); }

// Prioridade do roll. Preenche pwm[4] e informa qual canal foi limitado.
SatCanal mapear(float Tbase, float u1, float u2, uint16_t pwm[4]) {
  float m1 = 2.0f * fminf(Tbase, T_MAX_N - Tbase);
  if (m1 < 0.0f) m1 = 0.0f;
  float u1s = sat(u1, -m1, m1);                                   // 1) roll primeiro
  float a = 0.5f * fabsf(u1s);
  float lo = 4.0f * fmaxf(a - Tbase, Tbase - T_MAX_N);            // 2) yaw na margem que sobra
  float hi = 4.0f * fminf(T_MAX_N - Tbase - a, Tbase);
  if (hi < lo) hi = lo = 0.0f;
  float u2s = sat(u2, lo, hi);
  float T[4];
  T[0] = Tbase - u2s / 4.0f;                // M1 traseiro
  T[2] = Tbase - u2s / 4.0f;                // M3 dianteiro
  T[1] = Tbase + u2s / 4.0f - u1s / 2.0f;   // M2 esquerdo
  T[3] = Tbase + u2s / 4.0f + u1s / 2.0f;   // M4 direito
  for (int i = 0; i < 4; i++) pwm[i] = pwmDeEmpuxo(sat(T[i], 0.0f, T_MAX_N));   // clip só por arredondamento
  SatCanal s = { u1s != u1, u2s != u2 };
  return s;
}

void escreverEscs(const uint16_t pwm[4]) {
  for (int i = 0; i < 4; i++) esc[i].writeMicroseconds(pwm[i]);
}

void enviarEvento(const char* txt) {
  Evento e;
  strncpy(e.txt, txt, sizeof(e.txt) - 1);
  e.txt[sizeof(e.txt) - 1] = 0;
  xQueueSend(filaEvento, &e, 0);
}

// Perfil cossenoidal de a até b em dur segundos; tau em segundos desde o início.
void perfil(float a, float b, float dur, float tau, float& x, float& xd, float& xdd) {
  if (tau <= 0.0f) { x = a; xd = 0.0f; xdd = 0.0f; return; }
  if (tau >= dur)  { x = b; xd = 0.0f; xdd = 0.0f; return; }
  float s = PI_F * tau / dur;
  x   = a + (b - a) * 0.5f * (1.0f - cosf(s));
  xd  = (b - a) * PI_F / (2.0f * dur) * sinf(s);
  xdd = (b - a) * PI_F * PI_F / (2.0f * dur * dur) * cosf(s);   // para a compensação da gravidade
}

// (Re)configura o PWM dos ESCs (frequência e temporizador de 16 bits); deixa em 1000 us
void configurarEscs(int hz) {
  for (int i = 0; i < 4; i++) {
    if (esc[i].attached()) esc[i].detach();
    esc[i].setPeriodHertz(hz);
    esc[i].setTimerWidth(ESC_TIMER_BITS);
    esc[i].attach(PINO_MOTOR[i], ESC_MIN_US, ESC_MAX_US);
    esc[i].writeMicroseconds(ESC_MIN_US);
  }
}

// ============================================================
// Bias do giroscópio
// ============================================================
void medirBiasGiro(const char* origem) {
  double s[3] = {0, 0, 0}, s2[3] = {0, 0, 0};
  int n = 0;
  int16_t a[3], g[3];
  TickType_t t0 = xTaskGetTickCount();
  for (int k = 0; k < N_BIAS_BOOT; k++) {
    if (mpuRead(a, g)) {
      for (int i = 0; i < 3; i++) { s[i] += g[i]; s2[i] += (double)g[i] * g[i]; }
      n++;
    }
    vTaskDelayUntil(&t0, pdMS_TO_TICKS(5));
  }
  char buf[200];
  if (n < N_BIAS_BOOT / 2) {
    snprintf(buf, sizeof(buf), "{\"evento\":\"bias\",\"origem\":\"%s\",\"usado\":\"nvs\",\"motivo\":\"falha_imu\"}", origem);
    enviarEvento(buf);
    return;
  }
  float media[3], dp_max = 0, dif_max = 0;
  for (int i = 0; i < 3; i++) {
    media[i] = s[i] / n;
    float dp = sqrt(fmax(0.0, s2[i] / n - (double)media[i] * media[i])) * LSB_TO_RADPS;
    dp_max = fmaxf(dp_max, dp);
    dif_max = fmaxf(dif_max, fabsf(media[i] - gyro_bias_nvs[i]) * LSB_TO_RADPS);
  }
  bool ok = dp_max < BIAS_STD_MAX_RADPS && (!gyro_nvs_ok || dif_max < BIAS_DIF_MAX_RADPS);
  for (int i = 0; i < 3; i++) gyro_bias_lsb[i] = ok ? media[i] : gyro_bias_nvs[i];
  snprintf(buf, sizeof(buf),
           "{\"evento\":\"bias\",\"origem\":\"%s\",\"usado\":\"%s\",\"b\":[%.5f,%.5f,%.5f],\"dp_max\":%.5f,\"dif_nvs\":%.5f}",
           origem, ok ? "boot" : "nvs",
           gyro_bias_lsb[0] * LSB_TO_RADPS, gyro_bias_lsb[1] * LSB_TO_RADPS,
           gyro_bias_lsb[2] * LSB_TO_RADPS, dp_max, dif_max);
  enviarEvento(buf);
}

// ============================================================
// Tarefa de controle (núcleo 1, 200 Hz)
// ============================================================
void tarefaControle(void*) {
  uint16_t pwm[4] = {ESC_MIN_US, ESC_MIN_US, ESC_MIN_US, ESC_MIN_US};
  escreverEscs(pwm);
  medirBiasGiro("boot");

  Modo modo = M_DESARMADO;
  uint32_t t_modo = 0;                       // instante de entrada no modo atual [ms]
  float phi = 0, psi = 0, phi_a = 0;
  bool phi_init = false;
  int falhas = 0;
  uint8_t div = 0;

  // trajetória e referências [rad]
  float traj_a = 0, traj_b = 0, traj_dur = 1;  // perfil do modo atual
  float phi_tr = 0, phid_tr = 0, phidd_tr = 0; // phi_traj e suas derivadas (até a 2ª derivada)
  float uff = 0;                               // compensação da gravidade [N]
  float rf = 0;                                // r filtrado para a parcela derivativa do yaw
  float lado = 1.0f;                           // +1: veio de +180°, -1: de -180° (descida volta ao mesmo lado)
  float phi_ref = 0, psi_ref = 0;              // referências de operação
  bool  yaw_on = false;
  float e_phi = 0, e_psi = 0, err_phi_ant = 0, err_psi_ant = 0;
  float u1 = 0, u2 = 0;
  bool  saturou = false;
  uint8_t satMask = 0;                         // 1 = roll limitado, 2 = yaw limitado
  bool  off_pedido = false;
  bool  inicio_manual = false;                 // LIGAR perto de 0° -> off corta direto

  auto desarmar = [&](const char* motivo) {
    bool estava = modo != M_DESARMADO;
    modo = M_DESARMADO; modoPub = M_DESARMADO;
    u1 = u2 = 0; e_phi = e_psi = 0; yaw_on = false; off_pedido = false;
    for (int i = 0; i < 4; i++) pwm[i] = ESC_MIN_US;
    escreverEscs(pwm);
    strncpy((char*)motivoPub, motivo, sizeof(motivoPub) - 1);
    if (estava) {
      char buf[120];
      snprintf(buf, sizeof(buf), "{\"evento\":\"desarmado\",\"motivo\":\"%s\",\"phi\":%.1f}", motivo, phi * RAD2DEG);
      enviarEvento(buf);
    }
  };

  auto mudarModo = [&](Modo m, uint32_t agora) {
    modo = m; modoPub = m; t_modo = agora;
    char buf[120];
    snprintf(buf, sizeof(buf), "{\"evento\":\"modo\",\"modo\":\"%s\",\"phi\":%.1f}", NOME_MODO[m], phi * RAD2DEG);
    enviarEvento(buf);
  };

  auto iniciarDescida = [&](uint32_t agora) {
    // parte de phi_traj atual (sem salto na parcela P) e vai ao repouso do mesmo lado
    traj_a = phi_tr; traj_b = lado * PI_F;
    traj_dur = fmaxf(T_TRAJ_MIN_S, TSubAtual * fabsf(traj_b - traj_a) / PI_F);
    yaw_on = false; e_psi = 0; err_psi_ant = 0;
    mudarModo(M_DESCIDA, agora);
  };

  TickType_t ultimo = xTaskGetTickCount();
  for (;;) {
    vTaskDelayUntil(&ultimo, pdMS_TO_TICKS(5));
    uint32_t agora = millis();
    int32_t idadeHb = (int32_t)(agora - lastHb);   // com sinal

    // ---------- comandos ----------
    Comando c;
    while (xQueueReceive(filaCmd, &c, 0) == pdTRUE) {
      char buf[200];
      switch (c.tipo) {
        case CMD_ON: {
          const char* motivo = nullptr;
          float phi_w = wrapPi(phi);
          bool repouso  = fabsf(wrapPi(phi - PI_F)) < INICIO_REPOUSO_RAD;
          bool operacao = fabsf(phi_w) < INICIO_OPERACAO_RAD;
          if (modo != M_DESARMADO) motivo = "ja armado";
          else if (!linkOk || idadeHb >= (int32_t)HB_TIMEOUT_MS) motivo = "sem heartbeat ou link";
          else if (!phi_init) motivo = "imu sem leitura";
          else if (!repouso && !operacao) motivo = "phi longe de 180 e de 0";
          if (motivo) {
            snprintf(buf, sizeof(buf), "{\"evento\":\"recusado\",\"cmd\":\"on\",\"motivo\":\"%s\"}", motivo);
            enviarEvento(buf);
            break;
          }
          phi = phi_w;                                  // phi em [-pi, pi]: subida pelo caminho mais curto
          lado = (phi >= 0.0f) ? 1.0f : -1.0f;
          traj_a = traj_b = phi; traj_dur = 1.0f;       // rampa: mantém o ângulo inicial
          phi_tr = phi; phid_tr = 0; phidd_tr = 0;
          phi_ref = psi_ref = 0; yaw_on = false;
          e_phi = e_psi = 0; err_phi_ant = err_psi_ant = 0;
          off_pedido = false;
          inicio_manual = !repouso;
          mudarModo(M_RAMPA, agora);
          snprintf(buf, sizeof(buf), "{\"evento\":\"armado\",\"phi_ini\":%.1f,\"T0\":%.3f,\"t_sub\":%.1f,\"inicio\":\"%s\"}",
                   phi * RAD2DEG, (float)T0Atual, (float)TSubAtual, repouso ? "repouso" : "manual");
          enviarEvento(buf);
          break;
        }
        case CMD_OFF:
          if (modo == M_DESARMADO) break;
          if (modo == M_RAMPA) desarmar("painel");                 // ainda no repouso
          else if (modo == M_DESCIDA) desarmar("painel_2o_off");    // segundo off: corte imediato
          else if (inicio_manual) desarmar("painel_manual");        // sem descida até 180°
          else { off_pedido = true; iniciarDescida(agora); }
          break;
        case CMD_REF_PHI:
        case CMD_REF_PSI:
        case CMD_REF0:
          if (modo != M_OPERACAO) {
            enviarEvento("{\"evento\":\"recusado\",\"motivo\":\"referencia so na operacao\"}");
            break;
          }
          if (c.tipo == CMD_REF_PHI) phi_ref = sat(c.valor * DEG2RAD, -REF_PHI_MAX_RAD, REF_PHI_MAX_RAD);
          else if (c.tipo == CMD_REF_PSI) {
            if (!yaw_on) { enviarEvento("{\"evento\":\"recusado\",\"motivo\":\"yaw ainda nao ligado\"}"); break; }
            psi_ref = sat(c.valor * DEG2RAD, -REF_PSI_MAX_RAD, REF_PSI_MAX_RAD);
          } else { phi_ref = 0; psi_ref = 0; }
          snprintf(buf, sizeof(buf), "{\"evento\":\"referencia\",\"phi_ref\":%.2f,\"psi_ref\":%.2f}",
                   phi_ref * RAD2DEG, psi_ref * RAD2DEG);
          enviarEvento(buf);
          break;
        case CMD_T0:
          if (modo != M_DESARMADO) { enviarEvento("{\"evento\":\"recusado\",\"motivo\":\"t0 so desarmado\"}"); break; }
          T0Atual = c.valor;
          snprintf(buf, sizeof(buf), "{\"evento\":\"t0\",\"T0\":%.3f,\"pwm0\":%d}", c.valor, pwmDeEmpuxo(c.valor));
          enviarEvento(buf);
          break;
        case CMD_TSUB:
          if (modo != M_DESARMADO) { enviarEvento("{\"evento\":\"recusado\",\"motivo\":\"tsub so desarmado\"}"); break; }
          TSubAtual = c.valor;
          snprintf(buf, sizeof(buf), "{\"evento\":\"tsub\",\"t_sub\":%.1f}", c.valor);
          enviarEvento(buf);
          break;
        case CMD_ALPHA:
          alphaAtual = c.valor;
          snprintf(buf, sizeof(buf), "{\"evento\":\"alpha\",\"alpha\":%.5f,\"tau_s\":%.4f}",
                   c.valor, c.valor * TS_S / (1.0f - c.valor));
          enviarEvento(buf);
          break;
        case CMD_BIAS:
          if (modo != M_DESARMADO) enviarEvento("{\"evento\":\"recusado\",\"motivo\":\"bias so desarmado\"}");
          else { medirBiasGiro("comando"); ultimo = xTaskGetTickCount(); }
          break;
        case CMD_KROLL:
        case CMD_KP:
        case CMD_KI:
        case CMD_KD:
        case CMD_YAWG:
        case CMD_RFC:
        case CMD_FF:
        case CMD_ESCHZ:
        case CMD_DLPF:
          if (modo != M_DESARMADO) { enviarEvento("{\"evento\":\"recusado\",\"motivo\":\"ajuste so desarmado\"}"); break; }
          if (c.tipo == CMD_KROLL || c.tipo == CMD_KP || c.tipo == CMD_KI || c.tipo == CMD_KD) {
            if (c.tipo == CMD_KROLL) { escKp = escKi = escKd = c.valor; }
            else if (c.tipo == CMD_KP) escKp = c.valor;
            else if (c.tipo == CMD_KI) escKi = c.valor;
            else escKd = c.valor;
            KP_PHI = KP_PHI_BASE * escKp; KI_PHI = KI_PHI_BASE * escKi; KD_PHI = KD_PHI_BASE * escKd;
          } else if (c.tipo == CMD_YAWG) {
            yawGanhos = c.valor > 0.5f ? 1 : 0;
            KP_PSI = yawGanhos ? KP_PSI_NOVO : KP_PSI_ANT;
            KI_PSI = yawGanhos ? KI_PSI_NOVO : KI_PSI_ANT;
            KD_PSI = yawGanhos ? KD_PSI_NOVO : KD_PSI_ANT;
          } else if (c.tipo == CMD_RFC) {
            rfcHz = c.valor;
            aRf = (c.valor > 0.0f) ? expf(-2.0f * PI_F * c.valor * TS_S) : 0.0f;
          } else if (c.tipo == CMD_FF) {
            ffOn = c.valor > 0.5f;
          } else if (c.tipo == CMD_ESCHZ) {
            escHz = (int)c.valor; configurarEscs(escHz);
            for (int i = 0; i < 4; i++) pwm[i] = ESC_MIN_US;
          } else {
            dlpfCfg = (int)c.valor; mpuWrite(0x1A, (uint8_t)dlpfCfg);
          }
          snprintf(buf, sizeof(buf), "{\"evento\":\"ajuste\",\"esc_kp_ki_kd\":[%.2f,%.2f,%.2f],\"K_phi\":[%.4f,%.4f,%.4f],\"K_psi\":[%.3f,%.3f,%.3f],\"rfc\":%.1f,\"ff\":%d,\"esc_hz\":%d,\"dlpf\":%d}",
                   (float)escKp, (float)escKi, (float)escKd, KP_PHI, KI_PHI, KD_PHI, KP_PSI, KI_PSI, KD_PSI,
                   (float)rfcHz, (int)ffOn, (int)escHz, (int)dlpfCfg);
          enviarEvento(buf);
          ultimo = xTaskGetTickCount();
          break;
      }
    }

    // ---------- segurança: comunicação ----------
    if (modo != M_DESARMADO) {
      if (!linkOk) desarmar("link");
      else if (idadeHb > (int32_t)HB_TIMEOUT_MS) desarmar("heartbeat");
    }

    // ---------- IMU e filtro complementar ----------
    int16_t a[3], g[3];
    if (!mpuRead(a, g)) {
      if (++falhas >= FALHAS_IMU_MAX && modo != M_DESARMADO) desarmar("imu");
      continue;
    }
    falhas = 0;
    float as[3], ws[3], ac[3], w[3];
    for (int i = 0; i < 3; i++) {
      as[i] = (a[i] - acc_off_lsb[i]) / acc_esc_lsb[i];
      ws[i] = (g[i] - gyro_bias_lsb[i]) * LSB_TO_RADPS;
    }
    remapear(as, ws, ac, w);
    const float p = w[0], r = w[2];
    rf = aRf * rf + (1.0f - aRf) * r;                             // filtro de 1ª ordem
    phi_a = atan2f(ac[1], ac[2]);                                 // eq:phi_acel
    if (!phi_init) { phi = phi_a; phi_init = true; }
    float al = alphaAtual;
    float phi_pred = phi + p * TS_S;
    phi   = phi_pred + (1.0f - al) * wrapPi(phi_a - phi_pred);   // eq:complementar (phi contínuo)
    phi_a = phi + wrapPi(phi_a - phi);
    psi   = psi + r * TS_S;                                       // eq:complementar_yaw

    // ---------- máquina de estados e trajetória ----------
    if (modo != M_DESARMADO) {
      float tau = (agora - t_modo) * 1e-3f;
      if (modo == M_RAMPA && agora - t_modo >= RAMPA_MS) {
        traj_a = phi_tr; traj_b = 0.0f;
        traj_dur = fmaxf(T_TRAJ_MIN_S, TSubAtual * fabsf(traj_a) / PI_F);
        mudarModo(M_SUBIDA, agora); tau = 0;
      } else if (modo == M_SUBIDA && tau >= traj_dur) {
        phi_ref = 0;
        mudarModo(M_OPERACAO, agora); tau = 0;
      } else if (modo == M_DESCIDA && tau >= traj_dur + ESPERA_FIM_DESCIDA_MS * 1e-3f) {
        desarmar("fim_descida");
      }
      if (modo == M_SUBIDA || modo == M_DESCIDA) perfil(traj_a, traj_b, traj_dur, tau, phi_tr, phid_tr, phidd_tr);
      else if (modo == M_OPERACAO) { phi_tr = 0; phid_tr = 0; phidd_tr = 0; }
      // M_RAMPA: phi_tr = ângulo inicial (fixado no "on")
    }

    if (modo == M_OPERACAO && !yaw_on && fabsf(phi) < YAW_LIGA_PHI_RAD && fabsf(p) < YAW_LIGA_P_RADPS) {
      yaw_on = true; psi = 0; psi_ref = 0; e_psi = 0; err_psi_ant = 0;
      enviarEvento("{\"evento\":\"yaw_ligado\"}");
    }

    // ---------- segurança: ângulo e velocidades ----------
    if (modo != M_DESARMADO) {
      float erro_corte = (modo == M_OPERACAO) ? fabsf(phi) : fabsf(phi - phi_tr);
      if (erro_corte > CORTE_ERRO_RAD) desarmar(modo == M_OPERACAO ? "limite_phi" : "erro_rastreamento");
      else if (fabsf(p) > CORTE_TAXA_RADPS) desarmar("limite_p");
      else if (fabsf(r) > CORTE_TAXA_RADPS) desarmar("limite_r");
    }

    // ---------- lei de controle ----------
    saturou = false; satMask = 0;
    if (modo != M_DESARMADO) {
      uint32_t dt = agora - t_modo;
      float T0 = T0Atual;
      float Tbase = (modo == M_RAMPA && dt < RAMPA_MS) ? T0 * dt / (float)RAMPA_MS : T0;

      // roll: alvo do integrador = phi_traj (subida/descida/rampa) ou phi_ref (operação)
      float alvo_phi = (modo == M_OPERACAO) ? phi_ref : phi_tr;
      float err_phi = alvo_phi - phi;
      float e_phi_novo = e_phi + 0.5f * TS_S * (err_phi + err_phi_ant);   // Tustin
      // compensação da gravidade só fora da operação (na operação phi_traj = 0 -> u_ff = 0)
      uff = (ffOn && modo != M_OPERACAO) ? (phidd_tr - W0Q_FF * sinf(phi_tr)) / BETA_HAT : 0.0f;
      float u1_novo = KP_PHI * (phi_tr - phi) + KD_PHI * (phid_tr - p) + KI_PHI * e_phi_novo + uff;

      // yaw
      float err_psi = 0, e_psi_novo = e_psi, u2_novo;
      if (yaw_on) {
        err_psi = psi_ref - psi;
        e_psi_novo = e_psi + 0.5f * TS_S * (err_psi + err_psi_ant);
        u2_novo = -KP_PSI * psi - KD_PSI * rf + KI_PSI * e_psi_novo;
      } else {
        u2_novo = sat(-KD_PSI * rf, -U2_AMORT_MAX_N, U2_AMORT_MAX_N);
      }

      SatCanal sc = mapear(Tbase, u1_novo, u2_novo, pwm);
      saturou = sc.roll || sc.yaw;
      satMask = (sc.roll ? 1 : 0) | (sc.yaw ? 2 : 0);
      // integração condicional POR CANAL: suspende o canal limitado cujo erro tem o mesmo sinal da ação
      bool congela_phi = sc.roll && (err_phi * u1_novo > 0.0f);
      bool congela_psi = sc.yaw && (err_psi * u2_novo > 0.0f);
      if (congela_phi || congela_psi) {
        if (congela_phi) u1_novo -= KI_PHI * (e_phi_novo - e_phi), e_phi_novo = e_phi;
        if (congela_psi && yaw_on) u2_novo -= KI_PSI * (e_psi_novo - e_psi), e_psi_novo = e_psi;
        mapear(Tbase, u1_novo, u2_novo, pwm);
      }
      e_phi = e_phi_novo; err_phi_ant = err_phi;
      if (yaw_on) { e_psi = e_psi_novo; err_psi_ant = err_psi; }
      u1 = u1_novo; u2 = u2_novo;
    } else {
      for (int i = 0; i < 4; i++) pwm[i] = ESC_MIN_US;
      u1 = u2 = 0; uff = 0;
    }
    escreverEscs(pwm);

    // ---------- telemetria a 100 Hz ----------
    if (telemOn && (++div & 1)) {
      Amostra s;
      s.t = agora;
      s.phi = phi * RAD2DEG; s.phi_a = phi_a * RAD2DEG; s.phi_tr = phi_tr * RAD2DEG;
      s.phi_ref = phi_ref * RAD2DEG; s.psi = psi * RAD2DEG; s.psi_ref = psi_ref * RAD2DEG;
      s.p = p; s.r = r; s.u1 = u1; s.u2 = u2; s.e_phi = e_phi; s.e_psi = e_psi; s.uff = uff; s.rf = rf;
      for (int i = 0; i < 4; i++) s.pwm[i] = pwm[i];
      s.modo = modo; s.yaw = yaw_on; s.sat = satMask;
      xQueueSend(filaTelem, &s, 0);
    }
  }
}

// ============================================================
// Comunicação (núcleo 0)
// ============================================================
void publicarEstado(const char* json) {
  mqtt.publish(TOPIC_STATE, json);
  Serial.println(json);
}

void publicarShow() {
  char buf[560];
  float al = alphaAtual;
  snprintf(buf, sizeof(buf),
           "{\"evento\":\"show\",\"modo\":\"%s\",\"motivo_ultimo_desarme\":\"%s\",\"alpha\":%.5f,"
           "\"tau_s\":%.4f,\"T0\":%.3f,\"t_sub\":%.1f,\"nvs_giro\":%d,\"nvs_acel\":%d,"
           "\"b\":[%.5f,%.5f,%.5f],\"telem\":%d,"
           "\"K_phi\":[%.4f,%.4f,%.4f],\"K_psi\":[%.4f,%.4f,%.4f],\"fw\":\"v5\",\"yawg\":%d,\"rfc\":%.1f,\"esc_kp_ki_kd\":[%.2f,%.2f,%.2f],\"ff\":%d,\"esc_hz\":%d,\"esc_bits\":%d,\"dlpf\":%d}",
           NOME_MODO[modoPub], (const char*)motivoPub, al, al * TS_S / (1.0f - al), (float)T0Atual,
           (float)TSubAtual, (int)gyro_nvs_ok, (int)acc_nvs_ok,
           gyro_bias_lsb[0] * LSB_TO_RADPS, gyro_bias_lsb[1] * LSB_TO_RADPS,
           gyro_bias_lsb[2] * LSB_TO_RADPS, (int)telemOn,
           KP_PHI, KI_PHI, KD_PHI, KP_PSI, KI_PSI, KD_PSI, (int)yawGanhos, (float)rfcHz,
           (float)escKp, (float)escKi, (float)escKd, (int)ffOn, (int)escHz, ESC_TIMER_BITS, (int)dlpfCfg);
  publicarEstado(buf);
}

void enviarCmd(TipoCmd t, float v = 0) {
  Comando c{t, v};
  xQueueSend(filaCmd, &c, 0);
}

void callback(char* topic, byte* payload, unsigned int len) {
  String msg;
  for (unsigned int i = 0; i < len; i++) msg += (char)payload[i];
  msg.trim();
  String tp(topic);

  if (tp == TOPIC_HB) { lastHb = millis(); return; }

  if (tp == TOPIC_START) {
    if (msg.equalsIgnoreCase("on"))  enviarCmd(CMD_ON);
    if (msg.equalsIgnoreCase("off")) enviarCmd(CMD_OFF);
    return;
  }
  if (tp != TOPIC_CMD) return;

  msg.toLowerCase();
  float v = 0;
  if (msg.startsWith("ref_phi") && sscanf(msg.c_str(), "ref_phi %f", &v) == 1) {
    enviarCmd(CMD_REF_PHI, v);
  } else if (msg.startsWith("ref_psi") && sscanf(msg.c_str(), "ref_psi %f", &v) == 1) {
    enviarCmd(CMD_REF_PSI, v);
  } else if (msg == "ref0") {
    enviarCmd(CMD_REF0);
  } else if (msg.startsWith("t0") && sscanf(msg.c_str(), "t0 %f", &v) == 1 && v >= 0.5f && v <= 3.0f) {
    enviarCmd(CMD_T0, v);
  } else if (msg.startsWith("tsub") && sscanf(msg.c_str(), "tsub %f", &v) == 1 && v >= 6.0f && v <= 30.0f) {
    enviarCmd(CMD_TSUB, v);
  } else if (msg.startsWith("tau") && sscanf(msg.c_str(), "tau %f", &v) == 1 && v > 0 && v < 100) {
    enviarCmd(CMD_ALPHA, v / (v + TS_S));
  } else if (msg.startsWith("alpha") && sscanf(msg.c_str(), "alpha %f", &v) == 1 && v > 0 && v < 1) {
    enviarCmd(CMD_ALPHA, v);
  } else if (msg == "bias") {
    enviarCmd(CMD_BIAS);
  } else if (msg.startsWith("kroll") && sscanf(msg.c_str(), "kroll %f", &v) == 1 && v >= 0.3f && v <= 1.5f) {
    enviarCmd(CMD_KROLL, v);
  } else if (msg.startsWith("kp ") && sscanf(msg.c_str(), "kp %f", &v) == 1 && v >= 0.3f && v <= 2.0f) {
    enviarCmd(CMD_KP, v);
  } else if (msg.startsWith("ki ") && sscanf(msg.c_str(), "ki %f", &v) == 1 && v >= 0.0f && v <= 3.0f) {
    enviarCmd(CMD_KI, v);
  } else if (msg.startsWith("kd ") && sscanf(msg.c_str(), "kd %f", &v) == 1 && v >= 0.3f && v <= 2.0f) {
    enviarCmd(CMD_KD, v);
  } else if (msg == "yawg 0" || msg == "yawg 1") {
    enviarCmd(CMD_YAWG, msg.endsWith("1") ? 1.0f : 0.0f);
  } else if (msg.startsWith("rfc ") && sscanf(msg.c_str(), "rfc %f", &v) == 1 && (v == 0.0f || (v >= 1.0f && v <= 10.0f))) {
    enviarCmd(CMD_RFC, v);
  } else if (msg == "ff 0" || msg == "ff 1") {
    enviarCmd(CMD_FF, msg.endsWith("1") ? 1.0f : 0.0f);
  } else if (msg.startsWith("eschz") && sscanf(msg.c_str(), "eschz %f", &v) == 1 &&
             (v == 50.0f || v == 100.0f || v == 200.0f || v == 400.0f)) {
    enviarCmd(CMD_ESCHZ, v);
  } else if (msg == "dlpf 3" || msg == "dlpf 4") {
    enviarCmd(CMD_DLPF, msg.endsWith("3") ? 3.0f : 4.0f);
  } else if (msg.startsWith("telem")) {
    telemOn = msg.endsWith("1");
    publicarEstado(telemOn ? "{\"evento\":\"telem\",\"on\":1}" : "{\"evento\":\"telem\",\"on\":0}");
  } else if (msg == "show") {
    publicarShow();
  } else {
    publicarEstado("{\"evento\":\"erro\",\"msg\":\"comando desconhecido ou fora da faixa\"}");
  }
}

bool conectarMqtt() {
  String id = "esp32ctrl-" + String((uint32_t)ESP.getEfuseMac(), HEX);
  if (id.length() > 23) id = id.substring(0, 23);
  if (!mqtt.connect(id.c_str(), TOPIC_STATUS, 0, true, "offline")) return false;
  mqtt.subscribe(TOPIC_START);
  mqtt.subscribe(TOPIC_HB);
  mqtt.subscribe(TOPIC_CMD);
  mqtt.publish(TOPIC_STATUS, "online", true);
  publicarShow();
  return true;
}

void publicarAmostra(const Amostra& s) {
  char buf[520];   // telemetria com o campo rf
  snprintf(buf, sizeof(buf),
           "{\"t\":%lu,\"phi\":%.3f,\"phi_a\":%.3f,\"phi_tr\":%.3f,\"phi_ref\":%.2f,\"psi\":%.3f,\"psi_ref\":%.2f,"
           "\"p\":%.5f,\"r\":%.5f,\"u1\":%.4f,\"u2\":%.4f,\"e_phi\":%.5f,\"e_psi\":%.5f,"
           "\"uff\":%.4f,\"rf\":%.5f,\"pwm\":[%u,%u,%u,%u],\"modo\":%u,\"yaw\":%u,\"sat\":%u}",
           (unsigned long)s.t, s.phi, s.phi_a, s.phi_tr, s.phi_ref, s.psi, s.psi_ref,
           s.p, s.r, s.u1, s.u2, s.e_phi, s.e_psi, s.uff, s.rf,
           s.pwm[0], s.pwm[1], s.pwm[2], s.pwm[3], s.modo, s.yaw, s.sat);
  mqtt.publish(TOPIC_TELEM, buf);
}

void tarefaComunicacao(void*) {
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.setAutoReconnect(true);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  mqtt.setServer(BROKER_IP, BROKER_PORT);
  mqtt.setCallback(callback);
  mqtt.setBufferSize(1024);
  mqtt.setKeepAlive(2);
  mqtt.setSocketTimeout(1);

  uint32_t ultimaTentativa = 0;
  for (;;) {
    bool wifiOk = WiFi.status() == WL_CONNECTED;
    if (wifiOk && !mqtt.connected() && millis() - ultimaTentativa > 2000) {
      ultimaTentativa = millis();
      Serial.print("MQTT...");
      Serial.println(conectarMqtt() ? "conectado" : "falhou");
    }
    if (mqtt.connected()) mqtt.loop();
    linkOk = wifiOk && mqtt.connected();

    Evento e;
    while (xQueueReceive(filaEvento, &e, 0) == pdTRUE) {
      if (mqtt.connected()) publicarEstado(e.txt);
      else Serial.println(e.txt);
    }
    Amostra s;
    int n = 0;
    while (n < 16 && xQueueReceive(filaTelem, &s, 0) == pdTRUE) {
      if (mqtt.connected()) publicarAmostra(s);
      n++;
    }
    vTaskDelay(pdMS_TO_TICKS(2));
  }
}

// ============================================================
void setup() {
  Serial.begin(115200);
  delay(200);

  ESP32PWM::allocateTimer(0);
  ESP32PWM::allocateTimer(1);
  configurarEscs(escHz);   // 50 Hz, temporizador de 16 bits

  Wire.begin(I2C_SDA, I2C_SCL, 400000);
  delay(10);
  mpuBegin();
  delay(50);
  nvsLoad();
  Serial.printf("NVS: giro %s, acel %s\n", gyro_nvs_ok ? "ok" : "AUSENTE", acc_nvs_ok ? "ok" : "AUSENTE");

  filaCmd    = xQueueCreate(16, sizeof(Comando));
  filaTelem  = xQueueCreate(800, sizeof(Amostra));
  filaEvento = xQueueCreate(16, sizeof(Evento));

  xTaskCreatePinnedToCore(tarefaComunicacao, "com", 8192, nullptr, 1, nullptr, 0);
  xTaskCreatePinnedToCore(tarefaControle, "ctrl", 8192, nullptr, configMAX_PRIORITIES - 2, nullptr, 1);
  Serial.println("sketch_controlador_v5: DESARMADO. Bias do giro sendo medido (3 s, manter imovel).");
}

void loop() {
  vTaskDelete(nullptr);
}
