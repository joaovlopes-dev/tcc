import json
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

AQUI = os.path.dirname(os.path.abspath(__file__))
LOG = os.path.join(AQUI, "dados", "malha_aberta_log.txt")
SAIDA_JSON = os.path.join(AQUI, "dados", "filtro_complementar_v4.json")
FIG_TAU = os.path.join(AQUI, "graficos", "filtro_complementar_tau_v4.png")
FIG_TRECHO = os.path.join(AQUI, "graficos", "filtro_complementar_trecho_v4.png")

TAUS = [0.1, 0.25, 0.5, 0.75, 1.0, 1.5, 2.0, 3.0, 5.0]
P_SAT = 8.7          # rad/s, ~500 °/s
TAU_ESCOLHIDO = 1.0


def ler_sessao_v3(caminho):
    """Devolve a última sessão e os instantes dos "bias" por comando."""
    sessoes, atual, t_ant, eventos = [], None, None, []
    with open(caminho, encoding="utf-8") as f:
        for linha in f:
            topico, _, conteudo = linha.strip().partition(" ")
            if topico.endswith("telemetry"):
                d = json.loads(conteudo)
                if t_ant is None or d["t"] < t_ant:
                    atual = {"v3": "ax" in d, "dados": [], "zero": [], "bias": []}
                    sessoes.append(atual)
                t_ant = d["t"]
                if atual["v3"]:
                    atual["dados"].append([d["t"] / 1000.0, d["phi"], d["p"],
                                           d["ax"], d["ay"], d["az"], d["psi"]])
            elif topico.endswith("state") and '"zero"' in conteudo and atual:
                atual["zero"].append(t_ant / 1000.0)
            elif topico.endswith("state") and '"origem":"comando"' in conteudo and atual:
                atual["bias"].append(t_ant / 1000.0)
    s = [x for x in sessoes if x["v3"] and len(x["dados"]) > 10000][-1]
    return np.array(s["dados"]), s["bias"]


def wrap(x):
    return np.arctan2(np.sin(x), np.cos(x))


GAP = 0.05           # s; acima disso houve perda de pacotes
DB_RESIDUAL = 0.024  # rad/s; diferença entre o bias medido e o da NVS


def filtro(tau, t, p, pa, phi0, phi_fw=None):
    dt = np.diff(t, prepend=t[0])
    out = np.empty_like(p)
    phi = phi0
    for i in range(len(p)):
        if phi_fw is not None and dt[i] > GAP:      # reinicia após perda de pacotes
            phi = phi_fw[i]
            out[i] = phi
            continue
        al = tau / (tau + dt[i]) if dt[i] > 0 else 1.0
        pred = phi + p[i] * dt[i]
        phi = pred + (1.0 - al) * wrap(pa[i] - pred)
        out[i] = phi
    return out


def main():
    a, zeros = ler_sessao_v3(LOG)
    m = a[:, 0] > zeros[-1]                     # a partir do último "bias" (início do 3.2)
    t, phi_rec, p = a[m, 0], np.radians(a[m, 1]), a[m, 2]
    psi = a[m, 6]
    ax, ay, az = a[m, 3], a[m, 4], a[m, 5]
    pa = np.unwrap(np.arctan2(ay, az))
    amag = np.sqrt(ax**2 + ay**2 + az**2)
    dt = np.diff(t, prepend=t[0])

    # intervalos parados
    g_ref = np.median(amag)
    inst = (np.abs(p) < 0.05) & (np.abs(amag - g_ref) < 0.03)
    parado = np.convolve(inst, np.ones(100), "same") >= 99
    d = np.diff(np.r_[0, parado.astype(int), 0])
    seg = [(i, f) for i, f in zip(np.where(d == 1)[0], np.where(d == -1)[0]) if f - i >= 100]

    # referência por integração do giroscópio entre âncoras
    ref = np.full_like(p, np.nan)
    valido = np.zeros_like(p, dtype=bool)
    for (i0, f0), (i1, f1) in zip(seg[:-1], seg[1:]):
        a0, a1 = pa[i0:f0].mean(), pa[i1:f1].mean()
        idx = np.arange(f0, i1)
        integ = a0 + np.cumsum(p[idx] * dt[idx])
        a1 += 2 * np.pi * np.round((integ[-1] - a1) / (2 * np.pi))
        integ -= (integ[-1] - a1) * np.linspace(0, 1, len(idx))
        ref[i0:f0], ref[idx], ref[i1:f1] = a0, integ, a1
        if not (np.abs(p[idx]) >= P_SAT).any() and not (dt[f0:i1 + 1] > GAP).any():
            valido[idx] = True
    mov = valido & ~parado

    def ruido(f):
        return float(np.mean([np.std(np.degrees(f[i + 20:k - 20])) for i, k in seg if k - i > 140]))

    # conferência até a 1ª saturação (depois dela 100 Hz x 200 Hz divergem)
    f05 = filtro(1.0, t, p, pa, phi_rec[0], phi_rec)
    sat0 = np.where(np.abs(p) >= P_SAT)[0]
    k = sat0[0] if len(sat0) else len(t)
    conf = float(np.degrees(np.sqrt(np.mean(wrap(f05[:k] - phi_rec[:k]) ** 2))))

    e_acel = np.degrees(wrap(pa - ref))[mov]
    linhas = []
    filtrados = {}
    for tau in TAUS:
        f = filtro(tau, t, p, pa, pa[0], phi_rec)
        filtrados[tau] = f
        e = np.degrees(wrap(f - ref))[mov]
        linhas.append({"tau_s": tau, "alpha": tau / (tau + 0.005),
                       "rms_mov_graus": float(np.sqrt(np.mean(e**2))),
                       "p95_mov_graus": float(np.percentile(np.abs(e), 95)),
                       "max_mov_graus": float(np.abs(e).max()),
                       "ruido_parado_graus": ruido(f)})

    # recuperação após saturação do giroscópio
    isat = np.where(np.abs(p) >= P_SAT)[0]
    recup = []
    if len(isat):
        tl = t[isat[-1]]
        pa_s = np.convolve(pa, np.ones(50) / 50, "same")
        w = (t > tl) & (np.abs(p) < 0.05)
        for tau in TAUS:
            e = np.abs(np.degrees(wrap(filtrados[tau] - pa_s)))[w]
            recup.append({"tau_s": tau, "erro_apos_saturacao_graus": float(e[:20].mean())})

    s32 = (t > zeros[-1] + 2) & (t < zeros[-1] + 118)

    # erro permanente com bias residual (trecho parado do 3.2)
    i32 = np.where(s32)[0]
    for l in linhas:
        tau = l["tau_s"]
        f_ok = filtro(tau, t[i32], p[i32], pa[i32], pa[i32][0])
        f_b = filtro(tau, t[i32], p[i32] + DB_RESIDUAL, pa[i32], pa[i32][0])
        l["erro_bias_residual_graus"] = float(np.degrees(np.mean(f_b[-500:] - f_ok[-500:])))
    resumo = {
        "sessao_t_s": [float(t[0]), float(t[-1])],
        "conferencia_offline_vs_firmware_rms_graus": conf,
        "tempo_em_movimento_valido_s": float(mov.sum() * 0.01),
        "amostras_giro_saturado": int(len(isat)),
        "buracos_telemetria": int((dt[1:] > GAP).sum()),
        "tempo_perdido_s": float(dt[1:][dt[1:] > GAP].sum()),
        "acelerometro_puro": {"rms_mov_graus": float(np.sqrt(np.mean(e_acel**2))),
                              "max_mov_graus": float(np.abs(e_acel).max()),
                              "ruido_parado_graus": ruido(pa)},
        "parado_3_2": {"phi_medio_graus": float(np.degrees(phi_rec[s32].mean())),
                       "phi_dp_graus": float(np.degrees(phi_rec[s32].std())),
                       "phi_acel_dp_graus": float(np.degrees(pa[s32].std())),
                       "deriva_p_graus_min": float(np.degrees(p[s32].mean()) * 60),
                       "deriva_psi_graus_min": float(np.polyfit(t[s32], psi[s32], 1)[0] * 60)},
        "varredura_tau": linhas,
        "recuperacao_saturacao": recup,
        "bias_residual_radps": DB_RESIDUAL,
        "tau_escolhido_s": TAU_ESCOLHIDO,
        "alpha_escolhido": TAU_ESCOLHIDO / (TAU_ESCOLHIDO + 0.005),
    }
    with open(SAIDA_JSON, "w", encoding="utf-8") as fp:
        json.dump(resumo, fp, indent=2, ensure_ascii=False)

    print(f"conferência offline x firmware (tau 1 s): rms {conf:.3f}°")
    print("3.2 parado:", resumo["parado_3_2"])
    print(f"movimento válido: {resumo['tempo_em_movimento_valido_s']:.0f} s, "
          f"giro saturado: {len(isat)} amostras")
    print("acelerômetro puro: rms {rms_mov_graus:.2f}°, máx {max_mov_graus:.1f}°, "
          "ruído parado {ruido_parado_graus:.3f}°".format(**resumo["acelerometro_puro"]))
    for l, r in zip(linhas, recup or [{}] * len(linhas)):
        print(f"tau {l['tau_s']:.2f} s (alpha {l['alpha']:.4f}): rms {l['rms_mov_graus']:.2f}°, "
              f"p95 {l['p95_mov_graus']:.2f}°, máx {l['max_mov_graus']:.2f}°, "
              f"ruído parado {l['ruido_parado_graus']:.3f}°, "
              f"erro c/ bias residual {l['erro_bias_residual_graus']:.2f}°, "
              f"erro após saturação {r.get('erro_apos_saturacao_graus', float('nan')):.1f}°")

    # figura 1: métricas x tau
    fig, ax = plt.subplots(1, 2, figsize=(11, 4))
    tt = [l["tau_s"] for l in linhas]
    ax[0].plot(tt, [l["rms_mov_graus"] for l in linhas], "o-", label="RMS em movimento")
    ax[0].plot(tt, [l["p95_mov_graus"] for l in linhas], "s-", label="95º percentil")
    ax[0].axhline(resumo["acelerometro_puro"]["rms_mov_graus"], ls="--", color="gray",
                  label="acelerômetro puro (RMS)")
    if recup:
        ax[0].plot(tt, [r["erro_apos_saturacao_graus"] for r in recup], "^-",
                   label="erro logo após saturação do giro")
    ax[0].plot(tt, [l["erro_bias_residual_graus"] for l in linhas], "^-",
               label=f"erro com bias residual de {DB_RESIDUAL:.3f} rad/s".replace(".", ","))
    ax[0].set_xscale("log"); ax[0].set_xlabel(r"$\tau_c$ [s]"); ax[0].set_ylabel("erro [°]")
    ax[0].grid(alpha=0.3, which="both"); ax[0].legend(fontsize=8)
    ax[1].plot(tt, [l["ruido_parado_graus"] for l in linhas], "o-")
    ax[1].axhline(resumo["acelerometro_puro"]["ruido_parado_graus"], ls="--", color="gray",
                  label="acelerômetro puro")
    ax[1].set_xscale("log"); ax[1].set_xlabel(r"$\tau_c$ [s]")
    ax[1].set_ylabel("desvio-padrão parado [°]"); ax[1].grid(alpha=0.3, which="both")
    ax[1].legend(fontsize=8)
    for a_ in ax:
        a_.axvline(TAU_ESCOLHIDO, color="k", lw=0.8, ls=":")
    fig.tight_layout(); fig.savefig(FIG_TAU, dpi=130)

    # figura 2: trecho de movimento (3.3)
    j = np.where(mov)[0]
    t0 = t[j[0]] - 2
    w = (t > t0) & (t < t0 + 20)
    fig, ax = plt.subplots(figsize=(11, 4))
    ax.plot(t[w], np.degrees(pa[w]), lw=0.6, color="0.6", label=r"$\phi_{acel}$")
    ax.plot(t[w], np.degrees(ref[w]), lw=1.2, color="k", label="referência (giro ancorado)")
    for tau, cor in ((0.25, "tab:orange"), (TAU_ESCOLHIDO, "tab:blue"), (5.0, "tab:green")):
        ax.plot(t[w], np.degrees(filtrados[tau][w]), lw=0.9, color=cor,
                label=rf"filtro $\tau_c$ = {tau:g} s")
    ax.set_xlabel("t [s]"); ax.set_ylabel(r"$\phi$ [°]"); ax.grid(alpha=0.3)
    ax.legend(fontsize=8, ncol=3)
    fig.tight_layout(); fig.savefig(FIG_TRECHO, dpi=130)
    print("figuras:", FIG_TAU, FIG_TRECHO)
    print("json:", SAIDA_JSON)


if __name__ == "__main__":
    main()
